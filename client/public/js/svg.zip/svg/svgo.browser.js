e="undefined"!=typeof self?self:this,t=function(){return(()=>{var e={2781:(e,t,r)=>{"use strict"
r.d(t,{version:()=>n})
const n="1.1.2"},6012:(e,t,r)=>{"use strict"
r.d(t,{i:()=>n})
const n="4.2.0"},1691:(e,t,r)=>{"use strict"
r.d(t,{default:()=>Dl})
var n={}
r.r(n)
r.d(n,{active:()=>je,description:()=>Ue,fn:()=>Qe,name:()=>Fe,params:()=>He,type:()=>Ve})
var a={}
r.r(a)
r.d(a,{active:()=>Je,description:()=>et,fn:()=>rt,name:()=>Ze,params:()=>tt,type:()=>$e})
var i={}
r.r(i)
r.d(i,{active:()=>ot,description:()=>st,fn:()=>ht,name:()=>at,params:()=>lt,type:()=>it})
var o={}
r.r(o)
r.d(o,{active:()=>St,description:()=>xt,fn:()=>Tt,name:()=>yt,params:()=>kt,type:()=>bt})
var s={}
r.r(s)
r.d(s,{active:()=>zt,description:()=>_t,fn:()=>Lt,name:()=>Et,params:()=>Pt,type:()=>Ot})
var l={}
r.r(l)
r.d(l,{active:()=>Mt,description:()=>Rt,fn:()=>jt,name:()=>Wt,params:()=>It,type:()=>Bt})
var c={}
r.r(c)
r.d(c,{active:()=>Yt,description:()=>Xt,fn:()=>Zt,name:()=>Ut,params:()=>Kt,type:()=>Ht})
var d={}
r.r(d)
r.d(d,{active:()=>Br,description:()=>Mr,fn:()=>Ur,name:()=>Lr,params:()=>Rr,type:()=>Wr})
var u={}
r.r(u)
r.d(u,{active:()=>sn,description:()=>ln,fn:()=>pn,name:()=>an,params:()=>cn,type:()=>on})
var p={}
r.r(p)
r.d(p,{active:()=>gn,description:()=>vn,fn:()=>On,name:()=>fn,params:()=>yn,type:()=>hn})
var m={}
r.r(m)
r.d(m,{active:()=>qn,description:()=>Ln,fn:()=>In,name:()=>_n,params:()=>Wn,type:()=>Pn})
var f={}
r.r(f)
r.d(f,{active:()=>Xn,description:()=>Qn,fn:()=>Zn,name:()=>Hn,params:()=>Kn,type:()=>Yn})
var h={}
r.r(h)
r.d(h,{active:()=>ea,description:()=>ta,fn:()=>na,name:()=>$n,params:()=>ra,type:()=>Jn})
var g={}
r.r(g)
r.d(g,{active:()=>sa,description:()=>la,fn:()=>da,name:()=>ia,params:()=>ca,type:()=>oa})
var v={}
r.r(v)
r.d(v,{active:()=>ha,description:()=>ga,fn:()=>ya,name:()=>ma,params:()=>va,type:()=>fa})
var y={}
r.r(y)
r.d(y,{active:()=>ka,description:()=>wa,fn:()=>Ta,name:()=>Sa,params:()=>Ca,type:()=>xa})
var b={}
r.r(b)
r.d(b,{active:()=>Oa,description:()=>za,fn:()=>Pa,name:()=>Aa,params:()=>_a,type:()=>Ea})
var S={}
r.r(S)
r.d(S,{active:()=>Wa,description:()=>Ma,fn:()=>Ia,name:()=>qa,params:()=>Ba,type:()=>La})
var x={}
r.r(x)
r.d(x,{active:()=>Ga,description:()=>Fa,fn:()=>ja,name:()=>Da,params:()=>Va,type:()=>Na})
var k={}
r.r(k)
r.d(k,{active:()=>Xa,description:()=>Ka,fn:()=>$a,name:()=>Ha,params:()=>Za,type:()=>Ya})
var w={}
r.r(w)
r.d(w,{active:()=>ti,description:()=>ri,fn:()=>ai,name:()=>Ja,params:()=>ni,type:()=>ei})
var C={}
r.r(C)
r.d(C,{active:()=>li,description:()=>ci,fn:()=>ui,name:()=>oi,params:()=>di,type:()=>si})
var T={}
r.r(T)
r.d(T,{active:()=>fi,description:()=>hi,fn:()=>vi,name:()=>pi,params:()=>gi,type:()=>mi})
var A={}
r.r(A)
r.d(A,{active:()=>Si,description:()=>xi,fn:()=>Ci,name:()=>yi,params:()=>ki,type:()=>bi})
var E={}
r.r(E)
r.d(E,{active:()=>Ei,description:()=>Oi,fn:()=>_i,name:()=>Ti,params:()=>zi,type:()=>Ai})
var O={}
r.r(O)
r.d(O,{active:()=>Li,description:()=>Wi,fn:()=>Mi,name:()=>Pi,params:()=>Bi,type:()=>qi})
var z={}
r.r(z)
r.d(z,{active:()=>Di,description:()=>Ni,fn:()=>Fi,name:()=>Ri,params:()=>Gi,type:()=>Ii})
var _={}
r.r(_)
r.d(_,{active:()=>Ui,description:()=>Hi,fn:()=>Ki,name:()=>Vi,params:()=>Yi,type:()=>ji})
var P={}
r.r(P)
r.d(P,{active:()=>$i,description:()=>Ji,fn:()=>to,name:()=>Qi,params:()=>eo,type:()=>Zi})
var q={}
r.r(q)
r.d(q,{active:()=>io,description:()=>oo,fn:()=>lo,name:()=>no,params:()=>so,type:()=>ao})
var L={}
r.r(L)
r.d(L,{active:()=>fo,description:()=>ho,fn:()=>So,name:()=>po,params:()=>go,type:()=>mo})
var W={}
r.r(W)
r.d(W,{active:()=>wo,description:()=>Co,fn:()=>Eo,name:()=>xo,params:()=>To,type:()=>ko})
var B={}
r.r(B)
r.d(B,{active:()=>_o,description:()=>Po,fn:()=>Lo,name:()=>Oo,params:()=>qo,type:()=>zo})
var M={}
r.r(M)
r.d(M,{active:()=>Mo,description:()=>Ro,fn:()=>Do,name:()=>Wo,params:()=>Io,type:()=>Bo})
var R={}
r.r(R)
r.d(R,{active:()=>jo,description:()=>Uo,fn:()=>Yo,name:()=>Fo,params:()=>Ho,type:()=>Vo})
var I={}
r.r(I)
r.d(I,{active:()=>Qo,description:()=>Zo,fn:()=>Jo,name:()=>Xo,params:()=>$o,type:()=>Ko})
var D={}
r.r(D)
r.d(D,{active:()=>rs,description:()=>ns,fn:()=>ls,name:()=>es,params:()=>as,type:()=>ts})
var N={}
r.r(N)
r.d(N,{active:()=>us,description:()=>ms,fn:()=>xs,name:()=>cs,params:()=>ps,type:()=>ds})
var G={}
r.r(G)
r.d(G,{active:()=>Cs,description:()=>Ts,fn:()=>Es,name:()=>ks,params:()=>As,type:()=>ws})
var F={}
r.r(F)
r.d(F,{active:()=>_s,description:()=>Ps,fn:()=>Ls,name:()=>Os,params:()=>qs,type:()=>zs})
var V={}
r.r(V)
r.d(V,{active:()=>Ms,description:()=>Rs,fn:()=>Ds,name:()=>Ws,params:()=>Is,type:()=>Bs})
var j={}
r.r(j)
r.d(j,{active:()=>Fs,description:()=>Vs,fn:()=>Us,name:()=>Ns,params:()=>js,type:()=>Gs})
var U={}
r.r(U)
r.d(U,{active:()=>Xs,description:()=>Ks,fn:()=>Js,name:()=>Hs,params:()=>Qs,type:()=>Ys})
var H={}
r.r(H)
r.d(H,{active:()=>nl,description:()=>al,fn:()=>ol,name:()=>tl,params:()=>il,type:()=>rl})
var Y={}
r.r(Y)
r.d(Y,{active:()=>cl,description:()=>dl,fn:()=>pl,name:()=>sl,params:()=>ul,type:()=>ll})
var X={}
r.r(X)
r.d(X,{active:()=>hl,description:()=>gl,fn:()=>yl,name:()=>ml,params:()=>vl,type:()=>fl})
var K={}
r.r(K)
r.d(K,{active:()=>xl,description:()=>kl,fn:()=>Cl,name:()=>bl,params:()=>wl,type:()=>Sl})
var Q={}
r.r(Q)
r.d(Q,{active:()=>El,description:()=>Ol,fn:()=>_l,name:()=>Tl,params:()=>zl,type:()=>Al})
var Z={}
r.r(Z)
r.d(Z,{active:()=>Bl,description:()=>Ml,fn:()=>Il,name:()=>Ll,params:()=>Rl,type:()=>Wl})
var $={}
r.r($)
r.d($,{addAttributesToSVGElement:()=>R,addClassesToSVGElement:()=>I,cleanupAttrs:()=>n,cleanupEnableBackground:()=>a,cleanupIDs:()=>i,cleanupListOfValues:()=>D,cleanupNumericValues:()=>o,collapseGroups:()=>s,convertColors:()=>l,convertEllipseToCircle:()=>c,convertPathData:()=>d,convertShapeToPath:()=>u,convertStyleToAttrs:()=>p,convertTransform:()=>m,inlineStyles:()=>f,mergePaths:()=>h,minifyStyles:()=>g,moveElemsAttrsToGroup:()=>v,moveGroupAttrsToElems:()=>y,prefixIds:()=>N,removeAttributesBySelector:()=>G,removeAttrs:()=>F,removeComments:()=>b,removeDesc:()=>S,removeDimensions:()=>V,removeDoctype:()=>x,removeEditorsNSData:()=>k,removeElementsByAttr:()=>j,removeEmptyAttrs:()=>w,removeEmptyContainers:()=>C,removeEmptyText:()=>T,removeHiddenElems:()=>A,removeMetadata:()=>E,removeNonInheritableGroupAttrs:()=>O,removeOffCanvasPaths:()=>U,removeRasterImages:()=>H,removeScriptElement:()=>Y,removeStyleElement:()=>X,removeTitle:()=>z,removeUnknownsAndDefaults:()=>_,removeUnusedNS:()=>P,removeUselessDefs:()=>q,removeUselessStrokeAndFill:()=>L,removeViewBox:()=>W,removeXMLNS:()=>K,removeXMLProcInst:()=>B,reusePaths:()=>Q,sortAttrs:()=>Z,sortDefsChildren:()=>M})
const J=function(e){e={...e,plugins:e.plugins.map((e=>({...e,params:{...e.params}})))}
Array.isArray(e.plugins)&&(e.plugins=function(e){let t
return e.reduce((function(e,r){t&&r.type===t[0].type?t.push(r):e.push(t=[r])
return e}),[])}(e.plugins))
return e}
var ee=r(4289)
var te=r.n(ee)
var re=r(7133)
var ne=r(732)
const ae={xmlMode:!0,adapter:r.n(ne)()({isTag:function(e){return e.isElem()},getParent:function(e){return e.parentNode||null},getChildren:function(e){return e.content||[]},getName:function(e){return e.elem},getText:function(e){return e.content[0].text||e.content[0].cdata||""},getAttributeValue:function(e,t){return e.hasAttr(t)?e.attr(t).value:null}})}
const ie=function(e,t){Object.assign(this,e)
t&&Object.defineProperty(this,"parentNode",{writable:!0,value:t})}
ie.prototype.clone=function(){const e=this
let t={}
Object.keys(e).forEach((function(r){"class"!==r&&"style"!==r&&"content"!==r&&(t[r]=e[r])}))
t=JSON.parse(JSON.stringify(t))
const r=new ie(t,!!e.parentNode)
e.class&&(r.class=e.class.clone(r))
e.style&&(r.style=e.style.clone(r))
e.content&&(r.content=e.content.map((function(e){const t=e.clone()
t.parentNode=r
return t})))
return r}
ie.prototype.isElem=function(e){return e?Array.isArray(e)?!!this.elem&&e.indexOf(this.elem)>-1:!!this.elem&&this.elem===e:!!this.elem}
ie.prototype.renameElem=function(e){e&&"string"==typeof e&&(this.elem=this.local=e)
return this}
ie.prototype.isEmpty=function(){return!this.content||!this.content.length}
ie.prototype.closestElem=function(e){let t=this
for(;(t=t.parentNode)&&!t.isElem(e););return t}
ie.prototype.spliceContent=function(e,t,r){if(arguments.length<2)return[]
Array.isArray(r)||(r=Array.apply(null,arguments).slice(2))
r.forEach((function(e){e.parentNode=this}),this)
return this.content.splice.apply(this.content,[e,t].concat(r))}
ie.prototype.hasAttr=function(e,t){return!!(this.attrs&&Object.keys(this.attrs).length&&(arguments.length?void 0!==t?this.attrs[e]&&this.attrs[e].value===t.toString():this.attrs[e]:this.attrs))}
ie.prototype.hasAttrLocal=function(e,t){if(!this.attrs||!Object.keys(this.attrs).length)return!1
if(!arguments.length)return!!this.attrs
let r
switch(null!=t&&t.constructor&&t.constructor.name){case"Number":case"String":r=a
break
case"RegExp":r=i
break
case"Function":r=o
break
default:r=n}return this.someAttr(r)
function n(t){return t.local===e}function a(r){return r.local===e&&t===r.value}function i(r){return r.local===e&&t.test(r.value)}function o(r){return r.local===e&&t(r.value)}}
ie.prototype.attr=function(e,t){if(this.hasAttr()&&arguments.length)return void 0!==t?this.hasAttr(e,t)?this.attrs[e]:void 0:this.attrs[e]}
ie.prototype.computedAttr=function(e,t){if(!arguments.length)return
let r=this
for(;r&&(!r.hasAttr(e)||!r.attr(e).value);r=r.parentNode);return null!=t?!!r&&r.hasAttr(e,t):r&&r.hasAttr(e)?r.attrs[e].value:void 0}
ie.prototype.removeAttr=function(e,t,r){if(!arguments.length)return!1
if(Array.isArray(e)){e.forEach(this.removeAttr,this)
return!1}if(!this.hasAttr(e))return!1
if(!r&&t&&this.attrs[e].value!==t)return!1
delete this.attrs[e]
Object.keys(this.attrs).length||delete this.attrs
return!0}
ie.prototype.addAttr=function(e){if(void 0===(e=e||{}).name||void 0===e.prefix||void 0===e.local)return!1
this.attrs=this.attrs||{}
this.attrs[e.name]=e
"class"===e.name&&this.class.hasClass()
"style"===e.name&&this.style.hasStyle()
return this.attrs[e.name]}
ie.prototype.eachAttr=function(e,t){if(!this.hasAttr())return!1
for(const r in this.attrs)e.call(t,this.attrs[r])
return!0}
ie.prototype.someAttr=function(e,t){if(!this.hasAttr())return!1
for(const r in this.attrs)if(e.call(t,this.attrs[r]))return!0
return!1}
ie.prototype.querySelectorAll=function(e){const t=(0,re.selectAll)(e,this,ae)
return t.length>0?t:null}
ie.prototype.querySelector=function(e){return(0,re.selectOne)(e,this,ae)}
ie.prototype.matches=function(e){return(0,re.is)(this,e,ae)}
const oe=function(e){this.parentNode=e
this.classNames=new Set
this.classAttr=null}
oe.prototype.clone=function(e){const t=this
let r={}
Object.keys(t).forEach((function(e){"parentNode"!==e&&(r[e]=t[e])}))
r=JSON.parse(JSON.stringify(r))
const n=new oe(e)
Object.assign(n,r)
return n}
oe.prototype.hasClass=function(){this.classAttr={name:"class",value:null}
this.addClassHandler()}
oe.prototype.addClassHandler=function(){Object.defineProperty(this.parentNode.attrs,"class",{get:this.getClassAttr.bind(this),set:this.setClassAttr.bind(this),enumerable:!0,configurable:!0})
this.addClassValueHandler()}
oe.prototype.addClassValueHandler=function(){Object.defineProperty(this.classAttr,"value",{get:this.getClassValue.bind(this),set:this.setClassValue.bind(this),enumerable:!0,configurable:!0})}
oe.prototype.getClassAttr=function(){return this.classAttr}
oe.prototype.setClassAttr=function(e){this.setClassValue(e.value)
this.classAttr=e
this.addClassValueHandler()}
oe.prototype.getClassValue=function(){return Array.from(this.classNames).join(" ")}
oe.prototype.setClassValue=function(e){if(void 0===e){this.classNames.clear()
return}const t=e.split(" ")
this.classNames=new Set(t)}
oe.prototype.add=function(){this.hasClass()
Object.values(arguments).forEach(this._addSingle.bind(this))}
oe.prototype._addSingle=function(e){this.classNames.add(e)}
oe.prototype.remove=function(){this.hasClass()
Object.values(arguments).forEach(this._removeSingle.bind(this))}
oe.prototype._removeSingle=function(e){this.classNames.delete(e)}
oe.prototype.item=function(e){return Array.from(this.classNames)[e]}
oe.prototype.toggle=function(e,t){(this.contains(e)||!1===t)&&this.classNames.delete(e)
this.classNames.add(e)}
oe.prototype.contains=function(e){return this.classNames.has(e)}
var se=r(4662)
var le=r.n(se)
var ce=r(8819)
var de=r.n(ce)
var ue=r(2454)
var pe=r.n(ue)
const me=le().List
function fe(e){const t=[]
le().walk(e,{visit:"Rule",enter:function(e){if("Rule"!==e.type)return
const r=this.atrule
const n=e
e.prelude.children.each((function(e,a){const i={item:a,atrule:r,rule:n,pseudos:[]}
e.children.each((function(e,t,r){"PseudoClassSelector"!==e.type&&"PseudoElementSelector"!==e.type||i.pseudos.push({item:t,list:r})}))
t.push(i)}))}})
return t}function he(e,t){return r=e.item.data,n=t.item.data,function(e,t){for(let r=0;r<4;r+=1){if(e[r]<t[r])return-1
if(e[r]>t[r])return 1}return 0}(pe()(r),pe()(n))
var r,n}function ge(e){return{name:e.property,value:le().generate(e.value),priority:e.important?"important":""}}function ve(e){return e.content[0].text||e.content[0].cdata||[]}function ye(e,t){if(e.content[0].cdata){e.content[0].cdata=t
return e.content[0].cdata}e.content[0].text=t
return e.content[0].text}const be=function(e){this.parentNode=e
this.properties=new Map
this.hasSynced=!1
this.styleAttr=null
this.styleValue=null
this.parseError=!1}
be.prototype.clone=function(e){var t=this
var r={}
Object.keys(t).forEach((function(e){"parentNode"!==e&&(r[e]=t[e])}))
r=JSON.parse(JSON.stringify(r))
var n=new be(e)
Object.assign(n,r)
return n}
be.prototype.hasStyle=function(){this.addStyleHandler()}
be.prototype.addStyleHandler=function(){this.styleAttr={name:"style",value:null}
Object.defineProperty(this.parentNode.attrs,"style",{get:this.getStyleAttr.bind(this),set:this.setStyleAttr.bind(this),enumerable:!0,configurable:!0})
this.addStyleValueHandler()}
be.prototype.addStyleValueHandler=function(){Object.defineProperty(this.styleAttr,"value",{get:this.getStyleValue.bind(this),set:this.setStyleValue.bind(this),enumerable:!0,configurable:!0})}
be.prototype.getStyleAttr=function(){return this.styleAttr}
be.prototype.setStyleAttr=function(e){this.setStyleValue(e.value)
this.styleAttr=e
this.addStyleValueHandler()
this.hasSynced=!1}
be.prototype.getStyleValue=function(){return this.getCssText()}
be.prototype.setStyleValue=function(e){this.properties.clear()
this.styleValue=e
this.hasSynced=!1}
be.prototype._loadCssText=function(){if(!this.hasSynced){this.hasSynced=!0
if(this.styleValue&&0!==this.styleValue.length){var e=this.styleValue
var t={}
try{t=le().parse(e,{context:"declarationList",parseValue:!1})}catch(e){this.parseError=e
return}this.parseError=!1
var r=this
t.children.each((function(e){try{var t=ge(e)
r.setProperty(t.name,t.value,t.priority)}catch(e){"Unknown node type: undefined"!==e.message&&(r.parseError=e)}}))}}}
be.prototype.getCssText=function(){var e=this.getProperties()
if(this.parseError)return this.styleValue
var t=[]
e.forEach((function(e,r){var n="important"===e.priority?"!important":""
t.push(r.trim()+":"+e.value.trim()+n)}))
return t.join(";")}
be.prototype._handleParseError=function(){this.parseError&&console.warn("Warning: Parse error when parsing inline styles, style properties of this element cannot be used. The raw styles can still be get/set using .attr('style').value. Error details: "+this.parseError)}
be.prototype._getProperty=function(e){if(void 0===e)throw Error("1 argument required, but only 0 present.")
var t=this.getProperties()
this._handleParseError()
return t.get(e.trim())}
be.prototype.getPropertyPriority=function(e){var t=this._getProperty(e)
return t?t.priority:""}
be.prototype.getPropertyValue=function(e){var t=this._getProperty(e)
return t?t.value:null}
be.prototype.item=function(e){if(void 0===e)throw Error("1 argument required, but only 0 present.")
var t=this.getProperties()
this._handleParseError()
return Array.from(t.keys())[e]}
be.prototype.getProperties=function(){this._loadCssText()
return this.properties}
be.prototype.removeProperty=function(e){if(void 0===e)throw Error("1 argument required, but only 0 present.")
this.hasStyle()
var t=this.getProperties()
this._handleParseError()
var r=this.getPropertyValue(e)
t.delete(e.trim())
return r}
be.prototype.setProperty=function(e,t,r){if(void 0===e)throw Error("propertyName argument required, but only not present.")
this.hasStyle()
var n=this.getProperties()
this._handleParseError()
var a={value:t.trim(),priority:r.trim()}
n.set(e.trim(),a)
return a}
const Se=/<!ENTITY\s+(\S+)\s+(?:'([^']+)'|"([^"]+)")\s*>/g
const xe={strict:!0,trim:!1,normalize:!0,lowercase:!0,xmlns:!0,position:!0}
function ke(e,t,r,n){return function e(a){a.content=a.content.filter((function(a){n&&a.content&&e(a)
let i=!0
for(let e=0;i&&e<r.length;e++){const n=r[e]
n.active&&!1===n.fn(a,n.params,t)&&(i=!1)}!n&&a.content&&e(a)
return i}))
return a}(e)}const we={animation:["animate","animateColor","animateMotion","animateTransform","set"],descriptive:["desc","metadata","title"],shape:["circle","ellipse","line","path","polygon","polyline","rect"],structural:["defs","g","svg","symbol","use"],paintServer:["solidColor","linearGradient","radialGradient","meshGradient","pattern","hatch"],nonRendering:["linearGradient","radialGradient","pattern","clipPath","mask","marker","symbol","filter","solidColor"],container:["a","defs","g","marker","mask","missing-glyph","pattern","svg","switch","symbol","foreignObject"],textContent:["altGlyph","altGlyphDef","altGlyphItem","glyph","glyphRef","textPath","text","tref","tspan"],textContentChild:["altGlyph","textPath","tref","tspan"],lightSource:["feDiffuseLighting","feSpecularLighting","feDistantLight","fePointLight","feSpotLight"],filterPrimitive:["feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feFlood","feGaussianBlur","feImage","feMerge","feMorphology","feOffset","feSpecularLighting","feTile","feTurbulence"]}
const Ce=["path","glyph","missing-glyph"]
const Te={animationAddition:["additive","accumulate"],animationAttributeTarget:["attributeType","attributeName"],animationEvent:["onbegin","onend","onrepeat","onload"],animationTiming:["begin","dur","end","min","max","restart","repeatCount","repeatDur","fill"],animationValue:["calcMode","values","keyTimes","keySplines","from","to","by"],conditionalProcessing:["requiredFeatures","requiredExtensions","systemLanguage"],core:["id","tabindex","xml:base","xml:lang","xml:space"],graphicalEvent:["onfocusin","onfocusout","onactivate","onclick","onmousedown","onmouseup","onmouseover","onmousemove","onmouseout","onload"],presentation:["alignment-baseline","baseline-shift","clip","clip-path","clip-rule","color","color-interpolation","color-interpolation-filters","color-profile","color-rendering","cursor","direction","display","dominant-baseline","enable-background","fill","fill-opacity","fill-rule","filter","flood-color","flood-opacity","font-family","font-size","font-size-adjust","font-stretch","font-style","font-variant","font-weight","glyph-orientation-horizontal","glyph-orientation-vertical","image-rendering","letter-spacing","lighting-color","marker-end","marker-mid","marker-start","mask","opacity","overflow","paint-order","pointer-events","shape-rendering","stop-color","stop-opacity","stroke","stroke-dasharray","stroke-dashoffset","stroke-linecap","stroke-linejoin","stroke-miterlimit","stroke-opacity","stroke-width","text-anchor","text-decoration","text-overflow","text-rendering","transform","unicode-bidi","vector-effect","visibility","word-spacing","writing-mode"],xlink:["xlink:href","xlink:show","xlink:actuate","xlink:type","xlink:role","xlink:arcrole","xlink:title"],documentEvent:["onunload","onabort","onerror","onresize","onscroll","onzoom"],filterPrimitive:["x","y","width","height","result"],transferFunction:["type","tableValues","slope","intercept","amplitude","exponent","offset"]}
const Ae={core:{"xml:space":"preserve"},filterPrimitive:{x:"0",y:"0",width:"100%",height:"100%"},presentation:{clip:"auto","clip-path":"none","clip-rule":"nonzero",mask:"none",opacity:"1","stop-color":"#000","stop-opacity":"1","fill-opacity":"1","fill-rule":"nonzero",fill:"#000",stroke:"none","stroke-width":"1","stroke-linecap":"butt","stroke-linejoin":"miter","stroke-miterlimit":"4","stroke-dasharray":"none","stroke-dashoffset":"0","stroke-opacity":"1","paint-order":"normal","vector-effect":"none",display:"inline",visibility:"visible","marker-start":"none","marker-mid":"none","marker-end":"none","color-interpolation":"sRGB","color-interpolation-filters":"linearRGB","color-rendering":"auto","shape-rendering":"auto","text-rendering":"auto","image-rendering":"auto","font-style":"normal","font-variant":"normal","font-weight":"normal","font-stretch":"normal","font-size":"medium","font-size-adjust":"none",kerning:"auto","letter-spacing":"normal","word-spacing":"normal","text-decoration":"none","text-anchor":"start","text-overflow":"clip","writing-mode":"lr-tb","glyph-orientation-vertical":"auto","glyph-orientation-horizontal":"0deg",direction:"ltr","unicode-bidi":"normal","dominant-baseline":"auto","alignment-baseline":"baseline","baseline-shift":"baseline"},transferFunction:{slope:"1",intercept:"0",amplitude:"1",exponent:"1",offset:"0"}}
const Ee={a:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation","xlink"],attrs:["class","style","externalResourcesRequired","transform","target"],defaults:{target:"_self"},contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},altGlyph:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation","xlink"],attrs:["class","style","externalResourcesRequired","x","y","dx","dy","glyphRef","format","rotate"]},altGlyphDef:{attrsGroups:["core"],content:["glyphRef"]},altGlyphItem:{attrsGroups:["core"],content:["glyphRef","altGlyphItem"]},animate:{attrsGroups:["conditionalProcessing","core","animationAddition","animationAttributeTarget","animationEvent","animationTiming","animationValue","presentation","xlink"],attrs:["externalResourcesRequired"],contentGroups:["descriptive"]},animateColor:{attrsGroups:["conditionalProcessing","core","animationEvent","xlink","animationAttributeTarget","animationTiming","animationValue","animationAddition","presentation"],attrs:["externalResourcesRequired"],contentGroups:["descriptive"]},animateMotion:{attrsGroups:["conditionalProcessing","core","animationEvent","xlink","animationTiming","animationValue","animationAddition"],attrs:["externalResourcesRequired","path","keyPoints","rotate","origin"],defaults:{rotate:"0"},contentGroups:["descriptive"],content:["mpath"]},animateTransform:{attrsGroups:["conditionalProcessing","core","animationEvent","xlink","animationAttributeTarget","animationTiming","animationValue","animationAddition"],attrs:["externalResourcesRequired","type"],contentGroups:["descriptive"]},circle:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform","cx","cy","r"],defaults:{cx:"0",cy:"0"},contentGroups:["animation","descriptive"]},clipPath:{attrsGroups:["conditionalProcessing","core","presentation"],attrs:["class","style","externalResourcesRequired","transform","clipPathUnits"],defaults:{clipPathUnits:"userSpaceOnUse"},contentGroups:["animation","descriptive","shape"],content:["text","use"]},"color-profile":{attrsGroups:["core","xlink"],attrs:["local","name","rendering-intent"],defaults:{name:"sRGB","rendering-intent":"auto"},contentGroups:["descriptive"]},cursor:{attrsGroups:["core","conditionalProcessing","xlink"],attrs:["externalResourcesRequired","x","y"],defaults:{x:"0",y:"0"},contentGroups:["descriptive"]},defs:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform"],contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},desc:{attrsGroups:["core"],attrs:["class","style"]},ellipse:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform","cx","cy","rx","ry"],defaults:{cx:"0",cy:"0"},contentGroups:["animation","descriptive"]},feBlend:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","in2","mode"],defaults:{mode:"normal"},content:["animate","set"]},feColorMatrix:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","type","values"],defaults:{type:"matrix"},content:["animate","set"]},feComponentTransfer:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in"],content:["feFuncA","feFuncB","feFuncG","feFuncR"]},feComposite:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","in2","operator","k1","k2","k3","k4"],defaults:{operator:"over",k1:"0",k2:"0",k3:"0",k4:"0"},content:["animate","set"]},feConvolveMatrix:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","order","kernelMatrix","divisor","bias","targetX","targetY","edgeMode","kernelUnitLength","preserveAlpha"],defaults:{order:"3",bias:"0",edgeMode:"duplicate",preserveAlpha:"false"},content:["animate","set"]},feDiffuseLighting:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","surfaceScale","diffuseConstant","kernelUnitLength"],defaults:{surfaceScale:"1",diffuseConstant:"1"},contentGroups:["descriptive"],content:["feDistantLight","fePointLight","feSpotLight"]},feDisplacementMap:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","in2","scale","xChannelSelector","yChannelSelector"],defaults:{scale:"0",xChannelSelector:"A",yChannelSelector:"A"},content:["animate","set"]},feDistantLight:{attrsGroups:["core"],attrs:["azimuth","elevation"],defaults:{azimuth:"0",elevation:"0"},content:["animate","set"]},feFlood:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style"],content:["animate","animateColor","set"]},feFuncA:{attrsGroups:["core","transferFunction"],content:["set","animate"]},feFuncB:{attrsGroups:["core","transferFunction"],content:["set","animate"]},feFuncG:{attrsGroups:["core","transferFunction"],content:["set","animate"]},feFuncR:{attrsGroups:["core","transferFunction"],content:["set","animate"]},feGaussianBlur:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","stdDeviation"],defaults:{stdDeviation:"0"},content:["set","animate"]},feImage:{attrsGroups:["core","presentation","filterPrimitive","xlink"],attrs:["class","style","externalResourcesRequired","preserveAspectRatio","href","xlink:href"],defaults:{preserveAspectRatio:"xMidYMid meet"},content:["animate","animateTransform","set"]},feMerge:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style"],content:["feMergeNode"]},feMergeNode:{attrsGroups:["core"],attrs:["in"],content:["animate","set"]},feMorphology:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","operator","radius"],defaults:{operator:"erode",radius:"0"},content:["animate","set"]},feOffset:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","dx","dy"],defaults:{dx:"0",dy:"0"},content:["animate","set"]},fePointLight:{attrsGroups:["core"],attrs:["x","y","z"],defaults:{x:"0",y:"0",z:"0"},content:["animate","set"]},feSpecularLighting:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in","surfaceScale","specularConstant","specularExponent","kernelUnitLength"],defaults:{surfaceScale:"1",specularConstant:"1",specularExponent:"1"},contentGroups:["descriptive","lightSource"]},feSpotLight:{attrsGroups:["core"],attrs:["x","y","z","pointsAtX","pointsAtY","pointsAtZ","specularExponent","limitingConeAngle"],defaults:{x:"0",y:"0",z:"0",pointsAtX:"0",pointsAtY:"0",pointsAtZ:"0",specularExponent:"1"},content:["animate","set"]},feTile:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","in"],content:["animate","set"]},feTurbulence:{attrsGroups:["core","presentation","filterPrimitive"],attrs:["class","style","baseFrequency","numOctaves","seed","stitchTiles","type"],defaults:{baseFrequency:"0",numOctaves:"1",seed:"0",stitchTiles:"noStitch",type:"turbulence"},content:["animate","set"]},filter:{attrsGroups:["core","presentation","xlink"],attrs:["class","style","externalResourcesRequired","x","y","width","height","filterRes","filterUnits","primitiveUnits","href","xlink:href"],defaults:{primitiveUnits:"userSpaceOnUse",x:"-10%",y:"-10%",width:"120%",height:"120%"},contentGroups:["descriptive","filterPrimitive"],content:["animate","set"]},font:{attrsGroups:["core","presentation"],attrs:["class","style","externalResourcesRequired","horiz-origin-x","horiz-origin-y","horiz-adv-x","vert-origin-x","vert-origin-y","vert-adv-y"],defaults:{"horiz-origin-x":"0","horiz-origin-y":"0"},contentGroups:["descriptive"],content:["font-face","glyph","hkern","missing-glyph","vkern"]},"font-face":{attrsGroups:["core"],attrs:["font-family","font-style","font-variant","font-weight","font-stretch","font-size","unicode-range","units-per-em","panose-1","stemv","stemh","slope","cap-height","x-height","accent-height","ascent","descent","widths","bbox","ideographic","alphabetic","mathematical","hanging","v-ideographic","v-alphabetic","v-mathematical","v-hanging","underline-position","underline-thickness","strikethrough-position","strikethrough-thickness","overline-position","overline-thickness"],defaults:{"font-style":"all","font-variant":"normal","font-weight":"all","font-stretch":"normal","unicode-range":"U+0-10FFFF","units-per-em":"1000","panose-1":"0 0 0 0 0 0 0 0 0 0",slope:"0"},contentGroups:["descriptive"],content:["font-face-src"]},"font-face-format":{attrsGroups:["core"],attrs:["string"]},"font-face-name":{attrsGroups:["core"],attrs:["name"]},"font-face-src":{attrsGroups:["core"],content:["font-face-name","font-face-uri"]},"font-face-uri":{attrsGroups:["core","xlink"],attrs:["href","xlink:href"],content:["font-face-format"]},foreignObject:{attrsGroups:["core","conditionalProcessing","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform","x","y","width","height"],defaults:{x:0,y:0}},g:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform"],contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},glyph:{attrsGroups:["core","presentation"],attrs:["class","style","d","horiz-adv-x","vert-origin-x","vert-origin-y","vert-adv-y","unicode","glyph-name","orientation","arabic-form","lang"],defaults:{"arabic-form":"initial"},contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},glyphRef:{attrsGroups:["core","presentation"],attrs:["class","style","d","horiz-adv-x","vert-origin-x","vert-origin-y","vert-adv-y"],contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},hatch:{attrsGroups:["core","presentation","xlink"],attrs:["class","style","x","y","pitch","rotate","hatchUnits","hatchContentUnits","transform"],defaults:{hatchUnits:"objectBoundingBox",hatchContentUnits:"userSpaceOnUse",x:"0",y:"0",pitch:"0",rotate:"0"},contentGroups:["animation","descriptive"],content:["hatchPath"]},hatchPath:{attrsGroups:["core","presentation","xlink"],attrs:["class","style","d","offset"],defaults:{offset:"0"},contentGroups:["animation","descriptive"]},hkern:{attrsGroups:["core"],attrs:["u1","g1","u2","g2","k"]},image:{attrsGroups:["core","conditionalProcessing","graphicalEvent","xlink","presentation"],attrs:["class","style","externalResourcesRequired","preserveAspectRatio","transform","x","y","width","height","href","xlink:href"],defaults:{x:"0",y:"0",preserveAspectRatio:"xMidYMid meet"},contentGroups:["animation","descriptive"]},line:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform","x1","y1","x2","y2"],defaults:{x1:"0",y1:"0",x2:"0",y2:"0"},contentGroups:["animation","descriptive"]},linearGradient:{attrsGroups:["core","presentation","xlink"],attrs:["class","style","externalResourcesRequired","x1","y1","x2","y2","gradientUnits","gradientTransform","spreadMethod","href","xlink:href"],defaults:{x1:"0",y1:"0",x2:"100%",y2:"0",spreadMethod:"pad"},contentGroups:["descriptive"],content:["animate","animateTransform","set","stop"]},marker:{attrsGroups:["core","presentation"],attrs:["class","style","externalResourcesRequired","viewBox","preserveAspectRatio","refX","refY","markerUnits","markerWidth","markerHeight","orient"],defaults:{markerUnits:"strokeWidth",refX:"0",refY:"0",markerWidth:"3",markerHeight:"3"},contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},mask:{attrsGroups:["conditionalProcessing","core","presentation"],attrs:["class","style","externalResourcesRequired","x","y","width","height","maskUnits","maskContentUnits"],defaults:{maskUnits:"objectBoundingBox",maskContentUnits:"userSpaceOnUse",x:"-10%",y:"-10%",width:"120%",height:"120%"},contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},metadata:{attrsGroups:["core"]},"missing-glyph":{attrsGroups:["core","presentation"],attrs:["class","style","d","horiz-adv-x","vert-origin-x","vert-origin-y","vert-adv-y"],contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},mpath:{attrsGroups:["core","xlink"],attrs:["externalResourcesRequired","href","xlink:href"],contentGroups:["descriptive"]},path:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform","d","pathLength"],contentGroups:["animation","descriptive"]},pattern:{attrsGroups:["conditionalProcessing","core","presentation","xlink"],attrs:["class","style","externalResourcesRequired","viewBox","preserveAspectRatio","x","y","width","height","patternUnits","patternContentUnits","patternTransform","href","xlink:href"],defaults:{patternUnits:"objectBoundingBox",patternContentUnits:"userSpaceOnUse",x:"0",y:"0",width:"0",height:"0",preserveAspectRatio:"xMidYMid meet"},contentGroups:["animation","descriptive","paintServer","shape","structural"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},polygon:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform","points"],contentGroups:["animation","descriptive"]},polyline:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform","points"],contentGroups:["animation","descriptive"]},radialGradient:{attrsGroups:["core","presentation","xlink"],attrs:["class","style","externalResourcesRequired","cx","cy","r","fx","fy","fr","gradientUnits","gradientTransform","spreadMethod","href","xlink:href"],defaults:{gradientUnits:"objectBoundingBox",cx:"50%",cy:"50%",r:"50%"},contentGroups:["descriptive"],content:["animate","animateTransform","set","stop"]},meshGradient:{attrsGroups:["core","presentation","xlink"],attrs:["class","style","x","y","gradientUnits","transform"],contentGroups:["descriptive","paintServer","animation"],content:["meshRow"]},meshRow:{attrsGroups:["core","presentation"],attrs:["class","style"],contentGroups:["descriptive"],content:["meshPatch"]},meshPatch:{attrsGroups:["core","presentation"],attrs:["class","style"],contentGroups:["descriptive"],content:["stop"]},rect:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform","x","y","width","height","rx","ry"],defaults:{x:"0",y:"0"},contentGroups:["animation","descriptive"]},script:{attrsGroups:["core","xlink"],attrs:["externalResourcesRequired","type","href","xlink:href"]},set:{attrsGroups:["conditionalProcessing","core","animation","xlink","animationAttributeTarget","animationTiming"],attrs:["externalResourcesRequired","to"],contentGroups:["descriptive"]},solidColor:{attrsGroups:["core","presentation"],attrs:["class","style"],contentGroups:["paintServer"]},stop:{attrsGroups:["core","presentation"],attrs:["class","style","offset","path"],content:["animate","animateColor","set"]},style:{attrsGroups:["core"],attrs:["type","media","title"],defaults:{type:"text/css"}},svg:{attrsGroups:["conditionalProcessing","core","documentEvent","graphicalEvent","presentation"],attrs:["class","style","x","y","width","height","viewBox","preserveAspectRatio","zoomAndPan","version","baseProfile","contentScriptType","contentStyleType"],defaults:{x:"0",y:"0",width:"100%",height:"100%",preserveAspectRatio:"xMidYMid meet",zoomAndPan:"magnify",version:"1.1",baseProfile:"none",contentScriptType:"application/ecmascript",contentStyleType:"text/css"},contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},switch:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform"],contentGroups:["animation","descriptive","shape"],content:["a","foreignObject","g","image","svg","switch","text","use"]},symbol:{attrsGroups:["core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","preserveAspectRatio","viewBox","refX","refY"],defaults:{refX:0,refY:0},contentGroups:["animation","descriptive","shape","structural","paintServer"],content:["a","altGlyphDef","clipPath","color-profile","cursor","filter","font","font-face","foreignObject","image","marker","mask","pattern","script","style","switch","text","view"]},text:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","transform","lengthAdjust","x","y","dx","dy","rotate","textLength"],defaults:{x:"0",y:"0",lengthAdjust:"spacing"},contentGroups:["animation","descriptive","textContentChild"],content:["a"]},textPath:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation","xlink"],attrs:["class","style","externalResourcesRequired","href","xlink:href","startOffset","method","spacing","d"],defaults:{startOffset:"0",method:"align",spacing:"exact"},contentGroups:["descriptive"],content:["a","altGlyph","animate","animateColor","set","tref","tspan"]},title:{attrsGroups:["core"],attrs:["class","style"]},tref:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation","xlink"],attrs:["class","style","externalResourcesRequired","href","xlink:href"],contentGroups:["descriptive"],content:["animate","animateColor","set"]},tspan:{attrsGroups:["conditionalProcessing","core","graphicalEvent","presentation"],attrs:["class","style","externalResourcesRequired","x","y","dx","dy","rotate","textLength","lengthAdjust"],contentGroups:["descriptive"],content:["a","altGlyph","animate","animateColor","set","tref","tspan"]},use:{attrsGroups:["core","conditionalProcessing","graphicalEvent","presentation","xlink"],attrs:["class","style","externalResourcesRequired","transform","x","y","width","height","href","xlink:href"],defaults:{x:"0",y:"0"},contentGroups:["animation","descriptive"]},view:{attrsGroups:["core"],attrs:["externalResourcesRequired","viewBox","preserveAspectRatio","zoomAndPan","viewTarget"],contentGroups:["descriptive"]},vkern:{attrsGroups:["core"],attrs:["u1","g1","u2","g2","k"]}}
const Oe=["clip-path","color-profile","fill","filter","marker-start","marker-mid","marker-end","mask","stroke","style"]
const ze=["clip-rule","color","color-interpolation","color-interpolation-filters","color-profile","color-rendering","cursor","direction","dominant-baseline","fill","fill-opacity","fill-rule","font","font-family","font-size","font-size-adjust","font-stretch","font-style","font-variant","font-weight","glyph-orientation-horizontal","glyph-orientation-vertical","image-rendering","letter-spacing","marker","marker-end","marker-mid","marker-start","paint-order","pointer-events","shape-rendering","stroke","stroke-dasharray","stroke-dashoffset","stroke-linecap","stroke-linejoin","stroke-miterlimit","stroke-opacity","stroke-width","text-anchor","text-rendering","transform","visibility","word-spacing","writing-mode"]
const _e=["display","clip-path","filter","mask","opacity","text-decoration","transform","unicode-bidi","visibility"]
const Pe={aliceblue:"#f0f8ff",antiquewhite:"#faebd7",aqua:"#0ff",aquamarine:"#7fffd4",azure:"#f0ffff",beige:"#f5f5dc",bisque:"#ffe4c4",black:"#000",blanchedalmond:"#ffebcd",blue:"#00f",blueviolet:"#8a2be2",brown:"#a52a2a",burlywood:"#deb887",cadetblue:"#5f9ea0",chartreuse:"#7fff00",chocolate:"#d2691e",coral:"#ff7f50",cornflowerblue:"#6495ed",cornsilk:"#fff8dc",crimson:"#dc143c",cyan:"#0ff",darkblue:"#00008b",darkcyan:"#008b8b",darkgoldenrod:"#b8860b",darkgray:"#a9a9a9",darkgreen:"#006400",darkgrey:"#a9a9a9",darkkhaki:"#bdb76b",darkmagenta:"#8b008b",darkolivegreen:"#556b2f",darkorange:"#ff8c00",darkorchid:"#9932cc",darkred:"#8b0000",darksalmon:"#e9967a",darkseagreen:"#8fbc8f",darkslateblue:"#483d8b",darkslategray:"#2f4f4f",darkslategrey:"#2f4f4f",darkturquoise:"#00ced1",darkviolet:"#9400d3",deeppink:"#ff1493",deepskyblue:"#00bfff",dimgray:"#696969",dimgrey:"#696969",dodgerblue:"#1e90ff",firebrick:"#b22222",floralwhite:"#fffaf0",forestgreen:"#228b22",fuchsia:"#f0f",gainsboro:"#dcdcdc",ghostwhite:"#f8f8ff",gold:"#ffd700",goldenrod:"#daa520",gray:"#808080",green:"#008000",greenyellow:"#adff2f",grey:"#808080",honeydew:"#f0fff0",hotpink:"#ff69b4",indianred:"#cd5c5c",indigo:"#4b0082",ivory:"#fffff0",khaki:"#f0e68c",lavender:"#e6e6fa",lavenderblush:"#fff0f5",lawngreen:"#7cfc00",lemonchiffon:"#fffacd",lightblue:"#add8e6",lightcoral:"#f08080",lightcyan:"#e0ffff",lightgoldenrodyellow:"#fafad2",lightgray:"#d3d3d3",lightgreen:"#90ee90",lightgrey:"#d3d3d3",lightpink:"#ffb6c1",lightsalmon:"#ffa07a",lightseagreen:"#20b2aa",lightskyblue:"#87cefa",lightslategray:"#789",lightslategrey:"#789",lightsteelblue:"#b0c4de",lightyellow:"#ffffe0",lime:"#0f0",limegreen:"#32cd32",linen:"#faf0e6",magenta:"#f0f",maroon:"#800000",mediumaquamarine:"#66cdaa",mediumblue:"#0000cd",mediumorchid:"#ba55d3",mediumpurple:"#9370db",mediumseagreen:"#3cb371",mediumslateblue:"#7b68ee",mediumspringgreen:"#00fa9a",mediumturquoise:"#48d1cc",mediumvioletred:"#c71585",midnightblue:"#191970",mintcream:"#f5fffa",mistyrose:"#ffe4e1",moccasin:"#ffe4b5",navajowhite:"#ffdead",navy:"#000080",oldlace:"#fdf5e6",olive:"#808000",olivedrab:"#6b8e23",orange:"#ffa500",orangered:"#ff4500",orchid:"#da70d6",palegoldenrod:"#eee8aa",palegreen:"#98fb98",paleturquoise:"#afeeee",palevioletred:"#db7093",papayawhip:"#ffefd5",peachpuff:"#ffdab9",peru:"#cd853f",pink:"#ffc0cb",plum:"#dda0dd",powderblue:"#b0e0e6",purple:"#800080",rebeccapurple:"#639",red:"#f00",rosybrown:"#bc8f8f",royalblue:"#4169e1",saddlebrown:"#8b4513",salmon:"#fa8072",sandybrown:"#f4a460",seagreen:"#2e8b57",seashell:"#fff5ee",sienna:"#a0522d",silver:"#c0c0c0",skyblue:"#87ceeb",slateblue:"#6a5acd",slategray:"#708090",slategrey:"#708090",snow:"#fffafa",springgreen:"#00ff7f",steelblue:"#4682b4",tan:"#d2b48c",teal:"#008080",thistle:"#d8bfd8",tomato:"#ff6347",turquoise:"#40e0d0",violet:"#ee82ee",wheat:"#f5deb3",white:"#fff",whitesmoke:"#f5f5f5",yellow:"#ff0",yellowgreen:"#9acd32"}
const qe={"#f0ffff":"azure","#f5f5dc":"beige","#ffe4c4":"bisque","#a52a2a":"brown","#ff7f50":"coral","#ffd700":"gold","#808080":"gray","#008000":"green","#4b0082":"indigo","#fffff0":"ivory","#f0e68c":"khaki","#faf0e6":"linen","#800000":"maroon","#000080":"navy","#808000":"olive","#ffa500":"orange","#da70d6":"orchid","#cd853f":"peru","#ffc0cb":"pink","#dda0dd":"plum","#800080":"purple","#f00":"red","#ff0000":"red","#fa8072":"salmon","#a0522d":"sienna","#c0c0c0":"silver","#fffafa":"snow","#d2b48c":"tan","#008080":"teal","#ff6347":"tomato","#ee82ee":"violet","#f5deb3":"wheat"}
const Le=["color","fill","stroke","stop-color","flood-color","lighting-color"]
const We=we.textContent.concat("title")
const Be="\n"
const Me={doctypeStart:"<!DOCTYPE",doctypeEnd:">",procInstStart:"<?",procInstEnd:"?>",tagOpenStart:"<",tagOpenEnd:">",tagCloseStart:"</",tagCloseEnd:">",tagShortStart:"<",tagShortEnd:"/>",attrStart:'="',attrEnd:'"',commentStart:"\x3c!--",commentEnd:"--\x3e",cdataStart:"<![CDATA[",cdataEnd:"]]>",textStart:"",textEnd:"",indent:4,regEntities:/[&'"<>]/g,regValEntities:/[&"<>]/g,encodeEntity:function(e){return Re[e]},pretty:!1,useShortTags:!0}
const Re={"&":"&amp;","'":"&apos;",'"':"&quot;",">":"&gt;","<":"&lt;"}
function Ie(e){this.config=e?Object.assign({},Me,e):Object.assign({},Me)
const t=this.config.indent
"number"!=typeof t||isNaN(t)?"string"!=typeof t&&(this.config.indent="    "):this.config.indent=t<0?"\t":" ".repeat(t)
if(this.config.pretty){this.config.doctypeEnd+=Be
this.config.procInstEnd+=Be
this.config.commentEnd+=Be
this.config.cdataEnd+=Be
this.config.tagShortEnd+=Be
this.config.tagOpenEnd+=Be
this.config.tagCloseEnd+=Be
this.config.textEnd+=Be}this.indentLevel=0
this.textContext=null}Ie.prototype.convert=function(e){let t=""
if(e.content){this.indentLevel++
e.content.forEach((function(e){e.elem?t+=this.createElem(e):e.text?t+=this.createText(e.text):e.doctype?t+=this.createDoctype(e.doctype):e.processinginstruction?t+=this.createProcInst(e.processinginstruction):e.comment?t+=this.createComment(e.comment):e.cdata&&(t+=this.createCDATA(e.cdata))}),this)}this.indentLevel--
return{data:t,info:{width:this.width,height:this.height}}}
Ie.prototype.createIndent=function(){let e=""
this.config.pretty&&!this.textContext&&(e=this.config.indent.repeat(this.indentLevel-1))
return e}
Ie.prototype.createDoctype=function(e){return this.config.doctypeStart+e+this.config.doctypeEnd}
Ie.prototype.createProcInst=function(e){return this.config.procInstStart+e.name+" "+e.body+this.config.procInstEnd}
Ie.prototype.createComment=function(e){return this.config.commentStart+e+this.config.commentEnd}
Ie.prototype.createCDATA=function(e){return this.createIndent()+this.config.cdataStart+e+this.config.cdataEnd}
Ie.prototype.createElem=function(e){if(e.isElem("svg")&&e.hasAttr("width")&&e.hasAttr("height")){this.width=e.attr("width").value
this.height=e.attr("height").value}if(e.isEmpty())return this.config.useShortTags?this.createIndent()+this.config.tagShortStart+e.elem+this.createAttrs(e)+this.config.tagShortEnd:this.createIndent()+this.config.tagShortStart+e.elem+this.createAttrs(e)+this.config.tagOpenEnd+this.config.tagCloseStart+e.elem+this.config.tagCloseEnd
{let t=this.config.tagOpenStart
let r=this.config.tagOpenEnd
let n=this.config.tagCloseStart
let a=this.config.tagCloseEnd
let i=this.createIndent()
let o=""
let s=""
let l=""
if(this.textContext){t=Me.tagOpenStart
r=Me.tagOpenEnd
n=Me.tagCloseStart
a=Me.tagCloseEnd
i=""}else if(e.isElem(We)){this.config.pretty&&(o+=i+this.config.indent)
this.textContext=e}s+=this.convert(e).data
if(this.textContext===e){this.textContext=null
this.config.pretty&&(l=Be)}return i+t+e.elem+this.createAttrs(e)+r+o+s+l+this.createIndent()+n+e.elem+a}}
Ie.prototype.createAttrs=function(e){let t=""
e.eachAttr((function(e){void 0!==e.value?t+=" "+e.name+this.config.attrStart+String(e.value).replace(this.config.regValEntities,this.config.encodeEntity)+this.config.attrEnd:t+=" "+e.name}),this)
return t}
Ie.prototype.createText=function(e){return this.createIndent()+this.config.textStart+e.replace(this.config.regEntities,this.config.encodeEntity)+(this.textContext?"":this.config.textEnd)}
const De=function(e,t,r){let n=""
let a
let i
e.forEach((function(e,o){a=" "
0===o&&(a="")
if(t.noSpaceAfterFlags&&("A"===r||"a"===r)){const e=o%7
4!==e&&5!==e||(a="")}t.leadingZero&&(e=Ne(e))
t.negativeExtraSpace&&""!==a&&(e<0||46===String(e).charCodeAt(0)&&i%1!=0)&&(a="")
i=e
n+=a+e}))
return n}
const Ne=function(e){let t=e.toString()
e>0&&e<1&&48===t.charCodeAt(0)?t=t.slice(1):e>-1&&e<0&&48===t.charCodeAt(1)&&(t=t.charAt(0)+t.slice(2))
return t}

;/**
 * SVGO is a Nodejs-based tool for optimizing SVG vector graphics files.
 *
 * @see https://github.com/svg/svgo
 *
 * @author Kir Belevich <kir@soulshine.in> (https://github.com/deepsweet)
 * @copyright © 2012 Kir Belevich
 * @license MIT https://raw.githubusercontent.com/svg/svgo/master/LICENSE
 */const Ge=function(e){this.config=Ge.Config(e)}
Ge.Config=J
Ge.prototype.optimize=function(e,t){t=t||{}
return new Promise(((r,n)=>{if(this.config.error){n(this.config.error)
return}const a=this.config
const i=a.multipass?10:1
let o=0
let s=Number.POSITIVE_INFINITY
const l=e=>{if(e.error)n(e.error)
else{t.multipassCount=o
if(++o<i&&e.data.length<s){s=e.data.length
this._optimizeOnce(e.data,t,l)}else{a.datauri&&(e.data=function(e,t){const r="data:image/svg+xml"
t&&"base64"!==t?"enc"===t?e=r+","+encodeURIComponent(e):"unenc"===t&&(e=r+","+e):e=r+";base64,"+Buffer.from(e).toString("base64")
return e}(e.data,a.datauri))
t&&t.path&&(e.path=t.path)
r(e)}}}
this._optimizeOnce(e,t,l)}))}
Ge.prototype._optimizeOnce=function(e,t,r){const n=this.config
!function(e,t){const r=te().parser(xe.strict,xe)
const n=new ie({elem:"#document",content:[]})
let a=n
const i=[n]
let o=null
let s=!1
function l(e){e=new ie(e,a);(a.content=a.content||[]).push(e)
return e}r.ondoctype=function(t){l({doctype:t})
const n=t.indexOf("[")
let a
if(n>=0){Se.lastIndex=n
for(;null!=(a=Se.exec(e));)r.ENTITIES[a[1]]=a[2]||a[3]}}
r.onprocessinginstruction=function(e){l({processinginstruction:e})}
r.oncomment=function(e){l({comment:e.trim()})}
r.oncdata=function(e){l({cdata:e})}
r.onopentag=function(e){let t={elem:e.name,prefix:e.prefix,local:e.local,attrs:{}}
t.class=new oe(t)
t.style=new be(t)
if(Object.keys(e.attributes).length)for(const r in e.attributes){"class"===r&&t.class.hasClass()
"style"===r&&t.style.hasStyle()
t.attrs[r]={name:r,value:e.attributes[r].value,prefix:e.attributes[r].prefix,local:e.attributes[r].local}}t=l(t)
a=t
"text"!==e.name||e.prefix||(o=a)
i.push(t)}
r.ontext=function(e){if(/\S/.test(e)||o){o||(e=e.trim())
l({text:e})}}
r.onclosetag=function(){if(i.pop()===o){!function(e){if(!e.content)return e
let t=e.content[0]
let r=e.content[e.content.length-1]
for(;t&&t.content&&!t.text;)t=t.content[0]
t&&t.text&&(t.text=t.text.replace(/^\s+/,""))
for(;r&&r.content&&!r.text;)r=r.content[r.content.length-1]
r&&r.text&&(r.text=r.text.replace(/\s+$/,""))}(o)
o=null}a=i[i.length-1]}
r.onerror=function(e){e.message="Error in parsing SVG: "+e.message
if(e.message.indexOf("Unexpected end")<0)throw e}
r.onend=function(){this.error?t({error:this.error.message}):t(n)}
try{r.write(e)}catch(e){t({error:e.message})
s=!0}s||r.close()}(e,(function(e){if(e.error)r(e)
else{e=function(e,t,r){r.forEach((function(r){switch(r[0].type){case"perItem":e=ke(e,t,r)
break
case"perItemReverse":e=ke(e,t,r,!0)
break
case"full":e=function(e,t,r){r.forEach((function(r){r.active&&(e=r.fn(e,r.params,t))}))
return e}(e,t,r)}}))
return e}(e,t,n.plugins)
r(function(e,t){return new Ie(t).convert(e)}(e,n.js2svg))}}))}
Ge.prototype.createContentItem=function(e){return new ie(e)}
const Fe="cleanupAttrs"
const Ve="perItem"
const je=!0
const Ue="cleanups attributes from newlines, trailing and repeating spaces"
const He={newlines:!0,trim:!0,spaces:!0}
const Ye=/(\S)\r?\n(\S)/g
const Xe=/\r?\n/g
const Ke=/\s{2,}/g
const Qe=function(e,t){e.isElem()&&e.eachAttr((function(e){if(t.newlines){e.value=e.value.replace(Ye,(function(e,t,r){return t+" "+r}))
e.value=e.value.replace(Xe,"")}t.trim&&(e.value=e.value.trim())
t.spaces&&(e.value=e.value.replace(Ke," "))}))}
const Ze="cleanupEnableBackground"
const $e="full"
const Je=!0
const et="remove or cleanup enable-background attribute when possible"
const tt={}
const rt=function(e){const t=/^new\s0\s0\s([-+]?\d*\.?\d+([eE][-+]?\d+)?)\s([-+]?\d*\.?\d+([eE][-+]?\d+)?)$/
const r=["svg","mask","pattern"]
let n=!1
function a(e,t){e.content.forEach((function(e){t(e)
e.content&&a(e,t)}))
return e}const i=a(e,(function(e){!function(e){if(e.isElem(r)&&e.hasAttr("enable-background")&&e.hasAttr("width")&&e.hasAttr("height")){const r=e.attr("enable-background").value.match(t)
r&&e.attr("width").value===r[1]&&e.attr("height").value===r[3]&&(e.isElem("svg")?e.removeAttr("enable-background"):e.attr("enable-background").value="new")}}(e)
n||function(e){e.isElem("filter")&&(n=!0)}(e)}))
return n?i:a(i,(function(e){e.removeAttr("enable-background")}))}
const nt=new Set(Oe)
const at="cleanupIDs"
const it="full"
const ot=!0
const st="removes unused IDs and minifies used"
const lt={remove:!0,minify:!0,prefix:"",preserve:[],preservePrefixes:[],force:!1}
const ct=/\burl\(("|')?#(.+?)\1\)/
const dt=/^#(.+?)$/
const ut=/(\w+)\./
const pt=["style","script"]
const mt=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
const ft=mt.length-1
const ht=function(e,t){let r
let n
const a=new Map
const i=new Map
let o=!1
const s=new Set(Array.isArray(t.preserve)?t.preserve:t.preserve?[t.preserve]:[])
const l=new Set(Array.isArray(t.preservePrefixes)?t.preservePrefixes:t.preservePrefixes?[t.preservePrefixes]:[])
e=function e(r){for(let n=0;n<r.content.length&&!o;n++){const s=r.content[n]
if(!t.force){const e=Boolean(s.content)
if(s.isElem(pt)&&e){o=!0
continue}if(s.isElem("svg")){let e=!0
for(let t=0;t<s.content.length;t++)if(!s.content[t].isElem("defs")){e=!1
break}if(e)break}}s.isElem()&&s.eachAttr((function(e){let t
let r
if("id"!==e.name){nt.has(e.name)&&(r=e.value.match(ct))?t=r[2]:("href"===e.local&&(r=e.value.match(dt))||"begin"===e.name&&(r=e.value.match(ut)))&&(t=r[1])
if(t){const r=i.get(t)||[]
r.push(e)
i.set(t,r)}}else{t=e.value
a.has(t)?s.removeAttr("id"):a.set(t,s)}}))
s.content&&e(s)}return r}(e)
if(o)return e
const c=e=>s.has(e)||function(e,t){if(!t)return!1
for(const r of e)if(t.startsWith(r))return!0
return!1}(l,e)
for(const e of i){const i=e[0]
if(a.has(i)){if(t.minify&&!c(i)){do{n=vt(r=gt(r),t)}while(c(n))
a.get(i).attr("id").value=n
for(const t of e[1])t.value=t.value.includes("#")?t.value.replace("#"+i,"#"+n):t.value.replace(i+".",n+".")}a.delete(i)}}if(t.remove)for(const e of a)c(e[0])||e[1].removeAttr("id")
return e}
function gt(e){if(!e)return[0]
e[e.length-1]++
for(let t=e.length-1;t>0;t--)if(e[t]>ft){e[t]=0
void 0!==e[t-1]&&e[t-1]++}if(e[0]>ft){e[0]=0
e.unshift(0)}return e}function vt(e,t){return t.prefix+e.map((e=>mt[e])).join("")}const yt="cleanupNumericValues"
const bt="perItem"
const St=!0
const xt="rounds numeric values to the fixed precision, removes default ‘px’ units"
const kt={floatPrecision:3,leadingZero:!0,defaultPx:!0,convertToPx:!0}
const wt=/^([-+]?\d*\.?\d+([eE][-+]?\d+)?)(px|pt|pc|mm|cm|m|in|ft|em|ex|%)?$/
const Ct={cm:96/2.54,mm:96/25.4,in:96,pt:4/3,pc:16}
const Tt=function(e,t){if(e.isElem()){const r=t.floatPrecision
if(e.hasAttr("viewBox")){const t=e.attr("viewBox").value.split(/\s,?\s*|,\s*/g)
e.attr("viewBox").value=t.map((function(e){const t=+e
return isNaN(t)?e:+t.toFixed(r)})).join(" ")}e.eachAttr((function(e){if("version"===e.name)return
const n=e.value.match(wt)
if(n){let a=+(+n[1]).toFixed(r)
let i=n[3]||""
if(t.convertToPx&&i&&i in Ct){const e=+(Ct[i]*n[1]).toFixed(r)
if(String(e).length<n[0].length){a=e
i="px"}}t.leadingZero&&(a=Ne(a))
t.defaultPx&&"px"===i&&(i="")
e.value=a+i}}))}}
const At=we.animation
const Et="collapseGroups"
const Ot="perItemReverse"
const zt=!0
const _t="collapses useless groups"
const Pt={}
function qt(e){return e.isElem(At)&&e.hasAttr("attributeName",this)||!e.isEmpty()&&e.content.some(qt,this)}const Lt=function(e){!e.isElem()||e.isElem("switch")||e.isEmpty()||e.content.forEach((function(t,r){if(t.isElem("g")&&!t.isEmpty()){if(t.hasAttr()&&1===t.content.length){const e=t.content[0]
!e.isElem()||e.hasAttr("id")||t.hasAttr("filter")||t.hasAttr("class")&&e.hasAttr("class")||(t.hasAttr("clip-path")||t.hasAttr("mask"))&&(!e.isElem("g")||t.hasAttr("transform")||e.hasAttr("transform"))||t.eachAttr((function(r){if(!t.content.some(qt,r.name)){if(e.hasAttr(r.name)){if("transform"===r.name)e.attr(r.name).value=r.value+" "+e.attr(r.name).value
else if(e.hasAttr(r.name,"inherit"))e.attr(r.name).value=r.value
else if(ze.indexOf(r.name)<0&&!e.hasAttr(r.name,r.value))return}else e.addAttr(r)
t.removeAttr(r.name)}}))}t.hasAttr()||t.content.some((function(e){return e.isElem(At)}))||e.spliceContent(r,1,t.content)}}))}
const Wt="convertColors"
const Bt="perItem"
const Mt=!0
const Rt="converts colors: rgb() to #rrggbb and #rrggbb to #rgb"
const It={currentColor:!1,names2hex:!0,rgb2hex:!0,shorthex:!0,shortname:!0}
const Dt="([+-]?(?:\\d*\\.\\d+|\\d+\\.?)%?)"
const Nt="\\s*,\\s*"
const Gt=new RegExp("^rgb\\(\\s*"+Dt+Nt+Dt+Nt+Dt+"\\s*\\)$")
const Ft=/^#(([a-fA-F0-9])\2){3}$/
const Vt=/\bnone\b/i
const jt=function(e,t){e.elem&&e.eachAttr((function(e){if(Le.indexOf(e.name)>-1){let n=e.value
let a
if(t.currentColor){a="string"==typeof t.currentColor?n===t.currentColor:t.currentColor.exec?t.currentColor.exec(n):!n.match(Vt)
a&&(n="currentColor")}t.names2hex&&n.toLowerCase()in Pe&&(n=Pe[n.toLowerCase()])
if(t.rgb2hex&&(a=n.match(Gt))){a=a.slice(1,4).map((function(e){e.indexOf("%")>-1&&(e=Math.round(2.55*parseFloat(e)))
return Math.max(0,Math.min(e,255))}))
n="#"+("00000"+((r=a)[0]<<16|r[1]<<8|r[2]).toString(16)).slice(-6).toUpperCase()}t.shorthex&&(a=n.match(Ft))&&(n="#"+a[0][1]+a[0][3]+a[0][5])
if(t.shortname){const e=n.toLowerCase()
e in qe&&(n=qe[e])}e.value=n}var r}))}
const Ut="convertEllipseToCircle"
const Ht="perItem"
const Yt=!0
const Xt="converts non-eccentric <ellipse>s to <circle>s"
const Kt={}
const Qt={value:0}
const Zt=function(e){if(e.isElem("ellipse")){const t=(e.attr("rx")||Qt).value||0
const r=(e.attr("ry")||Qt).value||0
if(t===r||"auto"===t||"auto"===r){const n="auto"!==t?t:r
e.renameElem("circle")
e.removeAttr(["rx","ry"])
e.addAttr({name:"r",value:n,prefix:"",local:"r"})}}}
const $t=/matrix|translate|scale|rotate|skewX|skewY/
const Jt=/\s*(matrix|translate|scale|rotate|skewX|skewY)\s*\(\s*(.+?)\s*\)[\s,]*/
const er=/[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g
const tr=function(e){const t=[]
let r
e.split(Jt).forEach((function(e){let n
if(e)if($t.test(e))t.push(r={name:e})
else for(;n=er.exec(e);){n=Number(n)
r.data?r.data.push(n):r.data=[n]}}))
return r&&r.data?t:[]}
const rr=function(e){return{name:"matrix",data:(e=e.map((function(e){return"matrix"===e.name?e.data:function(e){if("matrix"===e.name)return e.data
let t
switch(e.name){case"translate":t=[1,0,0,1,e.data[0],e.data[1]||0]
break
case"scale":t=[e.data[0],0,0,e.data[1]||e.data[0],0,0]
break
case"rotate":{const r=nr.cos(e.data[0])
const n=nr.sin(e.data[0])
const a=e.data[1]||0
const i=e.data[2]||0
t=[r,n,-n,r,(1-r)*a+n*i,(1-r)*i-n*a]
break}case"skewX":t=[1,0,nr.tan(e.data[0]),1,0,0]
break
case"skewY":t=[1,nr.tan(e.data[0]),0,1,0,0]}return t}(e)}))).length>0?e.reduce(ir):[]}}
const nr={rad:function(e){return e*Math.PI/180},deg:function(e){return 180*e/Math.PI},cos:function(e){return Math.cos(this.rad(e))},acos:function(e,t){return+this.deg(Math.acos(e)).toFixed(t)},sin:function(e){return Math.sin(this.rad(e))},asin:function(e,t){return+this.deg(Math.asin(e)).toFixed(t)},tan:function(e){return Math.tan(this.rad(e))},atan:function(e,t){return+this.deg(Math.atan(e)).toFixed(t)}}
const ar=function(e,t){const r=t.floatPrecision
const n=e.data
const a=[]
let i=+Math.hypot(n[0],n[1]).toFixed(t.transformPrecision)
let o=+((n[0]*n[3]-n[1]*n[2])/i).toFixed(t.transformPrecision)
const s=n[0]*n[2]+n[1]*n[3]
const l=n[0]*n[1]+n[2]*n[3]
const c=0!==l||i===o;(n[4]||n[5])&&a.push({name:"translate",data:n.slice(4,n[5]?6:5)})
if(!n[1]&&n[2])a.push({name:"skewX",data:[nr.atan(n[2]/o,r)]})
else if(n[1]&&!n[2]){a.push({name:"skewY",data:[nr.atan(n[1]/n[0],r)]})
i=n[0]
o=n[3]}else if(!s||1===i&&1===o||!c){if(!c){i=(n[0]<0?-1:1)*Math.hypot(n[0],n[2])
o=(n[3]<0?-1:1)*Math.hypot(n[1],n[3])
a.push({name:"scale",data:[i,o]})}const e=Math.min(Math.max(-1,n[0]/i),1)
const t=[nr.acos(e,r)*((c?1:o)*n[1]<0?-1:1)]
t[0]&&a.push({name:"rotate",data:t})
l&&s&&a.push({name:"skewX",data:[nr.atan(s/(i*i),r)]})
if(t[0]&&(n[4]||n[5])){a.shift()
const e=n[0]/i
const r=n[1]/(c?i:o)
const s=n[4]*(c||o)
const l=n[5]*(c||i)
const d=(Math.pow(1-e,2)+Math.pow(r,2))*(c||i*o)
t.push(((1-e)*s-r*l)/d)
t.push(((1-e)*l+r*s)/d)}}else if(n[1]||n[2])return e;(!c||1===i&&1===o)&&a.length||a.push({name:"scale",data:i===o?[i]:[i,o]})
return a}
function ir(e,t){return[e[0]*t[0]+e[2]*t[1],e[1]*t[0]+e[3]*t[1],e[0]*t[2]+e[2]*t[3],e[1]*t[2]+e[3]*t[3],e[0]*t[4]+e[2]*t[5]+e[4],e[1]*t[4]+e[3]*t[5]+e[5]]}const or=Ae.presentation["stroke-width"]
const sr=String.raw`[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?\s*`
const lr=String.raw`(?:\s,?\s*|,\s*)`
const cr=`(${sr})`+lr
const dr=`([01])${lr}?`
const ur=String.raw`(${sr})${lr}?(${sr})`
const pr=(cr+"?").repeat(2)+cr+dr.repeat(2)+ur
const mr=/([MmLlHhVvCcSsQqTtAaZz])\s*/
const fr=new RegExp(sr,"g")
const hr=new RegExp(pr,"g")
const gr=/[-+]?(\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/
const vr=function(e){if(e.pathJS)return e.pathJS
const t={H:1,V:1,M:2,L:2,T:2,Q:4,S:4,C:6,A:7,h:1,v:1,m:2,l:2,t:2,q:4,s:4,c:6,a:7}
const r=[]
let n
let a=!1
e.attr("d").value.split(mr).forEach((function(e){if(e){if(!a){if("M"!==e&&"m"!==e)return
a=!0}if(mr.test(e)){n=e
"Z"!==n&&"z"!==n||r.push({instruction:"z"})}else{if("A"===n||"a"===n){const t=[]
for(let r;r=hr.exec(e);)for(let e=1;e<r.length;e++)t.push(r[e])
e=t}else e=e.match(fr)
if(!e)return
e=e.map(Number)
if("M"===n||"m"===n){r.push({instruction:0===r.length?"M":n,data:e.splice(0,2)})
n="M"===n?"L":"l"}for(const a=t[n];e.length;)r.push({instruction:n,data:e.splice(0,a)})}}}))
r.length&&"m"===r[0].instruction&&(r[0].instruction="M")
e.pathJS=r
return r}
const yr=function(e){const t=[0,0]
const r=[0,0]
let n
return e.map((function(e){const a=e.instruction
const i=e.data&&e.data.slice()
if("M"===a){xr(t,i)
xr(r,i)}else if("mlcsqt".indexOf(a)>-1){for(n=0;n<i.length;n++)i[n]+=t[n%2]
xr(t,i)
"m"===a&&xr(r,i)}else if("a"===a){i[5]+=t[0]
i[6]+=t[1]
xr(t,i)}else if("h"===a){i[0]+=t[0]
t[0]=i[0]}else if("v"===a){i[0]+=t[1]
t[1]=i[0]}else"MZLCSQTA".indexOf(a)>-1?xr(t,i):"H"===a?t[0]=i[0]:"V"===a?t[1]=i[0]:"z"===a&&xr(t,r)
return"z"===a?{instruction:"z"}:{instruction:a.toUpperCase(),data:i}}))}
function br(e,t,r){return[e[0]*t+e[2]*r+e[4],e[1]*t+e[3]*r+e[5]]}const Sr=function(e,t,r){e.pathJS=t
r.collapseRepeated&&(t=function(e){let t
let r
return e.reduce((function(e,n){if(t&&n.data&&n.instruction===t.instruction)if("M"!==n.instruction)t=e[r]={instruction:t.instruction,data:t.data.concat(n.data),coords:n.coords,base:t.base}
else{t.data=n.data
t.coords=n.coords}else{e.push(n)
t=n
r=e.length-1}return e}),[])}(t))
e.attr("d").value=t.reduce((function(e,t){let n=""
t.data&&(n=De(t.data,r,t.instruction))
return e+(t.instruction+n)}),"")}
function xr(e,t){e[0]=t[t.length-2]
e[1]=t[t.length-1]
return e}const kr=function(e,t){if(e.length<3||t.length<3)return!1
const r=yr(e).reduce(zr,[])
const n=yr(t).reduce(zr,[])
if(r.maxX<=n.minX||n.maxX<=r.minX||r.maxY<=n.minY||n.maxY<=r.minY||r.every((function(e){return n.every((function(t){return e[e.maxX][0]<=t[t.minX][0]||t[t.maxX][0]<=e[e.minX][0]||e[e.maxY][1]<=t[t.minY][1]||t[t.maxY][1]<=e[e.minY][1]}))})))return!1
const a=r.map(_r)
const i=n.map(_r)
return a.some((function(e){return!(e.length<3)&&i.some((function(t){if(t.length<3)return!1
const r=[o(e,t,[1,0])]
const n=Cr(r[0])
let a=1e4
for(;;){if(0==a--){console.error("Error: infinite loop while processing mergePaths plugin.")
return!0}r.push(o(e,t,n))
if(Ar(n,r[r.length-1])<=0)return!1
if(wr(r,n))return!0}}))}))
function o(e,t,r){return Tr(s(e,r),s(t,Cr(r)))}function s(e,t){let r=t[1]>=0?t[0]<0?e.maxY:e.maxX:t[0]<0?e.minX:e.minY
let n=-1/0
let a
for(;(a=Ar(e[r],t))>n;){n=a
r=++r%e.length}return e[(r||e.length)-1]}}
function wr(e,t){if(2===e.length){const r=e[1]
const n=e[0]
const a=Cr(e[1])
const i=Tr(n,r)
if(Ar(a,i)>0)xr(t,Er(i,r))
else{xr(t,a)
e.shift()}}else{const r=e[2]
const n=e[1]
const a=e[0]
const i=Tr(n,r)
const o=Tr(a,r)
const s=Cr(r)
const l=Er(i,o)
const c=Er(o,i)
if(Ar(l,s)>0)if(Ar(i,s)>0){xr(t,l)
e.shift()}else{xr(t,s)
e.splice(0,2)}else{if(!(Ar(c,s)>0))return!0
if(Ar(o,s)>0){xr(t,c)
e.splice(1,1)}else{xr(t,s)
e.splice(0,2)}}}return!1}function Cr(e){return[-e[0],-e[1]]}function Tr(e,t){return[e[0]-t[0],e[1]-t[1]]}function Ar(e,t){return e[0]*t[0]+e[1]*t[1]}function Er(e,t){const r=[-e[1],e[0]]
return Ar(r,Cr(t))<0?Cr(r):r}let Or
function zr(e,t,r,n){let a=e.length&&e[e.length-1]
const i=r&&n[r-1]
let o=a.length&&a[a.length-1]
const s=t.data
let l=o
switch(t.instruction){case"M":e.push(a=[])
break
case"H":d(a,[s[0],o[1]])
break
case"V":d(a,[o[0],s[0]])
break
case"Q":d(a,s.slice(0,2))
Or=[s[2]-s[0],s[3]-s[1]]
break
case"T":if("Q"===i.instruction||"T"===i.instruction){l=[o[0]+Or[0],o[1]+Or[1]]
d(a,l)
Or=[s[0]-l[0],s[1]-l[1]]}break
case"C":d(a,[.5*(o[0]+s[0]),.5*(o[1]+s[1])])
d(a,[.5*(s[0]+s[2]),.5*(s[1]+s[3])])
d(a,[.5*(s[2]+s[4]),.5*(s[3]+s[5])])
Or=[s[4]-s[2],s[5]-s[3]]
break
case"S":if("C"===i.instruction||"S"===i.instruction){d(a,[o[0]+.5*Or[0],o[1]+.5*Or[1]])
l=[o[0]+Or[0],o[1]+Or[1]]}d(a,[.5*(l[0]+s[0]),.5*(l[1]+s[1])])
d(a,[.5*(s[0]+s[2]),.5*(s[1]+s[3])])
Or=[s[2]-s[0],s[3]-s[1]]
break
case"A":{const e=qr.apply(0,o.concat(s))
for(let t;(t=e.splice(0,6).map(c)).length;){d(a,[.5*(o[0]+t[0]),.5*(o[1]+t[1])])
d(a,[.5*(t[0]+t[2]),.5*(t[1]+t[3])])
d(a,[.5*(t[2]+t[4]),.5*(t[3]+t[5])])
e.length&&d(a,o=t.slice(-2))}break}}s&&s.length>=2&&d(a,s.slice(-2))
return e
function c(e,t){return e+o[t%2]}function d(t,r){if(!t.length||r[1]>t[t.maxY][1]){t.maxY=t.length
e.maxY=e.length?Math.max(r[1],e.maxY):r[1]}if(!t.length||r[0]>t[t.maxX][0]){t.maxX=t.length
e.maxX=e.length?Math.max(r[0],e.maxX):r[0]}if(!t.length||r[1]<t[t.minY][1]){t.minY=t.length
e.minY=e.length?Math.min(r[1],e.minY):r[1]}if(!t.length||r[0]<t[t.minX][0]){t.minX=t.length
e.minX=e.length?Math.min(r[0],e.minX):r[0]}t.push(r)}}function _r(e){e.sort((function(e,t){return e[0]===t[0]?e[1]-t[1]:e[0]-t[0]}))
const t=[]
let r=0
let n=0
for(let a=0;a<e.length;a++){for(;t.length>=2&&Pr(t[t.length-2],t[t.length-1],e[a])<=0;)t.pop()
if(e[a][1]<e[r][1]){r=a
n=t.length}t.push(e[a])}const a=[]
let i=e.length-1
let o=0
for(let t=e.length;t--;){for(;a.length>=2&&Pr(a[a.length-2],a[a.length-1],e[t])<=0;)a.pop()
if(e[t][1]>e[i][1]){i=t
o=a.length}a.push(e[t])}a.pop()
t.pop()
const s=t.concat(a)
s.minX=0
s.maxX=t.length
s.minY=n
s.maxY=(t.length+o)%s.length
return s}function Pr(e,t,r){return(t[0]-e[0])*(r[1]-e[1])-(t[1]-e[1])*(r[0]-e[0])}function qr(e,t,r,n,a,i,o,s,l,c){const d=120*Math.PI/180
const u=Math.PI/180*(+a||0)
let p=[]
let m
let f
let h
let g
const v=function(e,t,r){return e*Math.cos(r)-t*Math.sin(r)}
const y=function(e,t,r){return e*Math.sin(r)+t*Math.cos(r)}
if(c){h=c[0]
g=c[1]
f=c[2]
m=c[3]}else{t=y(e=v(e,t,-u),t,-u)
const a=(e-(s=v(s,l,-u)))/2
const c=(t-(l=y(s,l,-u)))/2
let d=a*a/(r*r)+c*c/(n*n)
if(d>1){d=Math.sqrt(d)
r*=d
n*=d}const p=r*r
const b=n*n
const S=(i===o?-1:1)*Math.sqrt(Math.abs((p*b-p*c*c-b*a*a)/(p*c*c+b*a*a)))
f=S*r*c/n+(e+s)/2
m=S*-n*a/r+(t+l)/2
h=Math.asin(((t-m)/n).toFixed(9))
g=Math.asin(((l-m)/n).toFixed(9))
h=e<f?Math.PI-h:h
g=s<f?Math.PI-g:g
h<0&&(h=2*Math.PI+h)
g<0&&(g=2*Math.PI+g)
o&&h>g&&(h-=2*Math.PI)
!o&&g>h&&(g-=2*Math.PI)}let b=g-h
if(Math.abs(b)>d){const e=g
const t=s
const i=l
g=h+d*(o&&g>h?1:-1)
p=qr(s=f+r*Math.cos(g),l=m+n*Math.sin(g),r,n,a,0,o,t,i,[g,e,f,m])}b=g-h
const S=Math.cos(h)
const x=Math.sin(h)
const k=Math.cos(g)
const w=Math.sin(g)
const C=Math.tan(b/4)
const T=4/3*r*C
const A=4/3*n*C
const E=[-T*x,A*S,s+T*w-e,l-A*k-t,s-e,l-t]
if(c)return E.concat(p)
{p=E.concat(p)
const e=[]
for(let t=0,r=p.length;t<r;t++)e[t]=t%2?y(p[t-1],p[t],u):v(p[t],p[t+1],u)
return e}}const Lr="convertPathData"
const Wr="perItem"
const Br=!0
const Mr="optimizes path data: writes in shorter form, applies transformations"
const Rr={applyTransforms:!0,applyTransformsStroked:!0,makeArcs:{threshold:2.5,tolerance:.5},straightCurves:!0,lineShorthands:!0,curveSmoothShorthands:!0,floatPrecision:3,transformPrecision:5,removeUseless:!0,collapseRepeated:!0,utilizeAbsolute:!0,leadingZero:!0,negativeExtraSpace:!0,noSpaceAfterFlags:!0,forceAbsolutePath:!1}
let Ir
let Dr
let Nr
let Gr
let Fr
let Vr
let jr
const Ur=function(e,t){if(e.isElem(Ce)&&e.hasAttr("d")){Dr=t.floatPrecision
Nr=!1!==Dr?+Math.pow(.1,Dr).toFixed(Dr):.01
Ir=Dr>0&&Dr<20?Xr:Kr
if(t.makeArcs){Gr=t.makeArcs.threshold
Fr=t.makeArcs.tolerance}Vr=e.hasAttr("marker-mid")
const r=e.computedAttr("stroke")
const n=e.computedAttr("stroke")
jr=r&&"none"!==r&&n&&"butt"!==n
let a=vr(e)
if(a.length){!function(e){const t=[0,0]
const r=[0,0]
let n
e.forEach((function(a,i){let o=a.instruction
const s=a.data
if(s){if("mcslqta".indexOf(o)>-1){t[0]+=s[s.length-2]
t[1]+=s[s.length-1]
if("m"===o){r[0]=t[0]
r[1]=t[1]
n=a}}else"h"===o?t[0]+=s[0]:"v"===o&&(t[1]+=s[0])
if("M"===o){i>0&&(o="m")
s[0]-=t[0]
s[1]-=t[1]
r[0]=t[0]+=s[0]
r[1]=t[1]+=s[1]
n=a}else if("LT".indexOf(o)>-1){o=o.toLowerCase()
s[0]-=t[0]
s[1]-=t[1]
t[0]+=s[0]
t[1]+=s[1]}else if("C"===o){o="c"
s[0]-=t[0]
s[1]-=t[1]
s[2]-=t[0]
s[3]-=t[1]
s[4]-=t[0]
s[5]-=t[1]
t[0]+=s[4]
t[1]+=s[5]}else if("SQ".indexOf(o)>-1){o=o.toLowerCase()
s[0]-=t[0]
s[1]-=t[1]
s[2]-=t[0]
s[3]-=t[1]
t[0]+=s[2]
t[1]+=s[3]}else if("A"===o){o="a"
s[5]-=t[0]
s[6]-=t[1]
t[0]+=s[5]
t[1]+=s[6]}else if("H"===o){o="h"
s[0]-=t[0]
t[0]+=s[0]}else if("V"===o){o="v"
s[0]-=t[1]
t[1]+=s[0]}a.instruction=o
a.data=s
a.coords=t.slice(-2)}else if("z"===o){n&&(a.coords=n.coords)
t[0]=r[0]
t[1]=r[1]}a.base=i>0?e[i-1].coords:[0,0]}))}(a)
t.applyTransforms&&(a=function(e,t,r){if(!e.hasAttr("transform")||!e.attr("transform").value||e.someAttr((function(e){return~Oe.indexOf(e.name)&&~e.value.indexOf("url(")})))return t
const n=rr(tr(e.attr("transform").value))
const a=e.computedAttr("stroke")
const i=e.computedAttr("id")
const o=r.transformPrecision
let s
let l
if(a&&"none"!==a){if(!r.applyTransformsStroked||(n.data[0]!==n.data[3]||n.data[1]!==-n.data[2])&&(n.data[0]!==-n.data[3]||n.data[1]!==n.data[2]))return t
if(i){let r=e
let n=!1
do{r.hasAttr("stroke-width")&&(n=!0)}while(!r.hasAttr("id",i)&&!n&&(r=r.parentNode))
if(!n)return t}l=+Math.sqrt(n.data[0]*n.data[0]+n.data[1]*n.data[1]).toFixed(o)
if(1!==l){const t=e.computedAttr("stroke-width")||or
e.hasAttr("vector-effect")&&"non-scaling-stroke"===e.attr("vector-effect").value||(e.hasAttr("stroke-width")?e.attrs["stroke-width"].value=e.attrs["stroke-width"].value.trim().replace(gr,(function(e){return Ne(e*l)})):e.addAttr({name:"stroke-width",prefix:"",local:"stroke-width",value:t.replace(gr,(function(e){return Ne(e*l)}))}))}}else if(i)return t
t.forEach((function(e){if(e.data){if("h"===e.instruction){e.instruction="l"
e.data[1]=0}else if("v"===e.instruction){e.instruction="l"
e.data[1]=e.data[0]
e.data[0]=0}if("M"!==e.instruction||0===n.data[4]&&0===n.data[5]){if("a"===e.instruction){!function(e,t){let r=e[0]
let n=e[1]
const a=e[2]*Math.PI/180
const i=Math.cos(a)
const o=Math.sin(a)
let s=Math.pow(e[5]*i+e[6]*o,2)/(4*r*r)+Math.pow(e[6]*i-e[5]*o,2)/(4*n*n)
if(s>1){s=Math.sqrt(s)
r*=s
n*=s}const l=ir(t,[r*i,r*o,-n*o,n*i,0,0])
const c=l[2]*l[2]+l[3]*l[3]
const d=l[0]*l[0]+l[1]*l[1]+c
const u=Math.hypot(l[0]-l[3],l[1]+l[2])*Math.hypot(l[0]+l[3],l[1]-l[2])
if(u){const t=(d+u)/2
const r=(d-u)/2
const n=Math.abs(t-c)>1e-6
const a=(n?t:r)-c
const i=l[0]*l[2]+l[1]*l[3]
const o=l[0]*a+l[2]*i
const s=l[1]*a+l[3]*i
e[0]=Math.sqrt(t)
e[1]=Math.sqrt(r)
e[2]=((n?s<0:o>0)?-1:1)*Math.acos((n?o:s)/Math.hypot(o,s))*180/Math.PI}else{e[0]=e[1]=Math.sqrt(d/2)
e[2]=0}t[0]<0!=t[3]<0&&(e[4]=1-e[4])}(e.data,n.data)
if(Math.abs(e.data[2])>80){const t=e.data[0]
const r=e.data[2]
e.data[0]=e.data[1]
e.data[1]=t
e.data[2]=r+(r>0?-90:90)}s=br(n.data,e.data[5],e.data[6])
e.data[5]=s[0]
e.data[6]=s[1]}else for(let t=0;t<e.data.length;t+=2){s=br(n.data,e.data[t],e.data[t+1])
e.data[t]=s[0]
e.data[t+1]=s[1]}e.coords[0]=e.base[0]+e.data[e.data.length-2]
e.coords[1]=e.base[1]+e.data[e.data.length-1]}else{s=br(n.data,e.data[0],e.data[1])
xr(e.data,s)
xr(e.coords,s)
n.data[4]=0
n.data[5]=0}}}))
e.removeAttr("transform")
return t}(e,a,t))
a=function(e,t){const r=nn.bind(null,t)
const n=[0,0]
const a=[0,0]
let i={}
return e.filter((function(e,o,s){let l=e.instruction
let c=e.data
let d=s[o+1]
if(c){let u=c
let p
if("s"===l){u=[0,0].concat(c)
if("cs".indexOf(i.instruction)>-1){const e=i.data
const t=e.length
u[0]=e[t-2]-e[t-4]
u[1]=e[t-1]-e[t-3]}}if(t.makeArcs&&("c"===l||"s"===l)&&Hr(u)&&(p=function(e){const t=Jr(e,.5)
const r=[t[0]/2,t[1]/2]
const n=[(t[0]+e[4])/2,(t[1]+e[5])/2]
const a=Yr([r[0],r[1],r[0]+r[1],r[1]-r[0],n[0],n[1],n[0]+(n[1]-t[1]),n[1]-(n[0]-t[0])])
const i=a&&$r([0,0],a)
const o=Math.min(Gr*Nr,Fr*i/100)
if(a&&i<1e15&&[1/4,3/4].every((function(t){return Math.abs($r(Jr(e,t),a)-i)<=o})))return{center:a,radius:i}}(u))){let t
const a=Ir([p.radius])[0]
let m=rn(u,p)
const f=u[5]*u[0]-u[4]*u[1]>0?1:0
let h={instruction:"a",data:[a,a,0,0,f,u[4],u[5]],coords:e.coords.slice(),base:e.base}
const g=[h]
const v=[p.center[0]-u[4],p.center[1]-u[5]]
const y={center:v,radius:p.radius}
const b=[e]
let S=0
let x=""
let k
if("c"===i.instruction&&Hr(i.data)&&tn(i.data,p)||"a"===i.instruction&&i.sdata&&tn(i.sdata,p)){b.unshift(i)
h.base=i.base
h.data[5]=h.coords[0]-h.base[0]
h.data[6]=h.coords[1]-h.base[1]
const e="a"===i.instruction?i.sdata:i.data
m+=rn(e,{center:[e[4]+p.center[0],e[5]+p.center[1]],radius:p.radius})
m>Math.PI&&(h.data[3]=1)
S=1}for(t=o;(d=s[++t])&&~"cs".indexOf(d.instruction);){let e=d.data
if("s"===d.instruction){k=Zr({instruction:"s",data:d.data.slice()},s[t-1].data)
e=k.data
k.data=e.slice(0,2)
x=r([k])}if(!Hr(e)||!en(e,y))break
m+=rn(e,y)
if(m-2*Math.PI>.001)break
m>Math.PI&&(h.data[3]=1)
b.push(d)
if(!(2*Math.PI-m>.001)){h.data[5]=2*(y.center[0]-e[4])
h.data[6]=2*(y.center[1]-e[5])
h.coords=[h.base[0]+h.data[5],h.base[1]+h.data[6]]
h={instruction:"a",data:[a,a,0,0,f,d.coords[0]-h.coords[0],d.coords[1]-h.coords[1]],coords:d.coords,base:h.coords}
g.push(h)
t++
break}h.coords=d.coords
h.data[5]=h.coords[0]-h.base[0]
h.data[6]=h.coords[1]-h.base[1]
v[0]-=e[4]
v[1]-=e[5]}if((r(g)+x).length<r(b).length){s[t]&&"s"===s[t].instruction&&Zr(s[t],s[t-1].data)
if(S){const t=g.shift()
Ir(t.data)
n[0]+=t.data[5]-i.data[i.data.length-2]
n[1]+=t.data[6]-i.data[i.data.length-1]
i.instruction="a"
i.data=t.data
e.base=i.coords=t.coords}h=g.shift()
1===b.length?e.sdata=u.slice():b.length-1-S>0&&s.splice.apply(s,[o+1,b.length-1-S].concat(g))
if(!h)return!1
l="a"
c=h.data
e.coords=h.coords}}if(!1!==Dr){if("mltqsc".indexOf(l)>-1)for(let t=c.length;t--;)c[t]+=e.base[t%2]-n[t%2]
else if("h"===l)c[0]+=e.base[0]-n[0]
else if("v"===l)c[0]+=e.base[1]-n[1]
else if("a"===l){c[5]+=e.base[0]-n[0]
c[6]+=e.base[1]-n[1]}Ir(c)
if("h"===l)n[0]+=c[0]
else if("v"===l)n[1]+=c[0]
else{n[0]+=c[c.length-2]
n[1]+=c[c.length-1]}Ir(n)
if("m"===l.toLowerCase()){a[0]=n[0]
a[1]=n[1]}}if(t.straightCurves)if("c"===l&&Qr(c)||"s"===l&&Qr(u)){d&&"s"===d.instruction&&Zr(d,c)
l="l"
c=c.slice(-2)}else if("q"===l&&Qr(c)){d&&"t"===d.instruction&&Zr(d,c)
l="l"
c=c.slice(-2)}else if("t"===l&&"q"!==i.instruction&&"t"!==i.instruction){l="l"
c=c.slice(-2)}else if("a"===l&&(0===c[0]||0===c[1])){l="l"
c=c.slice(-2)}if(t.lineShorthands&&"l"===l)if(0===c[1]){l="h"
c.pop()}else if(0===c[0]){l="v"
c.shift()}if(t.collapseRepeated&&!Vr&&"mhv".indexOf(l)>-1&&i.instruction&&l===i.instruction.toLowerCase()&&("h"!==l&&"v"!==l||i.data[0]>=0==c[0]>=0)){i.data[0]+=c[0]
"h"!==l&&"v"!==l&&(i.data[1]+=c[1])
i.coords=e.coords
s[o]=i
return!1}if(t.curveSmoothShorthands&&i.instruction)if("c"===l){if("c"===i.instruction&&c[0]===-(i.data[2]-i.data[4])&&c[1]===-(i.data[3]-i.data[5])){l="s"
c=c.slice(2)}else if("s"===i.instruction&&c[0]===-(i.data[0]-i.data[2])&&c[1]===-(i.data[1]-i.data[3])){l="s"
c=c.slice(2)}else if(-1==="cs".indexOf(i.instruction)&&0===c[0]&&0===c[1]){l="s"
c=c.slice(2)}}else if("q"===l)if("q"===i.instruction&&c[0]===i.data[2]-i.data[0]&&c[1]===i.data[3]-i.data[1]){l="t"
c=c.slice(2)}else if("t"===i.instruction&&c[2]===i.data[0]&&c[3]===i.data[1]){l="t"
c=c.slice(2)}if(t.removeUseless&&!jr){if("lhvqtcs".indexOf(l)>-1&&c.every((function(e){return 0===e}))){s[o]=i
return!1}if("a"===l&&0===c[5]&&0===c[6]){s[o]=i
return!1}}e.instruction=l
e.data=c
i=e}else{n[0]=a[0]
n[1]=a[1]
if("z"===i.instruction)return!1
i=e}return!0}))}(a,t)
t.utilizeAbsolute&&(a=function(e,t){let r=e[0]
return e.filter((function(e,n){if(0===n)return!0
if(!e.data){r=e
return!0}const a=e.instruction
const i=e.data
const o=i&&i.slice(0)
if("mltqsc".indexOf(a)>-1)for(let t=o.length;t--;)o[t]+=e.base[t%2]
else if("h"===a)o[0]+=e.base[0]
else if("v"===a)o[0]+=e.base[1]
else if("a"===a){o[5]+=e.base[0]
o[6]+=e.base[1]}Ir(o)
const s=De(o,t)
const l=De(i,t)
if(t.forceAbsolutePath||s.length<l.length&&!(t.negativeExtraSpace&&a===r.instruction&&r.instruction.charCodeAt(0)>96&&s.length===l.length-1&&(i[0]<0||/^0\./.test(i[0])&&r.data[r.data.length-1]%1))){e.instruction=a.toUpperCase()
e.data=o}r=e
return!0}))}(a,t))
Sr(e,a,t)}}}
function Hr(e){const t=Yr([0,0,e[2],e[3],e[0],e[1],e[4],e[5]])
return t&&e[2]<t[0]==t[0]<0&&e[3]<t[1]==t[1]<0&&e[4]<t[0]==t[0]<e[0]&&e[5]<t[1]==t[1]<e[1]}function Yr(e){const t=e[1]-e[3]
const r=e[2]-e[0]
const n=e[0]*e[3]-e[2]*e[1]
const a=e[5]-e[7]
const i=e[6]-e[4]
const o=e[4]*e[7]-e[5]*e[6]
const s=t*i-a*r
if(!s)return
const l=[(r*o-i*n)/s,(t*o-a*n)/-s]
return!isNaN(l[0])&&!isNaN(l[1])&&isFinite(l[0])&&isFinite(l[1])?l:void 0}function Xr(e){for(let t=e.length;t-- >0;)if(e[t].toFixed(Dr)!==e[t]){const r=+e[t].toFixed(Dr-1)
e[t]=+Math.abs(r-e[t]).toFixed(Dr+1)>=Nr?+e[t].toFixed(Dr):r}return e}function Kr(e){for(let t=e.length;t-- >0;)e[t]=Math.round(e[t])
return e}function Qr(e){let t=e.length-2
const r=-e[t+1]
const n=e[t]
const a=1/(r*r+n*n)
if(t<=1||!isFinite(a))return!1
for(;(t-=2)>=0;)if(Math.sqrt(Math.pow(r*e[t]+n*e[t+1],2)*a)>Nr)return!1
return!0}function Zr(e,t){switch(e.instruction){case"s":e.instruction="c"
break
case"t":e.instruction="q"}e.data.unshift(t[t.length-2]-t[t.length-4],t[t.length-1]-t[t.length-3])
return e}function $r(e,t){return Math.hypot(e[0]-t[0],e[1]-t[1])}function Jr(e,t){const r=t*t
const n=r*t
const a=1-t
const i=a*a
return[3*i*t*e[0]+3*a*r*e[2]+n*e[4],3*i*t*e[1]+3*a*r*e[3]+n*e[5]]}function en(e,t){const r=Math.min(Gr*Nr,Fr*t.radius/100)
return[0,1/4,.5,3/4,1].every((function(n){return Math.abs($r(Jr(e,n),t.center)-t.radius)<=r}))}function tn(e,t){return en(e,{center:[t.center[0]+e[4],t.center[1]+e[5]],radius:t.radius})}function rn(e,t){const r=-t.center[0]
const n=-t.center[1]
const a=e[4]-t.center[0]
const i=e[5]-t.center[1]
return Math.acos((r*a+n*i)/Math.sqrt((r*r+n*n)*(a*a+i*i)))}function nn(e,t){return t.reduce((function(t,r){let n=""
r.data&&(n=De(Ir(r.data.slice()),e))
return t+r.instruction+n}),"")}const an="convertShapeToPath"
const on="perItem"
const sn=!0
const ln="converts basic shapes to more compact path form"
const cn={convertArcs:!1}
const dn={value:0}
const un=/[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g
const pn=function(e,t){const r=t&&t.convertArcs
if(e.isElem("rect")&&e.hasAttr("width")&&e.hasAttr("height")&&!e.hasAttr("rx")&&!e.hasAttr("ry")){const t=+(e.attr("x")||dn).value
const r=+(e.attr("y")||dn).value
const n=+e.attr("width").value
const a=+e.attr("height").value
if(isNaN(t-r+n-a))return
const i="M"+t+" "+r+"H"+(t+n)+"V"+(r+a)+"H"+t+"z"
e.addAttr({name:"d",value:i,prefix:"",local:"d"})
e.renameElem("path").removeAttr(["x","y","width","height"])}else if(e.isElem("line")){const t=+(e.attr("x1")||dn).value
const r=+(e.attr("y1")||dn).value
const n=+(e.attr("x2")||dn).value
const a=+(e.attr("y2")||dn).value
if(isNaN(t-r+n-a))return
e.addAttr({name:"d",value:"M"+t+" "+r+"L"+n+" "+a,prefix:"",local:"d"})
e.renameElem("path").removeAttr(["x1","y1","x2","y2"])}else if((e.isElem("polyline")||e.isElem("polygon"))&&e.hasAttr("points")){const t=(e.attr("points").value.match(un)||[]).map(Number)
if(t.length<4)return!1
e.addAttr({name:"d",value:"M"+t.slice(0,2).join(" ")+"L"+t.slice(2).join(" ")+(e.isElem("polygon")?"z":""),prefix:"",local:"d"})
e.renameElem("path").removeAttr("points")}else if(e.isElem("circle")&&r){const t=+(e.attr("cx")||dn).value
const r=+(e.attr("cy")||dn).value
const n=+(e.attr("r")||dn).value
if(isNaN(t-r+n))return
const a="M"+t+" "+(r-n)+"A"+n+" "+n+" 0 1 0 "+t+" "+(r+n)+"A"+n+" "+n+" 0 1 0 "+t+" "+(r-n)+"Z"
e.addAttr({name:"d",value:a,prefix:"",local:"d"})
e.renameElem("path").removeAttr(["cx","cy","r"])}else if(e.isElem("ellipse")&&r){const t=+(e.attr("cx")||dn).value
const r=+(e.attr("cy")||dn).value
const n=+(e.attr("rx")||dn).value
const a=+(e.attr("ry")||dn).value
if(isNaN(t-r+n-a))return
const i="M"+t+" "+(r-a)+"A"+n+" "+a+" 0 1 0 "+t+" "+(r+a)+"A"+n+" "+a+" 0 1 0 "+t+" "+(r-a)+"Z"
e.addAttr({name:"d",value:i,prefix:"",local:"d"})
e.renameElem("path").removeAttr(["cx","cy","rx","ry"])}}
const mn=Te.presentation
const fn="convertStyleToAttrs"
const hn="perItem"
const gn=!0
const vn="converts style to attributes"
const yn={keepImportant:!1}
const bn="\\\\(?:[0-9a-f]{1,6}\\s?|\\r\\n|.)"
const Sn="\\s*("+zn("[^:;\\\\]",bn)+"*?)\\s*"
const xn="'(?:[^'\\n\\r\\\\]|"+bn+")*?(?:'|$)"
const kn='"(?:[^"\\n\\r\\\\]|'+bn+')*?(?:"|$)'
const wn=new RegExp("^"+zn(xn,kn)+"$")
const Cn="\\("+zn("[^'\"()\\\\]+",bn,xn,kn)+"*?\\)"
const Tn="\\s*("+zn("[^!'\"();\\\\]+?",bn,xn,kn,Cn,"[^;]*?")+"*?)"
const An=new RegExp(Sn+":"+Tn+"(\\s*!important(?![-(\\w]))?\\s*(?:;\\s*|$)","ig")
const En=new RegExp(zn(bn,xn,kn,"/\\*[^]*?\\*/"),"ig")
const On=function(e,t){if(e.elem&&e.hasAttr("style")){let r=e.attr("style").value
let n=[]
const a={}
r=r.replace(En,(function(e){return"/"===e[0]?"":"\\"===e[0]&&/[-g-z]/i.test(e[1])?e[1]:e}))
An.lastIndex=0
for(let e;e=An.exec(r);)t.keepImportant&&e[3]||n.push([e[1],e[2]])
if(n.length){n=n.filter((function(e){if(e[0]){const t=e[0].toLowerCase()
let r=e[1]
wn.test(r)&&(r=r.slice(1,-1))
if(mn.indexOf(t)>-1){a[t]={name:t,value:r,local:t,prefix:""}
return!1}}return!0}))
Object.assign(e.attrs,a)
n.length?e.attr("style").value=n.map((function(e){return e.join(":")})).join(";"):e.removeAttr("style")}}}
function zn(){return"(?:"+Array.prototype.join.call(arguments,"|")+")"}const _n="convertTransform"
const Pn="perItem"
const qn=!0
const Ln="collapses multiple transformations and optimizes it"
const Wn={convertToShorts:!0,floatPrecision:3,transformPrecision:5,matrixToTransform:!0,shortTranslate:!0,shortScale:!0,shortRotate:!0,removeUseless:!0,collapseIntoOne:!0,leadingZero:!0,negativeExtraSpace:!1}
let Bn
let Mn
let Rn
const In=function(e,t){if(e.elem){e.hasAttr("transform")&&Dn(e,"transform",t)
e.hasAttr("gradientTransform")&&Dn(e,"gradientTransform",t)
e.hasAttr("patternTransform")&&Dn(e,"patternTransform",t)}}
function Dn(e,t,r){let n=tr(e.attr(t).value);(r=function(e,t){const r=e.reduce(Nn,[])
let n=t.transformPrecision
t=Object.assign({},t)
if(r.length){t.transformPrecision=Math.min(t.transformPrecision,Math.max.apply(Math,r.map(Gn))||t.transformPrecision)
n=Math.max.apply(Math,r.map((function(e){return String(e).replace(/\D+/g,"").length})))}"degPrecision"in t||(t.degPrecision=Math.max(0,Math.min(t.floatPrecision,n-2)))
Mn=t.floatPrecision>=1&&t.floatPrecision<20?Un.bind(this,t.floatPrecision):jn
Bn=t.degPrecision>=1&&t.floatPrecision<20?Un.bind(this,t.degPrecision):jn
Rn=t.transformPrecision>=1&&t.floatPrecision<20?Un.bind(this,t.transformPrecision):jn
return t}(n,r)).collapseIntoOne&&n.length>1&&(n=[rr(n)])
r.convertToShorts?n=function(e,t){for(let r=0;r<e.length;r++){let n=e[r]
if(t.matrixToTransform&&"matrix"===n.name){const a=ar(n,t)
a!==n&&Fn(a,t).length<=Fn([n],t).length&&e.splice.apply(e,[r,1].concat(a))
n=e[r]}Vn(n)
t.shortTranslate&&"translate"===n.name&&2===n.data.length&&!n.data[1]&&n.data.pop()
t.shortScale&&"scale"===n.name&&2===n.data.length&&n.data[0]===n.data[1]&&n.data.pop()
if(t.shortRotate&&e[r-2]&&"translate"===e[r-2].name&&"rotate"===e[r-1].name&&"translate"===e[r].name&&e[r-2].data[0]===-e[r].data[0]&&e[r-2].data[1]===-e[r].data[1]){e.splice(r-2,3,{name:"rotate",data:[e[r-1].data[0],e[r-2].data[0],e[r-2].data[1]]})
r-=2
n=e[r]}}return e}(n,r):n.forEach(Vn)
r.removeUseless&&(n=n.filter((function(e){return!(["translate","rotate","skewX","skewY"].indexOf(e.name)>-1&&(1===e.data.length||"rotate"===e.name)&&!e.data[0]||"translate"===e.name&&!e.data[0]&&!e.data[1]||"scale"===e.name&&1===e.data[0]&&(e.data.length<2||1===e.data[1])||"matrix"===e.name&&1===e.data[0]&&1===e.data[3]&&!(e.data[1]||e.data[2]||e.data[4]||e.data[5]))})))
n.length?e.attr(t).value=Fn(n,r):e.removeAttr(t)}function Nn(e,t){return"matrix"===t.name?e.concat(t.data.slice(0,4)):e}function Gn(e){return(e=String(e)).slice(e.indexOf(".")).length-1}function Fn(e,t){let r=""
e.forEach((function(e){Vn(e)
r+=(r&&" ")+e.name+"("+De(e.data,t)+")"}))
return r}function Vn(e){switch(e.name){case"translate":e.data=Mn(e.data)
break
case"rotate":e.data=Bn(e.data.slice(0,1)).concat(Mn(e.data.slice(1)))
break
case"skewX":case"skewY":e.data=Bn(e.data)
break
case"scale":e.data=Rn(e.data)
break
case"matrix":e.data=Rn(e.data.slice(0,4)).concat(Mn(e.data.slice(4)))}return e}function jn(e){return e.map(Math.round)}function Un(e,t){for(let r=t.length,n=+Math.pow(.1,e).toFixed(e);r--;)if(t[r].toFixed(e)!==t[r]){const a=+t[r].toFixed(e-1)
t[r]=+Math.abs(a-t[r]).toFixed(e+1)>=n?+t[r].toFixed(e):a}return t}const Hn="inlineStyles"
const Yn="full"
const Xn=!0
const Kn={onlyMatchedOnce:!0,removeMatchedSelectors:!0,useMqs:["","screen"],usePseudos:[""]}
const Qn="inline styles (additional options)"
const Zn=function(e,t){const r=e.querySelectorAll("style")
if(null===r)return e
const n=[]
let a=[]
for(const t of r){if(t.isEmpty()||t.closestElem("foreignObject"))continue
const r=ve(t)
let i={}
try{i=le().parse(r,{parseValue:!1,parseCustomProperty:!1})}catch(e){continue}n.push({styleEl:t,cssAst:i})
a=a.concat(fe(i))}const i=function(e,t){return e.filter((function(e){const r=le().generate({type:"Selector",children:(new me).fromArray(e.pseudos.map((function(e){return e.item.data})))})
return~t.indexOf(r)}))}(function(e,t){return e.filter((function(e){if(null===e.atrule)return~t.indexOf("")
const r=e.atrule.name
let n=r
e.atrule.expression&&"MediaQueryList"===e.atrule.expression.children.first().type&&(n=[r,le().generate(e.atrule.expression)].join(" "))
return~t.indexOf(n)}))}(a,t.useMqs),t.usePseudos)
!function(e){e.forEach((function(e){e.pseudos.forEach((function(e){e.list.remove(e.item)}))}))}(i)
const o=function(e){return de()(e,he)}(i).reverse()
let s
let l
for(s of o){const t=le().generate(s.item.data)
let r=null
try{r=e.querySelectorAll(t)}catch(e){if(e.message.includes("Unmatched selector:"))continue
throw e}null!==r&&(s.selectedEls=r)}for(s of o)if(s.selectedEls&&!(t.onlyMatchedOnce&&null!==s.selectedEls&&s.selectedEls.length>1)){for(l of s.selectedEls)null!==s.rule&&le().walk(s.rule,{visit:"Declaration",enter:function(e){const t=ge(e)
null!==l.style.getPropertyValue(t.name)&&l.style.getPropertyPriority(t.name)>=t.priority||l.style.setProperty(t.name,t.value,t.priority)}})
t.removeMatchedSelectors&&null!==s.selectedEls&&s.selectedEls.length>0&&s.rule.prelude.children.remove(s.item)}if(!t.removeMatchedSelectors)return e
for(s of o)if(s.selectedEls&&!(t.onlyMatchedOnce&&null!==s.selectedEls&&s.selectedEls.length>1))for(l of s.selectedEls){const e=s.item.data.children.first()
"ClassSelector"===e.type&&l.class.remove(e.name)
void 0===l.class.item(0)&&l.removeAttr("class")
"IdSelector"===e.type&&l.removeAttr("id",e.name)}for(const e of n){le().walk(e.cssAst,{visit:"Rule",enter:function(e,t,r){("Atrule"===e.type&&null!==e.block&&e.block.children.isEmpty()||"Rule"===e.type&&e.prelude.children.isEmpty())&&r.remove(t)}})
if(e.cssAst.children.isEmpty()){const t=e.styleEl.parentNode
t.spliceContent(t.content.indexOf(e.styleEl),1)
if("defs"===t.elem&&0===t.content.length){const e=t.parentNode
e.spliceContent(e.content.indexOf(t),1)}}else ye(e.styleEl,le().generate(e.cssAst))}return e}
const $n="mergePaths"
const Jn="perItem"
const ea=!0
const ta="merges multiple paths in one if possible"
const ra={collapseRepeated:!0,force:!1,leadingZero:!0,negativeExtraSpace:!0,noSpaceAfterFlags:!0}
const na=function(e,t){if(!e.isElem()||e.isEmpty())return
let r=null
let n=null
e.content=e.content.filter((function(e){if(r&&r.isElem("path")&&r.isEmpty()&&r.hasAttr("d")&&e.isElem("path")&&e.isEmpty()&&e.hasAttr("d")){n||(n=Object.keys(r.attrs))
const a=Object.keys(e.attrs)
const i=n.length===a.length&&a.every((function(t){return"d"===t||r.hasAttr(t)&&r.attr(t).value===e.attr(t).value}))
const o=vr(r)
const s=vr(e)
if(i&&(t.force||!kr(o,s))){Sr(r,o.concat(s),t)
return!1}}r=e
n=null
return!0}))}
var aa=r(4758)
const ia="minifyStyles"
const oa="full"
const sa=!0
const la="minifies styles and removes unused styles based on usage data"
const ca={usage:{force:!1,ids:!0,classes:!0,tags:!0}}
const da=function(e,t){const r=ua(t=t||{})
const n=ua(t)
const a=function(e){return function e(t,r){for(let n=0;n<t.content.length;n++){const a=t.content[n]
a.content&&e(a,r);(a.isElem("style")&&!a.isEmpty()||a.isElem()&&a.hasAttr("style"))&&r.push(a)}return r}(e,[])}(e)
r.usage=function(e,t){let r=!0
const n={}
let a=!1
const i=function e(t,n){for(let a=0;a<t.content.length;a++){const i=t.content[a]
i.content&&e(i,n)
i.isElem("script")&&(r=!1)
if(i.isElem()){n.tags[i.elem]=!0
i.hasAttr("id")&&(n.ids[i.attr("id").value]=!0)
i.hasAttr("class")&&i.attr("class").value.replace(/^\s+|\s+$/g,"").split(/\s+/).forEach((function(e){n.classes[e]=!0}))
i.attrs&&Object.keys(i.attrs).some((function(e){return/^on/i.test(e)}))&&(r=!1)}}return n}(e,{ids:Object.create(null),classes:Object.create(null),tags:Object.create(null)})
!r&&t.usage&&t.usage.force&&(r=!0)
for(const e in i)if(pa(t,e)){n[e]=Object.keys(i[e])
a=!0}return r&&a?n:null}(e,t)
n.usage=null
a.forEach((function(e){if(e.isElem("style")){const t=e.content[0].text||e.content[0].cdata||[]
const n=t.indexOf(">")>=0||t.indexOf("<")>=0?"cdata":"text"
e.content[0][n]=(0,aa.minify)(t,r).css}else{const t=e.attr("style").value
e.attr("style").value=(0,aa.minifyBlock)(t,n).css}}))
return e}
function ua(e){const t={}
for(const r in e)t[r]=e[r]
return t}function pa(e,t){return"usage"in e==0||!(!e.usage||t in e.usage!=0)||Boolean(e.usage&&e.usage[t])}const ma="moveElemsAttrsToGroup"
const fa="perItemReverse"
const ha=!0
const ga="moves elements attributes to the existing group wrapper"
const va={}
const ya=function(e){if(e.isElem("g")&&!e.isEmpty()&&e.content.length>1){let t={}
let r=!1
const n=e.hasAttr("clip-path")||e.hasAttr("mask")
const a=e.content.every((function(e){if(e.isElem()&&e.hasAttr()){if(e.hasAttr("class"))return!1
if(Object.keys(t).length){t=function(e,t){const r={}
for(const n in e)Object.prototype.hasOwnProperty.call(t,n)&&ze.indexOf(n)>-1&&e[n].name===t[n].name&&e[n].value===t[n].value&&e[n].prefix===t[n].prefix&&e[n].local===t[n].local&&(r[n]=e[n])
return!!Object.keys(r).length&&r}(t,e.attrs)
if(!t)return!1}else t=e.attrs
return!0}}))
const i=e.content.every((function(e){return e.isElem(Ce)}))
a&&e.content.forEach((function(a){for(const o in t)if(!i&&!n||"transform"!==o){a.removeAttr(o)
if("transform"===o){if(!r){e.hasAttr("transform")?e.attr("transform").value+=" "+t[o].value:e.addAttr(t[o])
r=!0}}else e.addAttr(t[o])}}))}}
const ba=Ce.concat(["g","text"])
const Sa="moveGroupAttrsToElems"
const xa="perItem"
const ka=!0
const wa="moves some group attributes to the content elements"
const Ca={}
const Ta=function(e){if(e.isElem("g")&&e.hasAttr("transform")&&!e.isEmpty()&&!e.someAttr((function(e){return~Oe.indexOf(e.name)&&~e.value.indexOf("url(")}))&&e.content.every((function(e){return e.isElem(ba)&&!e.hasAttr("id")}))){e.content.forEach((function(t){const r=e.attr("transform")
t.hasAttr("transform")?t.attr("transform").value=r.value+" "+t.attr("transform").value:t.addAttr({name:r.name,local:r.local,prefix:r.prefix,value:r.value})}))
e.removeAttr("transform")}}
const Aa="removeComments"
const Ea="perItem"
const Oa=!0
const za="removes comments"
const _a={}
const Pa=function(e){if(e.comment&&"!"!==e.comment.charAt(0))return!1}
const qa="removeDesc"
const La="perItem"
const Wa=!0
const Ba={removeAny:!0}
const Ma="removes <desc>"
const Ra=/^(Created with|Created using)/
const Ia=function(e,t){return!e.isElem("desc")||!(t.removeAny||e.isEmpty()||Ra.test(e.content[0].text))}
const Da="removeDoctype"
const Na="perItem"
const Ga=!0
const Fa="removes doctype declaration"
const Va={}
const ja=function(e){if(e.doctype)return!1}
let Ua=["http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd","http://inkscape.sourceforge.net/DTD/sodipodi-0.dtd","http://www.inkscape.org/namespaces/inkscape","http://www.bohemiancoding.com/sketch/ns","http://ns.adobe.com/AdobeIllustrator/10.0/","http://ns.adobe.com/Graphs/1.0/","http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/","http://ns.adobe.com/Variables/1.0/","http://ns.adobe.com/SaveForWeb/1.0/","http://ns.adobe.com/Extensibility/1.0/","http://ns.adobe.com/Flows/1.0/","http://ns.adobe.com/ImageReplacement/1.0/","http://ns.adobe.com/GenericCustomNamespace/1.0/","http://ns.adobe.com/XPath/1.0/","http://schemas.microsoft.com/visio/2003/SVGExtensions/","http://taptrix.com/vectorillustrator/svg_extensions","http://www.figma.com/figma/ns","http://purl.org/dc/elements/1.1/","http://creativecommons.org/ns#","http://www.w3.org/1999/02/22-rdf-syntax-ns#","http://www.serif.com/","http://www.vector.evaxdesign.sk"]
const Ha="removeEditorsNSData"
const Ya="perItem"
const Xa=!0
const Ka="removes editors namespaces, elements and attributes"
const Qa=[]
const Za={additionalNamespaces:[]}
const $a=function(e,t){Array.isArray(t.additionalNamespaces)&&(Ua=Ua.concat(t.additionalNamespaces))
if(e.elem){e.isElem("svg")&&e.eachAttr((function(t){if("xmlns"===t.prefix&&Ua.indexOf(t.value)>-1){Qa.push(t.local)
e.removeAttr(t.name)}}))
e.eachAttr((function(t){Qa.indexOf(t.prefix)>-1&&e.removeAttr(t.name)}))
if(Qa.indexOf(e.prefix)>-1)return!1}}
const Ja="removeEmptyAttrs"
const ei="perItem"
const ti=!0
const ri="removes empty attributes"
const ni={}
const ai=function(e){e.elem&&e.eachAttr((function(t){""===t.value&&e.removeAttr(t.name)}))}
const ii=we.container
const oi="removeEmptyContainers"
const si="perItemReverse"
const li=!0
const ci="removes empty container elements"
const di={}
const ui=function(e){return!(e.isElem(ii)&&!e.isElem("svg")&&e.isEmpty()&&(!e.isElem("pattern")||!e.hasAttrLocal("href")))}
const pi="removeEmptyText"
const mi="perItem"
const fi=!0
const hi="removes empty <text> elements"
const gi={text:!0,tspan:!0,tref:!0}
const vi=function(e,t){return!(t.text&&e.isElem("text")&&e.isEmpty())&&!(t.tspan&&e.isElem("tspan")&&e.isEmpty())&&!(t.tref&&e.isElem("tref")&&!e.hasAttrLocal("href"))&&void 0}
const yi="removeHiddenElems"
const bi="perItem"
const Si=!0
const xi="removes hidden elements (zero sized, with absent attributes)"
const ki={isHidden:!0,displayNone:!0,opacity0:!0,circleR0:!0,ellipseRX0:!0,ellipseRY0:!0,rectWidth0:!0,rectHeight0:!0,patternWidth0:!0,patternHeight0:!0,imageWidth0:!0,imageHeight0:!0,pathEmptyD:!0,polylineEmptyPoints:!0,polygonEmptyPoints:!0}
const wi=/M\s*(?:[-+]?(?:\d*\.\d+|\d+(?:\.|(?!\.)))([eE][-+]?\d+)?(?!\d)\s*,?\s*){2}\D*\d/i
const Ci=function(e,t){if(e.elem){if(t.isHidden&&e.hasAttr("visibility","hidden"))return!1
if(t.displayNone&&e.hasAttr("display","none"))return!1
if(t.opacity0&&e.hasAttr("opacity","0"))return!1
if(t.circleR0&&e.isElem("circle")&&e.isEmpty()&&e.hasAttr("r","0"))return!1
if(t.ellipseRX0&&e.isElem("ellipse")&&e.isEmpty()&&e.hasAttr("rx","0"))return!1
if(t.ellipseRY0&&e.isElem("ellipse")&&e.isEmpty()&&e.hasAttr("ry","0"))return!1
if(t.rectWidth0&&e.isElem("rect")&&e.isEmpty()&&e.hasAttr("width","0"))return!1
if(t.rectHeight0&&t.rectWidth0&&e.isElem("rect")&&e.isEmpty()&&e.hasAttr("height","0"))return!1
if(t.patternWidth0&&e.isElem("pattern")&&e.hasAttr("width","0"))return!1
if(t.patternHeight0&&e.isElem("pattern")&&e.hasAttr("height","0"))return!1
if(t.imageWidth0&&e.isElem("image")&&e.hasAttr("width","0"))return!1
if(t.imageHeight0&&e.isElem("image")&&e.hasAttr("height","0"))return!1
if(t.pathEmptyD&&e.isElem("path")&&(!e.hasAttr("d")||!wi.test(e.attr("d").value)))return!1
if(t.polylineEmptyPoints&&e.isElem("polyline")&&!e.hasAttr("points"))return!1
if(t.polygonEmptyPoints&&e.isElem("polygon")&&!e.hasAttr("points"))return!1}}
const Ti="removeMetadata"
const Ai="perItem"
const Ei=!0
const Oi="removes <metadata>"
const zi={}
const _i=function(e){return!e.isElem("metadata")}
const Pi="removeNonInheritableGroupAttrs"
const qi="perItem"
const Li=!0
const Wi="removes non-inheritable group’s presentational attributes"
const Bi={}
const Mi=function(e){e.isElem("g")&&e.eachAttr((function(t){!~Te.presentation.indexOf(t.name)||~ze.indexOf(t.name)||~_e.indexOf(t.name)||e.removeAttr(t.name)}))}
const Ri="removeTitle"
const Ii="perItem"
const Di=!0
const Ni="removes <title>"
const Gi={}
const Fi=function(e){return!e.isElem("title")}
const Vi="removeUnknownsAndDefaults"
const ji="perItem"
const Ui=!0
const Hi="removes unknown elements content and attributes, removes attrs with default values"
const Yi={unknownContent:!0,unknownAttrs:!0,defaultAttrs:!0,uselessOverrides:!0,keepDataAttrs:!0,keepAriaAttrs:!0,keepRoleAttr:!1}
for(var Xi in Ee){if((Xi=Ee[Xi]).attrsGroups){Xi.attrs=Xi.attrs||[]
Xi.attrsGroups.forEach((function(e){Xi.attrs=Xi.attrs.concat(Te[e])
var t=Ae[e]
if(t){Xi.defaults=Xi.defaults||{}
for(var r in t)Xi.defaults[r]=t[r]}}))}if(Xi.contentGroups){Xi.content=Xi.content||[]
Xi.contentGroups.forEach((function(e){Xi.content=Xi.content.concat(we[e])}))}}const Ki=function(e,t){if(e.isElem()&&!e.prefix){var r=e.elem
t.unknownContent&&!e.isEmpty()&&Ee[r]&&"foreignObject"!==r&&e.content.forEach((function(t,n){t.isElem()&&!t.prefix&&(Ee[r].content&&-1===Ee[r].content.indexOf(t.elem)||!Ee[r].content&&!Ee[t.elem])&&e.content.splice(n,1)}))
Ee[r]&&Ee[r].attrs&&e.eachAttr((function(n){"xmlns"===n.name||"xml"!==n.prefix&&n.prefix||t.keepDataAttrs&&0===n.name.indexOf("data-")||t.keepAriaAttrs&&0===n.name.indexOf("aria-")||t.keepRoleAttr&&"role"===n.name||(t.unknownAttrs&&-1===Ee[r].attrs.indexOf(n.name)||t.defaultAttrs&&!e.hasAttr("id")&&Ee[r].defaults&&Ee[r].defaults[n.name]===n.value&&(ze.indexOf(n.name)<0||!e.parentNode.computedAttr(n.name))||t.uselessOverrides&&!e.hasAttr("id")&&_e.indexOf(n.name)<0&&ze.indexOf(n.name)>-1&&e.parentNode.computedAttr(n.name,n.value))&&e.removeAttr(n.name)}))}}
const Qi="removeUnusedNS"
const Zi="full"
const $i=!0
const Ji="removes unused namespaces declaration"
const eo={}
const to=function(e){let t
const r=[]
function n(e){const t=r.indexOf(e)
t>-1&&r.splice(t,1)}e=function e(a){let i=0
const o=a.content.length
for(;i<o;){const o=a.content[i]
if(o.isElem("svg")){o.eachAttr((function(e){"xmlns"===e.prefix&&e.local&&r.push(e.local)}))
r.length&&(t=o)}if(r.length){o.prefix&&n(o.prefix)
o.eachAttr((function(e){n(e.prefix)}))}r.length&&o.content&&e(o)
i++}return a}(e)
r.length&&r.forEach((function(e){t.removeAttr("xmlns:"+e)}))
return e}
const ro=we.nonRendering
const no="removeUselessDefs"
const ao="perItem"
const io=!0
const oo="removes elements in <defs> without id"
const so={}
const lo=function(e){if(e.isElem("defs")){e.content&&(e.content=co(e,[]))
if(e.isEmpty())return!1}else if(e.isElem(ro)&&!e.hasAttr("id"))return!1}
function co(e,t){e.content.forEach((function(r){if(r.hasAttr("id")||r.isElem("style")){t.push(r)
r.parentNode=e}else r.isEmpty()||(r.content=co(r,t))}))
return t}const uo=we.shape
const po="removeUselessStrokeAndFill"
const mo="perItem"
const fo=!0
const ho="removes useless stroke and fill attributes"
const go={stroke:!0,fill:!0,removeNone:!1,hasStyleOrScript:!1}
const vo=/^stroke/
const yo=/^fill-/
const bo=["style","script"]
const So=function(e,t){e.isElem(bo)&&(t.hasStyleOrScript=!0)
if(!t.hasStyleOrScript&&e.isElem(uo)&&!e.computedAttr("id")){const r=t.stroke&&e.computedAttr("stroke")
const n=t.fill&&!e.computedAttr("fill","none")
if(t.stroke&&(!r||"none"===r||e.computedAttr("stroke-opacity","0")||e.computedAttr("stroke-width","0"))){const t=e.parentNode.computedAttr("stroke")
const r=t&&"none"!==t
e.eachAttr((function(t){vo.test(t.name)&&e.removeAttr(t.name)}))
r&&e.addAttr({name:"stroke",value:"none",prefix:"",local:"stroke"})}if(t.fill&&(!n||e.computedAttr("fill-opacity","0"))){e.eachAttr((function(t){yo.test(t.name)&&e.removeAttr(t.name)}))
n&&(e.hasAttr("fill")?e.attr("fill").value="none":e.addAttr({name:"fill",value:"none",prefix:"",local:"fill"}))}if(t.removeNone&&(!r||e.hasAttr("stroke")&&"none"===e.attr("stroke").value)&&(!n||e.hasAttr("fill")&&"none"===e.attr("fill").value))return!1}}
const xo="removeViewBox"
const ko="perItem"
const wo=!0
const Co="removes viewBox attribute when possible"
const To={}
const Ao=["svg","pattern","symbol"]
const Eo=function(e){if(e.isElem(Ao)&&e.hasAttr("viewBox")&&e.hasAttr("width")&&e.hasAttr("height")){const t=e.attr("viewBox").value.split(/[ ,]+/g)
"0"===t[0]&&"0"===t[1]&&e.attr("width").value.replace(/px$/,"")===t[2]&&e.attr("height").value.replace(/px$/,"")===t[3]&&e.removeAttr("viewBox")}}
const Oo="removeXMLProcInst"
const zo="perItem"
const _o=!0
const Po="removes XML processing instructions"
const qo={}
const Lo=function(e){return!(e.processinginstruction&&"xml"===e.processinginstruction.name)}
const Wo="sortDefsChildren"
const Bo="perItem"
const Mo=!0
const Ro="Sorts children of <defs> to improve compression"
const Io={}
const Do=function(e){if(e.isElem("defs")){if(e.content){const t=e.content.reduce((function(e,t){t.elem in e?e[t.elem]++:e[t.elem]=1
return e}),{})
e.content.sort((function(e,r){const n=t[r.elem]-t[e.elem]
if(0!==n)return n
const a=r.elem.length-e.elem.length
return 0!==a?a:e.elem!==r.elem?e.elem>r.elem?-1:1:0}))}return!0}}
const No=[n,a,i,o,s,l,c,d,u,p,m,f,h,g,v,y,b,S,x,k,w,C,T,A,E,O,z,_,P,q,L,W,B,M]
const Go=Ge
Go.Config=(e={plugins:No})=>J(e)
const Fo="addAttributesToSVGElement"
const Vo="full"
const jo=!1
const Uo="adds attributes to an outer <svg> element"
const Ho={}
const Yo=function(e,t){if(!t||!Array.isArray(t.attributes)&&!t.attribute){console.error('Error in plugin "addAttributesToSVGElement": absent parameters.\nIt should have a list of "attributes" or one "attribute".\nConfig example:\n\nplugins:\n- addAttributesToSVGElement:\n    attribute: "mySvg"\n\nplugins:\n- addAttributesToSVGElement:\n    attributes: ["mySvg", "size-big"]\n\nplugins:\n- addAttributesToSVGElement:\n    attributes:\n        - focusable: false\n        - data-image: icon')
return e}const r=t.attributes||[t.attribute]
const n=e.content[0]
n.isElem("svg")&&r.forEach((function(e){"string"==typeof e?n.hasAttr(e)||n.addAttr({name:e,prefix:"",local:e}):"object"==typeof e&&Object.keys(e).forEach((function(t){n.hasAttr(t)||n.addAttr({name:t,value:e[t],prefix:"",local:t})}))}))
return e}
const Xo="addClassesToSVGElement"
const Ko="full"
const Qo=!1
const Zo="adds classnames to an outer <svg> element"
const $o={}
const Jo=function(e,t){if(!t||!(Array.isArray(t.classNames)&&t.classNames.some(String)||t.className)){console.error('Error in plugin "addClassesToSVGElement": absent parameters.\nIt should have a list of classes in "classNames" or one "className".\nConfig example:\n\nplugins:\n- addClassesToSVGElement:\n    className: "mySvg"\n\nplugins:\n- addClassesToSVGElement:\n    classNames: ["mySvg", "size-big"]\n')
return e}const r=t.classNames||[t.className]
const n=e.content[0]
n.isElem("svg")&&n.class.add.apply(n.class,r)
return e}
const es="cleanupListOfValues"
const ts="perItem"
const rs=!1
const ns="rounds list of values to the fixed precision"
const as={floatPrecision:3,leadingZero:!0,defaultPx:!0,convertToPx:!0}
const is=/^([-+]?\d*\.?\d+([eE][-+]?\d+)?)(px|pt|pc|mm|cm|m|in|ft|em|ex|%)?$/
const os=/\s+,?\s*|,\s*/
const ss={cm:96/2.54,mm:96/25.4,in:96,pt:4/3,pc:16}
const ls=function(e,t){e.hasAttr("points")&&r(e.attrs.points)
e.hasAttr("enable-background")&&r(e.attrs["enable-background"])
e.hasAttr("viewBox")&&r(e.attrs.viewBox)
e.hasAttr("stroke-dasharray")&&r(e.attrs["stroke-dasharray"])
e.hasAttr("dx")&&r(e.attrs.dx)
e.hasAttr("dy")&&r(e.attrs.dy)
e.hasAttr("x")&&r(e.attrs.x)
e.hasAttr("y")&&r(e.attrs.y)
function r(e){let r
let n
let a
let i
const o=e.value.split(os)
const s=[]
o.forEach((function(e){a=e.match(is)
i=e.match(/new/)
if(a){r=+(+a[1]).toFixed(t.floatPrecision)
n=a[3]||""
if(t.convertToPx&&n&&n in ss){const e=+(ss[n]*a[1]).toFixed(t.floatPrecision)
if(String(e).length<a[0].length){r=e
n="px"}}t.leadingZero&&(r=Ne(r))
t.defaultPx&&"px"===n&&(n="")
s.push(r+n)}else i?s.push("new"):e&&s.push(e)}))
const l=s.join(" ")
e.value=l}}
const cs="prefixIds"
const ds="perItem"
const us=!1
const ps={delim:"__",prefixIds:!0,prefixClassNames:!0}
const ms="prefix IDs"
const fs=/^#(.*)$/
let hs=null
const gs=function(e){return e&&e.value&&e.value.length>0}
const vs=function(e){const t=function(e){const t=e.match(fs)
return null!==t&&t[1]}(e)
return!!t&&"#"+hs(t)}
const ys=function(e){if(!gs(e))return
const t=vs(e.value)
t&&(e.value=t)}
const bs=function(e){if(!gs(e))return
const t=function(e){const t=/url\((.*?)\)/gi.exec(e)
return null!==t&&t[1]}(e.value)
if(!t)return
const r=vs(t)
r&&(e.value="url("+r+")")}
const Ss=function(e){if(!gs(e))return
const t=e.value.split("; ").map((function(e){if((e=e.trim()).endsWith(".end")||e.endsWith(".start")){const t=e.split(".")
const r=t[0]
const n=t[1]
let a=vs(`#${r}`)
if(!a)return e
a=a.slice(1)
return`${a}.${n}`}return e}))
e.value=t.join("; ")}
const xs=function(e,t,r){if(r.multipassCount&&r.multipassCount>0)return e
let n="prefix"
t.prefix?n="function"==typeof t.prefix?t.prefix(e,r):t.prefix:!1===t.prefix?n=!1:r&&r.path&&r.path.length>0&&(n=r.path.split(/[/\\]/).pop())
hs=function(e){return function(e){return e.replace(/[. ]/g,"_")}(!1===n?e:n+t.delim+e)}
if("style"===e.elem){if(e.isEmpty())return e
const r=e.content[0].text||e.content[0].cdata||[]
let n={}
try{n=le().parse(r,{parseValue:!0,parseCustomProperty:!1})}catch(t){console.warn("Warning: Parse error of styles of <style/> element, skipped. Error details: "+t)
return e}let a=""
le().walk(n,(function(e){if((t.prefixIds&&"IdSelector"===e.type||t.prefixClassNames&&"ClassSelector"===e.type)&&e.name)e.name=hs(e.name)
else if("Url"===e.type&&e.value.value&&e.value.value.length>0){a=vs(((e="")=>{const{length:t}=e
if(0!==t){const r=e.charCodeAt(0)
const n=e.charCodeAt(t-1)
const a=39===r||34===r
const i=39===n||34===n
e=e.slice(a?1:0,i?t-1:t)}return e})(e.value.value))
if(!a)return
e.value.value=a}}))
e.content[0].text=le().generate(n)
return e}if(!e.attrs)return e
t.prefixIds&&(a=e.attrs.id,gs(a)&&(a.value=hs(a.value)))
var a
t.prefixClassNames&&function(e){gs(e)&&(e.value=e.value.split(/\s+/).map(hs).join(" "))}(e.attrs.class)
ys(e.attrs.href)
ys(e.attrs["xlink:href"])
for(const t of Oe)bs(e.attrs[t])
Ss(e.attrs.begin)
Ss(e.attrs.end)
return e}
const ks="removeAttributesBySelector"
const ws="perItem"
const Cs=!1
const Ts="removes attributes of elements that match a css selector"
const As={}
const Es=function(e,t){(Array.isArray(t.selectors)?t.selectors:[t]).map((function(t){e.matches(t.selector)&&e.removeAttr(t.attributes)}))}
const Os="removeAttrs"
const zs="perItem"
const _s=!1
const Ps="removes specified attributes"
const qs={elemSeparator:":",preserveCurrentColor:!1,attrs:[]}
const Ls=function(e,t){Array.isArray(t.attrs)||(t.attrs=[t.attrs])
if(e.isElem()){const r="string"==typeof t.elemSeparator?t.elemSeparator:":"
const n="boolean"==typeof t.preserveCurrentColor&&t.preserveCurrentColor
t.attrs.map((function(e){-1===e.indexOf(r)?e=[".*",r,e,r,".*"].join(""):e.split(r).length<3&&(e=[e,r,".*"].join(""))
return e.split(r).map((function(e){"*"===e&&(e=".*")
return new RegExp(["^",e,"$"].join(""),"i")}))})).forEach((function(t){t[0].test(e.elem)&&e.eachAttr((function(r){const a=r.name
const i=r.value
n&&"fill"===a&&"currentColor"===i||n&&"stroke"===a&&"currentColor"===i||t[1].test(a)&&t[2].test(r.value)&&e.removeAttr(a)}))}))}}
const Ws="removeDimensions"
const Bs="perItem"
const Ms=!1
const Rs="removes width and height in presence of viewBox (opposite to removeViewBox, disable it first)"
const Is={}
const Ds=function(e){if(e.isElem("svg"))if(e.hasAttr("viewBox")){e.removeAttr("width")
e.removeAttr("height")}else if(e.hasAttr("width")&&e.hasAttr("height")&&!isNaN(Number(e.attr("width").value))&&!isNaN(Number(e.attr("height").value))){e.addAttr({name:"viewBox",value:"0 0 "+Number(e.attr("width").value)+" "+Number(e.attr("height").value),prefix:"",local:"viewBox"})
e.removeAttr("width")
e.removeAttr("height")}}
const Ns="removeElementsByAttr"
const Gs="perItem"
const Fs=!1
const Vs="removes arbitrary elements by ID or className (disabled by default)"
const js={id:[],class:[]}
const Us=function(e,t){["id","class"].forEach((function(e){Array.isArray(t[e])||(t[e]=[t[e]])}))
if(!e.isElem())return
const r=e.attr("id")
if(r)return-1===t.id.indexOf(r.value)
const n=e.attr("class")
return n?!new RegExp(t.class.join("|")).test(n.value):void 0}
const Hs="removeOffCanvasPaths"
const Ys="perItem"
const Xs=!1
const Ks="removes elements that are drawn outside of the viewbox (disabled by default)"
const Qs={}
let Zs
let $s
const Js=function(e){if(e.isElem("path")&&e.hasAttr("d")&&void 0!==Zs){if(el(e)||function(e){const t=/M\s*(-?\d*\.?\d+)(?!\d)\s*(-?\d*\.?\d+)/g
let r
for(;null!==(r=t.exec(e));)if(r[1]>=Zs.left&&r[1]<=Zs.right&&r[2]>=Zs.top&&r[2]<=Zs.bottom)return!0
return!1}(e.attr("d").value))return!0
let t=vr(e)
if(2===t.length){t=JSON.parse(JSON.stringify(t))
t.push({instruction:"z"})}return kr($s,t)}e.isElem("svg")&&function(e){let t=""
e.hasAttr("viewBox")?t=e.attr("viewBox").value:e.hasAttr("height")&&e.hasAttr("width")&&(t="0 0 "+e.attr("width").value+" "+e.attr("height").value)
t=t.replace(/[,+]|px/g," ").replace(/\s+/g," ").replace(/^\s*|\s*$/g,"")
const r=/^(-?\d*\.?\d+) (-?\d*\.?\d+) (\d*\.?\d+) (\d*\.?\d+)$/.exec(t)
if(!r)return
Zs={left:parseFloat(r[1]),top:parseFloat(r[2]),right:parseFloat(r[1])+parseFloat(r[3]),bottom:parseFloat(r[2])+parseFloat(r[4])}
const n=new ie({elem:"path",prefix:"",local:"path"})
n.addAttr({name:"d",prefix:"",local:"d",value:"M"+r[1]+" "+r[2]+"h"+r[3]+"v"+r[4]+"H"+r[1]+"z"})
$s=vr(n)}(e)
return!0}
function el(e){return e.hasAttr("transform")||e.parentNode&&el(e.parentNode)}const tl="removeRasterImages"
const rl="perItem"
const nl=!1
const al="removes raster images (disabled by default)"
const il={}
const ol=function(e){if(e.isElem("image")&&e.hasAttrLocal("href",/(\.|image\/)(jpg|png|gif)/))return!1}
const sl="removeScriptElement"
const ll="perItem"
const cl=!1
const dl="removes <script> elements (disabled by default)"
const ul={}
const pl=function(e){return!e.isElem("script")}
const ml="removeStyleElement"
const fl="perItem"
const hl=!1
const gl="removes <style> element (disabled by default)"
const vl={}
const yl=function(e){return!e.isElem("style")}
const bl="removeXMLNS"
const Sl="perItem"
const xl=!1
const kl="removes xmlns attribute (for inline svg, disabled by default)"
const wl={}
const Cl=function(e){e.isElem("svg")&&e.hasAttr("xmlns")&&e.removeAttr("xmlns")}

;/**
 * @license
 * The MIT License
 *
 * Copyright © 2012–2016 Kir Belevich
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 *
 * Лицензия MIT
 *
 * Copyright © 2012–2016 Кир Белевич
 *
 * Данная лицензия разрешает лицам, получившим копию
 * данного
 * программного обеспечения и сопутствующей
 * документации
 * (в дальнейшем именуемыми «Программное Обеспечение»),
 * безвозмездно
 * использовать Программное Обеспечение без
 * ограничений, включая
 * неограниченное право на использование, копирование,
 * изменение,
 * добавление, публикацию, распространение,
 * сублицензирование
 * и/или продажу копий Программного Обеспечения, также
 * как и лицам,
 * которым предоставляется данное Программное
 * Обеспечение,
 * при соблюдении следующих условий:
 *
 * Указанное выше уведомление об авторском праве и
 * данные условия
 * должны быть включены во все копии или значимые части
 * данного
 * Программного Обеспечения.
 *
 * ДАННОЕ ПРОГРАММНОЕ ОБЕСПЕЧЕНИЕ ПРЕДОСТАВЛЯЕТСЯ «КАК
 * ЕСТЬ»,
 * БЕЗ КАКИХ-ЛИБО ГАРАНТИЙ, ЯВНО ВЫРАЖЕННЫХ ИЛИ
 * ПОДРАЗУМЕВАЕМЫХ,
 * ВКЛЮЧАЯ, НО НЕ ОГРАНИЧИВАЯСЬ ГАРАНТИЯМИ ТОВАРНОЙ
 * ПРИГОДНОСТИ,
 * СООТВЕТСТВИЯ ПО ЕГО КОНКРЕТНОМУ НАЗНАЧЕНИЮ И
 * ОТСУТСТВИЯ НАРУШЕНИЙ
 * ПРАВ. НИ В КАКОМ СЛУЧАЕ АВТОРЫ ИЛИ ПРАВООБЛАДАТЕЛИ НЕ
 * НЕСУТ
 * ОТВЕТСТВЕННОСТИ ПО ИСКАМ О ВОЗМЕЩЕНИИ УЩЕРБА, УБЫТКОВ
 * ИЛИ ДРУГИХ
 * ТРЕБОВАНИЙ ПО ДЕЙСТВУЮЩИМ КОНТРАКТАМ, ДЕЛИКТАМ ИЛИ
 * ИНОМУ,
 * ВОЗНИКШИМ ИЗ, ИМЕЮЩИМ ПРИЧИНОЙ ИЛИ СВЯЗАННЫМ С
 * ПРОГРАММНЫМ
 * ОБЕСПЕЧЕНИЕМ ИЛИ ИСПОЛЬЗОВАНИЕМ ПРОГРАММНОГО
 * ОБЕСПЕЧЕНИЯ
 * ИЛИ ИНЫМИ ДЕЙСТВИЯМИ С ПРОГРАММНЫМ ОБЕСПЕЧЕНИЕМ.
 */const Tl="reusePaths"
const Al="full"
const El=!1
const Ol="Finds <path> elements with the same d, fill, and stroke, and converts them to <use> elements referencing a single <path> def."
const zl={}
const _l=function(e){const t=new Map
let r=0
const n=[]
ql(e,(e=>{if(!e.isElem("path")||!e.hasAttr("d"))return
const a=e.attr("d").value
const i=e.hasAttr("fill")&&e.attr("fill").value||""
const o=a+";s:"+(e.hasAttr("stroke")&&e.attr("stroke").value||"")+";f:"+i
const s=t.get(o)
if(s){if(!s.reused){s.reused=!0
s.elem.hasAttr("id")||s.elem.addAttr({name:"id",local:"id",prefix:"",value:"reuse-"+r++})
n.push(s.elem)}e=Pl(e,s.elem.attr("id").value)}else t.set(o,{elem:e,reused:!1})}))
const a=new ie({elem:"defs",prefix:"",local:"defs",content:[],attrs:[]},e)
e.content[0].spliceContent(0,0,a)
for(let e of n){const t=e.style
const r=e.class
delete e.style
delete e.class
const n=e.clone()
e.style=t
e.class=r
n.removeAttr("transform")
a.spliceContent(0,0,n)
e=Pl(e,n.attr("id").value)
e.removeAttr("id")}return e}
function Pl(e,t){e.renameElem("use")
e.removeAttr("d")
e.removeAttr("stroke")
e.removeAttr("fill")
e.addAttr({name:"xlink:href",local:"xlink:href",prefix:"none",value:"#"+t})
delete e.pathJS
return e}function ql(e,t){if(!e.isEmpty())for(const r of e.content){t(r)
ql(r,t)}}const Ll="sortAttrs"
const Wl="perItem"
const Bl=!1
const Ml="sorts element attributes (disabled by default)"
const Rl={order:["id","width","height","x","x1","x2","y","y1","y2","cx","cy","r","fill","stroke","marker","d","points"]}
const Il=function(e,t){const r=[]
const n={}
const a=t.order.length+1
const i=t.xmlnsOrder||"front"
if(e.elem){e.eachAttr((function(e){r.push(e)}))
r.sort((function(e,r){if(e.prefix!==r.prefix){if("front"===i){if("xmlns"===e.prefix)return-1
if("xmlns"===r.prefix)return 1}return e.prefix<r.prefix?-1:1}let n=a
let o=a
for(let a=0;a<t.order.length;a++){e.name===t.order[a]?n=a:0===e.name.indexOf(t.order[a]+"-")&&(n=a+.5)
r.name===t.order[a]?o=a:0===r.name.indexOf(t.order[a]+"-")&&(o=a+.5)}return n!==o?n-o:e.name<r.name?-1:1}))
r.forEach((function(e){n[e.name]=e}))
e.attrs=n}}
const Dl=Object.assign(Go,{SVGO_LITE:Ge,CONFIG_LITE:J,PLUGINS_DEFAULT_LIST:No,PLUGINS_MAP:$})},7544:e=>{e.exports={trueFunc:function(){return!0},falseFunc:function(){return!1}}},732:e=>{"use strict"
e.exports=function(e){!function(e){if(!e)throw new TypeError("Expected implementation")
var r=t.filter((function(t){return"function"!=typeof e[t]}))
if(r.length){var n="("+r.join(", ")+")"
throw new Error("Expected functions "+n+" to be implemented")}}(e)
var r={}
var n={removeSubsets:function(e){return function(e,t){var r,n,a,i=t.length
for(;--i>-1;){r=n=t[i]
t[i]=null
a=!0
for(;n;){if(t.indexOf(n)>-1){a=!1
t.splice(i,1)
break}n=e.getParent(n)}a&&(t[i]=r)}return t}(r,e)},existsOne:function(e,t){return function(e,t,r){return r.some((function(r){return!!e.isTag(r)&&(t(r)||e.existsOne(t,e.getChildren(r)))}))}(r,e,t)},getSiblings:function(e){return function(e,t){var r=e.getParent(t)
return r&&e.getChildren(r)}(r,e)},hasAttrib:function(e,t){return function(e,t,r){return void 0!==e.getAttributeValue(t,r)}(r,e,t)},findOne:function(e,t){return function(e,t,r){var n=null
for(var a=0,i=r.length;a<i&&!n;a++)if(t(r[a]))n=r[a]
else{var o=e.getChildren(r[a])
o&&o.length>0&&(n=e.findOne(t,o))}return n}(r,e,t)},findAll:function(e,t){return function(e,t,r){var n=[]
for(var a=0,i=r.length;a<i;a++)if(e.isTag(r[a])){t(r[a])&&n.push(r[a])
var o=e.getChildren(r[a])
o&&(n=n.concat(e.findAll(t,o)))}return n}(r,e,t)}}
Object.assign(r,n,e)
return r}
var t=["isTag","getAttributeValue","getChildren","getName","getParent","getText"]},8221:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.attributeRules=void 0
var n=r(7544)
var a=/[-[\]{}()*+?.,\\^$|#\s]/g
function i(e){return e.replace(a,"\\$&")}t.attributeRules={equals:function(e,t,r){var n=r.adapter
var a=t.name
var i=t.value
if(t.ignoreCase){i=i.toLowerCase()
return function(t){var r
return(null===(r=n.getAttributeValue(t,a))||void 0===r?void 0:r.toLowerCase())===i&&e(t)}}return function(t){return n.getAttributeValue(t,a)===i&&e(t)}},hyphen:function(e,t,r){var n=r.adapter
var a=t.name
var i=t.value
var o=i.length
if(t.ignoreCase){i=i.toLowerCase()
return function(t){var r=n.getAttributeValue(t,a)
return null!=r&&(r.length===o||"-"===r.charAt(o))&&r.substr(0,o).toLowerCase()===i&&e(t)}}return function(t){var r=n.getAttributeValue(t,a)
return null!=r&&r.substr(0,o)===i&&(r.length===o||"-"===r.charAt(o))&&e(t)}},element:function(e,t,r){var a=t.name,o=t.value,s=t.ignoreCase
var l=r.adapter
if(/\s/.test(o))return n.falseFunc
var c=new RegExp("(?:^|\\s)"+i(o)+"(?:$|\\s)",s?"i":"")
return function(t){var r=l.getAttributeValue(t,a)
return null!=r&&c.test(r)&&e(t)}},exists:function(e,t,r){var n=t.name
var a=r.adapter
return function(t){return a.hasAttrib(t,n)&&e(t)}},start:function(e,t,r){var a=r.adapter
var i=t.name
var o=t.value
var s=o.length
if(0===s)return n.falseFunc
if(t.ignoreCase){o=o.toLowerCase()
return function(t){var r
return(null===(r=a.getAttributeValue(t,i))||void 0===r?void 0:r.substr(0,s).toLowerCase())===o&&e(t)}}return function(t){var r
return!!(null===(r=a.getAttributeValue(t,i))||void 0===r?void 0:r.startsWith(o))&&e(t)}},end:function(e,t,r){var a=r.adapter
var i=t.name
var o=t.value
var s=-o.length
if(0===s)return n.falseFunc
if(t.ignoreCase){o=o.toLowerCase()
return function(t){var r
return(null===(r=a.getAttributeValue(t,i))||void 0===r?void 0:r.substr(s).toLowerCase())===o&&e(t)}}return function(t){var r
return!!(null===(r=a.getAttributeValue(t,i))||void 0===r?void 0:r.endsWith(o))&&e(t)}},any:function(e,t,r){var a=r.adapter
var o=t.name,s=t.value
if(""===s)return n.falseFunc
if(t.ignoreCase){var l=new RegExp(i(s),"i")
return function(t){var r=a.getAttributeValue(t,o)
return null!=r&&l.test(r)&&e(t)}}return function(t){var r
return!!(null===(r=a.getAttributeValue(t,o))||void 0===r?void 0:r.includes(s))&&e(t)}},not:function(e,t,r){var n=r.adapter
var a=t.name
var i=t.value
if(""===i)return function(t){return!!n.getAttributeValue(t,a)&&e(t)}
if(t.ignoreCase){i=i.toLowerCase()
return function(t){var r=n.getAttributeValue(t,a)
return null!=r&&r.toLocaleLowerCase()!==i&&e(t)}}return function(t){return n.getAttributeValue(t,a)!==i&&e(t)}}}},3999:function(e,t,r){"use strict"
var n=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}}
Object.defineProperty(t,"__esModule",{value:!0})
t.compileToken=t.compileUnsafe=t.compile=void 0
var a=r(9528)
var i=r(7544)
var o=n(r(1766))
var s=r(157)
var l=r(7849)
var c=r(457)
t.compile=function(e,t,r){var n=d(e,t,r)
return c.ensureIsTag(n,t.adapter)}
function d(e,t,r){return h(a.parse(e,t),t,r)}t.compileUnsafe=d
function u(e){return"pseudo"===e.type&&("scope"===e.name||Array.isArray(e.data)&&e.data.some((function(e){return e.some(u)})))}var p={type:"descendant"}
var m={type:"_flexibleDescendant"}
var f={type:"pseudo",name:"scope",data:null}
function h(e,t,r){var n;(e=e.filter((function(e){return e.length>0}))).forEach(o.default)
r=null!==(n=t.context)&&void 0!==n?n:r
var a=Array.isArray(r)
var d=r&&(Array.isArray(r)?r:[r])
!function(e,t,r){var n=t.adapter
var a=!!(null==r?void 0:r.every((function(e){var t=n.getParent(e)
return e===c.PLACEHOLDER_ELEMENT||!(!t||!n.isTag(t))})))
for(var i=0,o=e;i<o.length;i++){var l=o[i]
if(l.length>0&&s.isTraversal(l[0])&&"descendant"!==l[0].type);else{if(!a||l.some(u))continue
l.unshift(p)}l.unshift(f)}}(e,t,d)
var v=!1
var y=e.map((function(e){if(e.length>=2){var r=e[0],n=e[1]
"pseudo"!==r.type||"scope"!==r.name||(a&&"descendant"===n.type?e[1]=m:"adjacent"!==n.type&&"sibling"!==n.type||(v=!0))}return function(e,t,r){var n
return e.reduce((function(e,n){return e===i.falseFunc?i.falseFunc:l.compileGeneralSelector(e,n,t,r,h)}),null!==(n=t.rootFunc)&&void 0!==n?n:i.trueFunc)}(e,t,d)})).reduce(g,i.falseFunc)
y.shouldTestNextSiblings=v
return y}t.compileToken=h
function g(e,t){return t===i.falseFunc||e===i.trueFunc?e:e===i.falseFunc||t===i.trueFunc?t:function(r){return e(r)||t(r)}}},7849:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.compileGeneralSelector=void 0
var n=r(8221)
var a=r(8896)
t.compileGeneralSelector=function(e,t,r,i,o){var s=r.adapter,l=r.equals
switch(t.type){case"pseudo-element":throw new Error("Pseudo-elements are not supported by css-select")
case"attribute":if(r.strict&&(t.ignoreCase||"not"===t.action))throw new Error("Unsupported attribute selector")
return n.attributeRules[t.action](e,t,r)
case"pseudo":return a.compilePseudoSelector(e,t,r,i,o)
case"tag":return function(r){return s.getName(r)===t.name&&e(r)}
case"descendant":if(!1===r.cacheResults||"undefined"==typeof WeakSet)return function(t){var r=t
for(;r=s.getParent(r);)if(s.isTag(r)&&e(r))return!0
return!1}
var c=new WeakSet
return function(t){var r=t
for(;r=s.getParent(r);)if(!c.has(r)){if(s.isTag(r)&&e(r))return!0
c.add(r)}return!1}
case"_flexibleDescendant":return function(t){var r=t
do{if(s.isTag(r)&&e(r))return!0}while(r=s.getParent(r))
return!1}
case"parent":if(r.strict)throw new Error("Parent selector isn't part of CSS3")
return function(t){return s.getChildren(t).some((function(t){return s.isTag(t)&&e(t)}))}
case"child":return function(t){var r=s.getParent(t)
return!!r&&s.isTag(r)&&e(r)}
case"sibling":return function(t){var r=s.getSiblings(t)
for(var n=0;n<r.length;n++){var a=r[n]
if(l(t,a))break
if(s.isTag(a)&&e(a))return!0}return!1}
case"adjacent":return function(t){var r=s.getSiblings(t)
var n
for(var a=0;a<r.length;a++){var i=r[a]
if(l(t,i))break
s.isTag(i)&&(n=i)}return!!n&&e(n)}
case"universal":return e}}},7133:function(e,t,r){"use strict"
var n=this&&this.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r)
Object.defineProperty(e,n,{enumerable:!0,get:function(){return t[r]}})}:function(e,t,r,n){void 0===n&&(n=r)
e[n]=t[r]})
var a=this&&this.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t})
var i=this&&this.__importStar||function(e){if(e&&e.__esModule)return e
var t={}
if(null!=e)for(var r in e)"default"!==r&&Object.prototype.hasOwnProperty.call(e,r)&&n(t,e,r)
a(t,e)
return t}
Object.defineProperty(t,"__esModule",{value:!0})
t.pseudos=t.filters=t.is=t.selectOne=t.selectAll=t.prepareContext=t._compileToken=t._compileUnsafe=t.compile=void 0
var o=i(r(5511))
var s=r(7544)
var l=r(3999)
var c=r(457)
var d=function(e,t){return e===t}
var u={adapter:o,equals:d}
function p(e){var t,r,n,a
var i=null!=e?e:u
null!==(t=i.adapter)&&void 0!==t||(i.adapter=o)
null!==(r=i.equals)&&void 0!==r||(i.equals=null!==(a=null===(n=i.adapter)||void 0===n?void 0:n.equals)&&void 0!==a?a:d)
return i}function m(e){return function(t,r,n){var a=p(r)
return e(t,a,n)}}t.compile=m(l.compile)
t._compileUnsafe=m(l.compileUnsafe)
t._compileToken=m(l.compileToken)
function f(e){return function(t,r,n){var a=p(n)
"function"!=typeof t&&(t=l.compileUnsafe(t,a,r))
var i=h(r,a.adapter,t.shouldTestNextSiblings)
return e(t,i,a)}}function h(e,t,r){void 0===r&&(r=!1)
r&&(e=function(e,t){var r=Array.isArray(e)?e.slice(0):[e]
for(var n=0;n<r.length;n++){var a=c.getNextSiblings(r[n],t)
r.push.apply(r,a)}return r}(e,t))
return Array.isArray(e)?t.removeSubsets(e):t.getChildren(e)}t.prepareContext=h
t.selectAll=f((function(e,t,r){return e!==s.falseFunc&&t&&0!==t.length?r.adapter.findAll(e,t):[]}))
t.selectOne=f((function(e,t,r){return e!==s.falseFunc&&t&&0!==t.length?r.adapter.findOne(e,t):null}))
t.is=function(e,t,r){var n=p(r)
return("function"==typeof t?t:l.compile(t,n))(e)}
t.default=t.selectAll
var g=r(8896)
Object.defineProperty(t,"filters",{enumerable:!0,get:function(){return g.filters}})
Object.defineProperty(t,"pseudos",{enumerable:!0,get:function(){return g.pseudos}})},157:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.isTraversal=t.procedure=void 0
t.procedure={universal:50,tag:30,attribute:1,pseudo:0,"pseudo-element":0,descendant:-1,child:-1,parent:-1,sibling:-1,adjacent:-1,_flexibleDescendant:-1}
t.isTraversal=function(e){return t.procedure[e.type]<0}},6636:function(e,t,r){"use strict"
var n=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}}
Object.defineProperty(t,"__esModule",{value:!0})
t.filters=void 0
var a=n(r(1316))
var i=r(7544)
var o=r(8221).attributeRules.equals
function s(e,t){var r={type:"attribute",action:"equals",ignoreCase:!1,namespace:null,name:e,value:t}
return function(e,t,n){return o(e,r,n)}}function l(e,t){return function(r){var n=t.getParent(r)
return!!n&&t.isTag(n)&&e(r)}}t.filters={contains:function(e,t,r){var n=r.adapter
return function(r){return e(r)&&n.getText(r).includes(t)}},icontains:function(e,t,r){var n=r.adapter
var a=t.toLowerCase()
return function(t){return e(t)&&n.getText(t).toLowerCase().includes(a)}},"nth-child":function(e,t,r){var n=r.adapter,o=r.equals
var s=a.default(t)
return s===i.falseFunc?i.falseFunc:s===i.trueFunc?l(e,n):function(t){var r=n.getSiblings(t)
var a=0
for(var i=0;i<r.length&&!o(t,r[i]);i++)n.isTag(r[i])&&a++
return s(a)&&e(t)}},"nth-last-child":function(e,t,r){var n=r.adapter,o=r.equals
var s=a.default(t)
return s===i.falseFunc?i.falseFunc:s===i.trueFunc?l(e,n):function(t){var r=n.getSiblings(t)
var a=0
for(var i=r.length-1;i>=0&&!o(t,r[i]);i--)n.isTag(r[i])&&a++
return s(a)&&e(t)}},"nth-of-type":function(e,t,r){var n=r.adapter,o=r.equals
var s=a.default(t)
return s===i.falseFunc?i.falseFunc:s===i.trueFunc?l(e,n):function(t){var r=n.getSiblings(t)
var a=0
for(var i=0;i<r.length;i++){var l=r[i]
if(o(t,l))break
n.isTag(l)&&n.getName(l)===n.getName(t)&&a++}return s(a)&&e(t)}},"nth-last-of-type":function(e,t,r){var n=r.adapter,o=r.equals
var s=a.default(t)
return s===i.falseFunc?i.falseFunc:s===i.trueFunc?l(e,n):function(t){var r=n.getSiblings(t)
var a=0
for(var i=r.length-1;i>=0;i--){var l=r[i]
if(o(t,l))break
n.isTag(l)&&n.getName(l)===n.getName(t)&&a++}return s(a)&&e(t)}},root:function(e,t,r){var n=r.adapter
return function(t){var r=n.getParent(t)
return(null==r||!n.isTag(r))&&e(t)}},scope:function(e,r,n,a){var i=n.equals
return a&&0!==a.length?1===a.length?function(t){return i(a[0],t)&&e(t)}:function(t){return a.includes(t)&&e(t)}:t.filters.root(e,r,n)},checkbox:s("type","checkbox"),file:s("type","file"),password:s("type","password"),radio:s("type","radio"),reset:s("type","reset"),image:s("type","image"),submit:s("type","submit"),hover:function(e,t,r){var n=r.adapter.isHovered
return"function"!=typeof n?i.falseFunc:function(t){return n(t)&&e(t)}},visited:function(e,t,r){var n=r.adapter.isVisited
return"function"!=typeof n?i.falseFunc:function(t){return n(t)&&e(t)}},active:function(e,t,r){var n=r.adapter.isActive
return"function"!=typeof n?i.falseFunc:function(t){return n(t)&&e(t)}}}},8896:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.compilePseudoSelector=t.pseudos=t.filters=void 0
var n=r(7544)
var a=r(6636)
Object.defineProperty(t,"filters",{enumerable:!0,get:function(){return a.filters}})
var i=r(7191)
Object.defineProperty(t,"pseudos",{enumerable:!0,get:function(){return i.pseudos}})
var o=r(457)
var s=/^(?:(?:nth|last|first|only)-(?:child|of-type)|root|empty|(?:en|dis)abled|checked|not)$/
t.compilePseudoSelector=function(e,t,r,l,c){var d=t.name,u=t.data
if(r.strict&&!s.test(d))throw new Error(":"+d+" isn't part of CSS3")
if(Array.isArray(u))return o.subselects[d](e,u,r,l,c)
if(d in a.filters)return a.filters[d](e,u,r,l)
if(d in i.pseudos){var p=i.pseudos[d]
i.verifyPseudoArgs(p,d,u)
return p===n.falseFunc?n.falseFunc:e===n.trueFunc?function(e){return p(e,r,u)}:function(t){return p(t,r,u)&&e(t)}}throw new Error("unmatched pseudo-class :"+d)}},7191:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.verifyPseudoArgs=t.pseudos=void 0
var r=n(["a","area","link"])
t.pseudos={empty:function(e,t){var r=t.adapter
return!r.getChildren(e).some((function(e){return r.isTag(e)||""!==r.getText(e)}))},"first-child":function(e,t){var r=t.adapter,n=t.equals
var a=r.getSiblings(e).find((function(e){return r.isTag(e)}))
return null!=a&&n(e,a)},"last-child":function(e,t){var r=t.adapter,n=t.equals
var a=r.getSiblings(e)
for(var i=a.length-1;i>=0;i--){if(n(e,a[i]))return!0
if(r.isTag(a[i]))break}return!1},"first-of-type":function(e,t){var r=t.adapter,n=t.equals
var a=r.getSiblings(e)
var i=r.getName(e)
for(var o=0;o<a.length;o++){var s=a[o]
if(n(e,s))return!0
if(r.isTag(s)&&r.getName(s)===i)break}return!1},"last-of-type":function(e,t){var r=t.adapter,n=t.equals
var a=r.getSiblings(e)
var i=r.getName(e)
for(var o=a.length-1;o>=0;o--){var s=a[o]
if(n(e,s))return!0
if(r.isTag(s)&&r.getName(s)===i)break}return!1},"only-of-type":function(e,t){var r=t.adapter,n=t.equals
var a=r.getName(e)
return r.getSiblings(e).every((function(t){return n(e,t)||!r.isTag(t)||r.getName(t)!==a}))},"only-child":function(e,t){var r=t.adapter,n=t.equals
return r.getSiblings(e).every((function(t){return n(e,t)||!r.isTag(t)}))},"any-link":function(e,t){return r(e,t)&&t.adapter.hasAttrib(e,"href")},link:function(e,r){var n,a
return!0!==(null===(a=(n=r.adapter).isVisited)||void 0===a?void 0:a.call(n,e))&&t.pseudos["any-link"](e,r)},selected:function(e,t){var r=t.adapter,n=t.equals
if(r.hasAttrib(e,"selected"))return!0
if("option"!==r.getName(e))return!1
var a=r.getParent(e)
if(!a||!r.isTag(a)||"select"!==r.getName(a)||r.hasAttrib(a,"multiple"))return!1
var i=r.getChildren(a)
var o=!1
for(var s=0;s<i.length;s++){var l=i[s]
if(r.isTag(l))if(n(e,l))o=!0
else{if(!o)return!1
if(r.hasAttrib(l,"selected"))return!1}}return o},disabled:function(e,t){return t.adapter.hasAttrib(e,"disabled")},enabled:function(e,t){return!t.adapter.hasAttrib(e,"disabled")},checked:function(e,r){return r.adapter.hasAttrib(e,"checked")||t.pseudos.selected(e,r)},required:function(e,t){return t.adapter.hasAttrib(e,"required")},optional:function(e,t){return!t.adapter.hasAttrib(e,"required")},parent:function(e,r){return!t.pseudos.empty(e,r)},header:n(["h1","h2","h3","h4","h5","h6"]),button:function(e,t){var r=t.adapter
var n=r.getName(e)
return"button"===n||"input"===n&&"button"===r.getAttributeValue(e,"type")},input:n(["input","textarea","select","button"]),text:function(e,t){var r=t.adapter
var n=r.getAttributeValue(e,"type")
return"input"===r.getName(e)&&(!n||"text"===n.toLowerCase())}}
function n(e){if("undefined"!=typeof Set){var t=new Set(e)
return function(e,r){var n=r.adapter
return t.has(n.getName(e))}}return function(t,r){var n=r.adapter
return e.includes(n.getName(t))}}t.verifyPseudoArgs=function(e,t,r){if(null===r){if(e.length>2&&"scope"!==t)throw new Error("pseudo-selector :"+t+" requires an argument")}else if(2===e.length)throw new Error("pseudo-selector :"+t+" doesn't have any arguments")}},457:function(e,t,r){"use strict"
var n=this&&this.__spreadArrays||function(){for(var e=0,t=0,r=arguments.length;t<r;t++)e+=arguments[t].length
var n=Array(e),a=0
for(t=0;t<r;t++)for(var i=arguments[t],o=0,s=i.length;o<s;o++,a++)n[a]=i[o]
return n}
Object.defineProperty(t,"__esModule",{value:!0})
t.subselects=t.getNextSiblings=t.ensureIsTag=t.PLACEHOLDER_ELEMENT=void 0
var a=r(7544)
var i=r(157)
t.PLACEHOLDER_ELEMENT={}
function o(e){return e.some(i.isTraversal)}function s(e,t){return e===a.falseFunc?e:function(r){return t.isTag(r)&&e(r)}}t.ensureIsTag=s
function l(e,t){var r=t.getSiblings(e)
if(r.length<=1)return[]
var n=r.indexOf(e)
return n<0||n===r.length-1?[]:r.slice(n+1).filter(t.isTag)}t.getNextSiblings=l
t.subselects={is:function(e,r,n,a,i){return t.subselects.matches(e,r,n,a,i)},matches:function(e,t,r,n,a){return a(t,{xmlMode:!!r.xmlMode,strict:!!r.strict,adapter:r.adapter,equals:r.equals,rootFunc:e},n)},not:function(e,t,r,n,i){var s={xmlMode:!!r.xmlMode,strict:!!r.strict,adapter:r.adapter,equals:r.equals}
if(s.strict&&(t.length>1||t.some(o)))throw new Error("complex selectors in :not aren't allowed in strict mode")
var l=i(t,s,n)
return l===a.falseFunc?e:l===a.trueFunc?a.falseFunc:function(t){return!l(t)&&e(t)}},has:function(e,r,i,c,d){var u=i.adapter
var p={xmlMode:!!i.xmlMode,strict:!!i.strict,adapter:u,equals:i.equals}
var m=r.some(o)?[t.PLACEHOLDER_ELEMENT]:void 0
var f=d(r,p,m)
if(f===a.falseFunc)return a.falseFunc
if(f===a.trueFunc)return function(t){return u.getChildren(t).some(u.isTag)&&e(t)}
var h=s(f,u)
var g=f.shouldTestNextSiblings,v=void 0!==g&&g
return m?function(t){m[0]=t
var r=u.getChildren(t)
var a=v?n(r,l(t,u)):r
return e(t)&&u.existsOne(h,a)}:function(t){return e(t)&&u.existsOne(h,u.getChildren(t))}}}},1766:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
var n=r(157)
var a={exists:10,equals:8,not:7,start:6,end:6,any:5,hyphen:4,element:4}
t.default=function(e){var t=e.map(i)
for(var r=1;r<e.length;r++){var n=t[r]
if(!(n<0))for(var a=r-1;a>=0&&n<t[a];a--){var o=e[a+1]
e[a+1]=e[a]
e[a]=o
t[a+1]=t[a]
t[a]=n}}}
function i(e){var t=n.procedure[e.type]
if("attribute"===e.type){(t=a[e.action])===a.equals&&"id"===e.name&&(t=9)
e.ignoreCase&&(t>>=1)}else if("pseudo"===e.type)if(e.data)if("has"===e.name||"contains"===e.name)t=0
else if(Array.isArray(e.data)){t=0
for(var r=0;r<e.data.length;r++)if(1===e.data[r].length){var o=i(e.data[r][0])
if(0===o){t=0
break}o>t&&(t=o)}e.data.length>1&&t>0&&(t-=1)}else t=1
else t=3
return t}},7681:(e,t,r)=>{const n=r(3523)
const a=r(5863)
const i=r(9023)
const o=r(5909)
const s=/^\s*\|\s*/
function l(e,t){const r={}
for(const t in e)r[t]=e[t].syntax||e[t]
for(const n in t)n in e?t[n].syntax?r[n]=s.test(t[n].syntax)?r[n]+" "+t[n].syntax.trim():t[n].syntax:delete r[n]:t[n].syntax&&(r[n]=t[n].syntax.replace(s,""))
return r}function c(e){const t={}
for(const r in e)t[r]=e[r].syntax
return t}e.exports={types:l(i,o.syntaxes),atrules:function(e,t){const r={}
for(const n in e){const a=t[n]&&t[n].descriptors||null
r[n]={prelude:n in t&&"prelude"in t[n]?t[n].prelude:e[n].prelude||null,descriptors:e[n].descriptors?l(e[n].descriptors,a||{}):a&&c(a)}}for(const n in t)hasOwnProperty.call(e,n)||(r[n]={prelude:t[n].prelude||null,descriptors:t[n].descriptors&&c(t[n].descriptors)})
return r}(function(e){const t=Object.create(null)
for(const r in e){const n=e[r]
let a=null
if(n.descriptors){a=Object.create(null)
for(const e in n.descriptors)a[e]=n.descriptors[e].syntax}t[r.substr(1)]={prelude:n.syntax.trim().match(/^@\S+\s+([^;\{]*)/)[1].trim()||null,descriptors:a}}return t}(n),o.atrules),properties:l(a,o.properties)}},1922:e=>{function t(e){return{prev:null,next:null,data:e}}function r(e,t,r){var n
if(null!==a){n=a
a=a.cursor
n.prev=t
n.next=r
n.cursor=e.cursor}else n={prev:t,next:r,cursor:e.cursor}
e.cursor=n
return n}function n(e){var t=e.cursor
e.cursor=t.cursor
t.prev=null
t.next=null
t.cursor=a
a=t}var a=null
var i=function(){this.cursor=null
this.head=null
this.tail=null}
i.createItem=t
i.prototype.createItem=t
i.prototype.updateCursors=function(e,t,r,n){var a=this.cursor
for(;null!==a;){a.prev===e&&(a.prev=t)
a.next===r&&(a.next=n)
a=a.cursor}}
i.prototype.getSize=function(){var e=0
var t=this.head
for(;t;){e++
t=t.next}return e}
i.prototype.fromArray=function(e){var r=null
this.head=null
for(var n=0;n<e.length;n++){var a=t(e[n])
null!==r?r.next=a:this.head=a
a.prev=r
r=a}this.tail=r
return this}
i.prototype.toArray=function(){var e=this.head
var t=[]
for(;e;){t.push(e.data)
e=e.next}return t}
i.prototype.toJSON=i.prototype.toArray
i.prototype.isEmpty=function(){return null===this.head}
i.prototype.first=function(){return this.head&&this.head.data}
i.prototype.last=function(){return this.tail&&this.tail.data}
i.prototype.each=function(e,t){var a
void 0===t&&(t=this)
var i=r(this,null,this.head)
for(;null!==i.next;){a=i.next
i.next=a.next
e.call(t,a.data,a,this)}n(this)}
i.prototype.forEach=i.prototype.each
i.prototype.eachRight=function(e,t){var a
void 0===t&&(t=this)
var i=r(this,this.tail,null)
for(;null!==i.prev;){a=i.prev
i.prev=a.prev
e.call(t,a.data,a,this)}n(this)}
i.prototype.forEachRight=i.prototype.eachRight
i.prototype.reduce=function(e,t,a){var i
void 0===a&&(a=this)
var o=r(this,null,this.head)
var s=t
for(;null!==o.next;){i=o.next
o.next=i.next
s=e.call(a,s,i.data,i,this)}n(this)
return s}
i.prototype.reduceRight=function(e,t,a){var i
void 0===a&&(a=this)
var o=r(this,this.tail,null)
var s=t
for(;null!==o.prev;){i=o.prev
o.prev=i.prev
s=e.call(a,s,i.data,i,this)}n(this)
return s}
i.prototype.nextUntil=function(e,t,a){if(null!==e){var i
void 0===a&&(a=this)
var o=r(this,null,e)
for(;null!==o.next;){i=o.next
o.next=i.next
if(t.call(a,i.data,i,this))break}n(this)}}
i.prototype.prevUntil=function(e,t,a){if(null!==e){var i
void 0===a&&(a=this)
var o=r(this,e,null)
for(;null!==o.prev;){i=o.prev
o.prev=i.prev
if(t.call(a,i.data,i,this))break}n(this)}}
i.prototype.some=function(e,t){var r=this.head
void 0===t&&(t=this)
for(;null!==r;){if(e.call(t,r.data,r,this))return!0
r=r.next}return!1}
i.prototype.map=function(e,t){var r=new i
var n=this.head
void 0===t&&(t=this)
for(;null!==n;){r.appendData(e.call(t,n.data,n,this))
n=n.next}return r}
i.prototype.filter=function(e,t){var r=new i
var n=this.head
void 0===t&&(t=this)
for(;null!==n;){e.call(t,n.data,n,this)&&r.appendData(n.data)
n=n.next}return r}
i.prototype.clear=function(){this.head=null
this.tail=null}
i.prototype.copy=function(){var e=new i
var r=this.head
for(;null!==r;){e.insert(t(r.data))
r=r.next}return e}
i.prototype.prepend=function(e){this.updateCursors(null,e,this.head,e)
if(null!==this.head){this.head.prev=e
e.next=this.head}else this.tail=e
this.head=e
return this}
i.prototype.prependData=function(e){return this.prepend(t(e))}
i.prototype.append=function(e){return this.insert(e)}
i.prototype.appendData=function(e){return this.insert(t(e))}
i.prototype.insert=function(e,t){if(null!=t){this.updateCursors(t.prev,e,t,e)
if(null===t.prev){if(this.head!==t)throw new Error("before doesn't belong to list")
this.head=e
t.prev=e
e.next=t
this.updateCursors(null,e)}else{t.prev.next=e
e.prev=t.prev
t.prev=e
e.next=t}}else{this.updateCursors(this.tail,e,null,e)
if(null!==this.tail){this.tail.next=e
e.prev=this.tail}else this.head=e
this.tail=e}return this}
i.prototype.insertData=function(e,r){return this.insert(t(e),r)}
i.prototype.remove=function(e){this.updateCursors(e,e.prev,e,e.next)
if(null!==e.prev)e.prev.next=e.next
else{if(this.head!==e)throw new Error("item doesn't belong to list")
this.head=e.next}if(null!==e.next)e.next.prev=e.prev
else{if(this.tail!==e)throw new Error("item doesn't belong to list")
this.tail=e.prev}e.prev=null
e.next=null
return e}
i.prototype.push=function(e){this.insert(t(e))}
i.prototype.pop=function(){if(null!==this.tail)return this.remove(this.tail)}
i.prototype.unshift=function(e){this.prepend(t(e))}
i.prototype.shift=function(){if(null!==this.head)return this.remove(this.head)}
i.prototype.prependList=function(e){return this.insertList(e,this.head)}
i.prototype.appendList=function(e){return this.insertList(e)}
i.prototype.insertList=function(e,t){if(null===e.head)return this
if(null!=t){this.updateCursors(t.prev,e.tail,t,e.head)
if(null!==t.prev){t.prev.next=e.head
e.head.prev=t.prev}else this.head=e.head
t.prev=e.tail
e.tail.next=t}else{this.updateCursors(this.tail,e.tail,null,e.head)
if(null!==this.tail){this.tail.next=e.head
e.head.prev=this.tail}else this.head=e.head
this.tail=e.tail}e.head=null
e.tail=null
return this}
i.prototype.replace=function(e,t){"head"in t?this.insertList(t,e):this.insert(t,e)
this.remove(e)}
e.exports=i},2060:(e,t,r)=>{var n=r(6048)
var a=r(8074).isBOM
var i=function(){this.lines=null
this.columns=null
this.linesAndColumnsComputed=!1}
i.prototype={setSource:function(e,t,r,n){this.source=e
this.startOffset=void 0===t?0:t
this.startLine=void 0===r?1:r
this.startColumn=void 0===n?1:n
this.linesAndColumnsComputed=!1},ensureLinesAndColumnsComputed:function(){if(!this.linesAndColumnsComputed){!function(e,t){var r=t.length
var i=n(e.lines,r)
var o=e.startLine
var s=n(e.columns,r)
var l=e.startColumn
for(var c=t.length>0?a(t.charCodeAt(0)):0;c<r;c++){var d=t.charCodeAt(c)
i[c]=o
s[c]=l++
if(10===d||13===d||12===d){if(13===d&&c+1<r&&10===t.charCodeAt(c+1)){i[++c]=o
s[c]=l}o++
l=1}}i[c]=o
s[c]=l
e.lines=i
e.columns=s}(this,this.source)
this.linesAndColumnsComputed=!0}},getLocation:function(e,t){this.ensureLinesAndColumnsComputed()
return{source:t,offset:this.startOffset+e,line:this.lines[e],column:this.columns[e]}},getLocationRange:function(e,t,r){this.ensureLinesAndColumnsComputed()
return{source:r,start:{offset:this.startOffset+e,line:this.lines[e],column:this.columns[e]},end:{offset:this.startOffset+t,line:this.lines[t],column:this.columns[t]}}}}
e.exports=i},2325:(e,t,r)=>{var n=r(3095)
var a="    "
function i(e,t){function r(e,t){return n.slice(e,t).map((function(t,r){var n=String(e+r+1)
for(;n.length<c;)n=" "+n
return n+" |"+t})).join("\n")}var n=e.source.split(/\r\n?|\n|\f/)
var i=e.line
var o=e.column
var s=Math.max(1,i-t)-1
var l=Math.min(i+t,n.length+1)
var c=Math.max(4,String(l).length)+1
var d=0
if((o+=(a.length-1)*(n[i-1].substr(0,o-1).match(/\t/g)||[]).length)>100){d=o-60+3
o=58}for(var u=s;u<=l;u++)if(u>=0&&u<n.length){n[u]=n[u].replace(/\t/g,a)
n[u]=(d>0&&n[u].length>d?"…":"")+n[u].substr(d,98)+(n[u].length>d+100-1?"…":"")}return[r(s,i),new Array(o+c+2).join("-")+"^",r(i,l)].filter(Boolean).join("\n")}e.exports=function(e,t,r,a,o){var s=n("SyntaxError",e)
s.source=t
s.offset=r
s.line=a
s.column=o
s.sourceFragment=function(e){return i(s,isNaN(e)?0:e)}
Object.defineProperty(s,"formattedMessage",{get:function(){return"Parse error: "+s.message+"\n"+i(s,2)}})
s.parseError={offset:r,line:a,column:o}
return s}},6418:(e,t,r)=>{var n=r(9856)
var a=n.TYPE
var i=n.NAME
var o=r(456).cmpStr
var s=a.EOF
var l=a.WhiteSpace
var c=a.Comment
var d=16777215
var u=24
var p=function(){this.offsetAndType=null
this.balance=null
this.reset()}
p.prototype={reset:function(){this.eof=!1
this.tokenIndex=-1
this.tokenType=0
this.tokenStart=this.firstCharOffset
this.tokenEnd=this.firstCharOffset},lookupType:function(e){return(e+=this.tokenIndex)<this.tokenCount?this.offsetAndType[e]>>u:s},lookupOffset:function(e){return(e+=this.tokenIndex)<this.tokenCount?this.offsetAndType[e-1]&d:this.source.length},lookupValue:function(e,t){return(e+=this.tokenIndex)<this.tokenCount&&o(this.source,this.offsetAndType[e-1]&d,this.offsetAndType[e]&d,t)},getTokenStart:function(e){return e===this.tokenIndex?this.tokenStart:e>0?e<this.tokenCount?this.offsetAndType[e-1]&d:this.offsetAndType[this.tokenCount]&d:this.firstCharOffset},getRawLength:function(e,t){var r=e
var n
var a=this.offsetAndType[Math.max(r-1,0)]&d
e:for(;r<this.tokenCount&&!((n=this.balance[r])<e);r++)switch(t(this.offsetAndType[r]>>u,this.source,a)){case 1:break e
case 2:r++
break e
default:a=this.offsetAndType[r]&d
this.balance[n]===r&&(r=n)}return r-this.tokenIndex},isBalanceEdge:function(e){return this.balance[this.tokenIndex]<e},isDelim:function(e,t){return t?this.lookupType(t)===a.Delim&&this.source.charCodeAt(this.lookupOffset(t))===e:this.tokenType===a.Delim&&this.source.charCodeAt(this.tokenStart)===e},getTokenValue:function(){return this.source.substring(this.tokenStart,this.tokenEnd)},getTokenLength:function(){return this.tokenEnd-this.tokenStart},substrToCursor:function(e){return this.source.substring(e,this.tokenStart)},skipWS:function(){for(var e=this.tokenIndex,t=0;e<this.tokenCount&&this.offsetAndType[e]>>u===l;e++,t++);t>0&&this.skip(t)},skipSC:function(){for(;this.tokenType===l||this.tokenType===c;)this.next()},skip:function(e){var t=this.tokenIndex+e
if(t<this.tokenCount){this.tokenIndex=t
this.tokenStart=this.offsetAndType[t-1]&d
t=this.offsetAndType[t]
this.tokenType=t>>u
this.tokenEnd=t&d}else{this.tokenIndex=this.tokenCount
this.next()}},next:function(){var e=this.tokenIndex+1
if(e<this.tokenCount){this.tokenIndex=e
this.tokenStart=this.tokenEnd
e=this.offsetAndType[e]
this.tokenType=e>>u
this.tokenEnd=e&d}else{this.tokenIndex=this.tokenCount
this.eof=!0
this.tokenType=s
this.tokenStart=this.tokenEnd=this.source.length}},forEachToken(e){for(var t=0,r=this.firstCharOffset;t<this.tokenCount;t++){var n=r
var a=this.offsetAndType[t]
var i=a&d
r=i
e(a>>u,n,i,t)}},dump(){var e=new Array(this.tokenCount)
this.forEachToken(((t,r,n,a)=>{e[a]={idx:a,type:i[t],chunk:this.source.substring(r,n),balance:this.balance[a]}}))
return e}}
e.exports=p},6048:e=>{var t="undefined"!=typeof Uint32Array?Uint32Array:Array
e.exports=function(e,r){return null===e||e.length<r?new t(Math.max(r+1024,16384)):e}},7851:(e,t,r)=>{var n=r(1922)
e.exports=function(e){return{fromPlainObject:function(t){e(t,{enter:function(e){e.children&&e.children instanceof n==0&&(e.children=(new n).fromArray(e.children))}})
return t},toPlainObject:function(t){e(t,{leave:function(e){e.children&&e.children instanceof n&&(e.children=e.children.toArray())}})
return t}}}},2302:(e,t,r)=>{var n=r(3095)
e.exports=function(e,t,r){var a=n("SyntaxError",e)
a.input=t
a.offset=r
a.rawMessage=e
a.message=a.rawMessage+"\n  "+a.input+"\n--"+new Array((a.offset||a.input.length)+1).join("-")+"^"
return a}},525:e=>{function t(e){return e}function r(e,t,n,a){var i
switch(e.type){case"Group":i=function(e,t,n,a){var i=" "===e.combinator||a?e.combinator:" "+e.combinator+" "
var o=e.terms.map((function(e){return r(e,t,n,a)})).join(i);(e.explicit||n)&&(o=(a||","===o[0]?"[":"[ ")+o+(a?"]":" ]"))
return o}(e,t,n,a)+(e.disallowEmpty?"!":"")
break
case"Multiplier":return r(e.term,t,n,a)+t(0===(o=e).min&&0===o.max?"*":0===o.min&&1===o.max?"?":1===o.min&&0===o.max?o.comma?"#":"+":1===o.min&&1===o.max?"":(o.comma?"#":"")+(o.min===o.max?"{"+o.min+"}":"{"+o.min+","+(0!==o.max?o.max:"")+"}"),e)
case"Type":i="<"+e.name+(e.opts?t(function(e){switch(e.type){case"Range":return" ["+(null===e.min?"-∞":e.min)+","+(null===e.max?"∞":e.max)+"]"
default:throw new Error("Unknown node type `"+e.type+"`")}}(e.opts),e.opts):"")+">"
break
case"Property":i="<'"+e.name+"'>"
break
case"Keyword":i=e.name
break
case"AtKeyword":i="@"+e.name
break
case"Function":i=e.name+"("
break
case"String":case"Token":i=e.value
break
case"Comma":i=","
break
default:throw new Error("Unknown node type `"+e.type+"`")}var o
return t(i,e)}e.exports=function(e,n){var a=t
var i=!1
var o=!1
if("function"==typeof n)a=n
else if(n){i=Boolean(n.forceBraces)
o=Boolean(n.compact)
"function"==typeof n.decorate&&(a=n.decorate)}return r(e,a,i,o)}},9540:(e,t,r)=>{e.exports={SyntaxError:r(2302),parse:r(8078),generate:r(525),walk:r(8264)}},8078:(e,t,r)=>{var n=r(8889)
var a=123
var i=function(e){var t="function"==typeof Uint32Array?new Uint32Array(128):new Array(128)
for(var r=0;r<128;r++)t[r]=e(String.fromCharCode(r))?1:0
return t}((function(e){return/[a-zA-Z0-9\-]/.test(e)}))
var o={" ":1,"&&":2,"||":3,"|":4}
function s(e){return e.substringToPos(e.findWsEnd(e.pos))}function l(e){var t=e.pos
for(;t<e.str.length;t++){var r=e.str.charCodeAt(t)
if(r>=128||0===i[r])break}e.pos===t&&e.error("Expect a keyword")
return e.substringToPos(t)}function c(e){var t=e.pos
for(;t<e.str.length;t++){var r=e.str.charCodeAt(t)
if(r<48||r>57)break}e.pos===t&&e.error("Expect a number")
return e.substringToPos(t)}function d(e){var t=e.str.indexOf("'",e.pos+1)
if(-1===t){e.pos=e.str.length
e.error("Expect an apostrophe")}return e.substringToPos(t+1)}function u(e){var t
var r=null
e.eat(a)
t=c(e)
if(44===e.charCode()){e.pos++
125!==e.charCode()&&(r=c(e))}else r=t
e.eat(125)
return{min:Number(t),max:r?Number(r):0}}function p(e,t){var r=function(e){var t=null
var r=!1
switch(e.charCode()){case 42:e.pos++
t={min:0,max:0}
break
case 43:e.pos++
t={min:1,max:0}
break
case 63:e.pos++
t={min:0,max:1}
break
case 35:e.pos++
r=!0
t=e.charCode()===a?u(e):{min:1,max:0}
break
case a:t=u(e)
break
default:return null}return{type:"Multiplier",comma:r,min:t.min,max:t.max,term:null}}(e)
if(null!==r){r.term=t
return r}return t}function m(e){var t=e.peek()
return""===t?null:{type:"Token",value:t}}function f(e,t){function r(e,t){return{type:"Group",terms:e,combinator:t,disallowEmpty:!1,explicit:!1}}t=Object.keys(t).sort((function(e,t){return o[e]-o[t]}))
for(;t.length>0;){var n=t.shift()
for(var a=0,i=0;a<e.length;a++){var s=e[a]
if("Combinator"===s.type)if(s.value===n){-1===i&&(i=a-1)
e.splice(a,1)
a--}else{if(-1!==i&&a-i>1){e.splice(i,a-i,r(e.slice(i,a),n))
a=i+1}i=-1}}-1!==i&&t.length&&e.splice(i,a-i,r(e.slice(i,a),n))}return n}function h(e){var t=[]
var r={}
var n
var a=null
var i=e.pos
for(;n=g(e);)if("Spaces"!==n.type){if("Combinator"===n.type){if(null===a||"Combinator"===a.type){e.pos=i
e.error("Unexpected combinator")}r[n.value]=!0}else if(null!==a&&"Combinator"!==a.type){r[" "]=!0
t.push({type:"Combinator",value:" "})}t.push(n)
a=n
i=e.pos}if(null!==a&&"Combinator"===a.type){e.pos-=i
e.error("Unexpected combinator")}return{type:"Group",terms:t,combinator:f(t,r)||" ",disallowEmpty:!1,explicit:!1}}function g(e){var t=e.charCode()
if(t<128&&1===i[t])return function(e){var t
t=l(e)
if(40===e.charCode()){e.pos++
return{type:"Function",name:t}}return p(e,{type:"Keyword",name:t})}(e)
switch(t){case 93:break
case 91:return p(e,function(e){var t
e.eat(91)
t=h(e)
e.eat(93)
t.explicit=!0
if(33===e.charCode()){e.pos++
t.disallowEmpty=!0}return t}(e))
case 60:return 39===e.nextCharCode()?function(e){var t
e.eat(60)
e.eat(39)
t=l(e)
e.eat(39)
e.eat(62)
return p(e,{type:"Property",name:t})}(e):function(e){var t
var r=null
e.eat(60)
t=l(e)
if(40===e.charCode()&&41===e.nextCharCode()){e.pos+=2
t+="()"}if(91===e.charCodeAt(e.findWsEnd(e.pos))){s(e)
r=function(e){var t=null
var r=null
var n=1
e.eat(91)
if(45===e.charCode()){e.peek()
n=-1}-1==n&&8734===e.charCode()?e.peek():t=n*Number(c(e))
s(e)
e.eat(44)
s(e)
if(8734===e.charCode())e.peek()
else{n=1
if(45===e.charCode()){e.peek()
n=-1}r=n*Number(c(e))}e.eat(93)
return null===t&&null===r?null:{type:"Range",min:t,max:r}}(e)}e.eat(62)
return p(e,{type:"Type",name:t,opts:r})}(e)
case 124:return{type:"Combinator",value:e.substringToPos(124===e.nextCharCode()?e.pos+2:e.pos+1)}
case 38:e.pos++
e.eat(38)
return{type:"Combinator",value:"&&"}
case 44:e.pos++
return{type:"Comma"}
case 39:return p(e,{type:"String",value:d(e)})
case 32:case 9:case 10:case 13:case 12:return{type:"Spaces",value:s(e)}
case 64:if((t=e.nextCharCode())<128&&1===i[t]){e.pos++
return{type:"AtKeyword",name:l(e)}}return m(e)
case 42:case 43:case 63:case 35:case 33:break
case a:if((t=e.nextCharCode())<48||t>57)return m(e)
break
default:return m(e)}}function v(e){var t=new n(e)
var r=h(t)
t.pos!==e.length&&t.error("Unexpected input")
1===r.terms.length&&"Group"===r.terms[0].type&&(r=r.terms[0])
return r}v("[a&&<b>#|<'c'>*||e() f{2} /,(% g#{1,2} h{2,})]!")
e.exports=v},8889:(e,t,r)=>{var n=r(2302)
var a=function(e){this.str=e
this.pos=0}
a.prototype={charCodeAt:function(e){return e<this.str.length?this.str.charCodeAt(e):0},charCode:function(){return this.charCodeAt(this.pos)},nextCharCode:function(){return this.charCodeAt(this.pos+1)},nextNonWsCode:function(e){return this.charCodeAt(this.findWsEnd(e))},findWsEnd:function(e){for(;e<this.str.length;e++){var t=this.str.charCodeAt(e)
if(13!==t&&10!==t&&12!==t&&32!==t&&9!==t)break}return e},substringToPos:function(e){return this.str.substring(this.pos,this.pos=e)},eat:function(e){this.charCode()!==e&&this.error("Expect `"+String.fromCharCode(e)+"`")
this.pos++},peek:function(){return this.pos<this.str.length?this.str.charAt(this.pos++):""},error:function(e){throw new n(e,this.str,this.pos)}}
e.exports=a},8264:e=>{var t=function(){}
function r(e){return"function"==typeof e?e:t}e.exports=function(e,n,a){var i=t
var o=t
if("function"==typeof n)i=n
else if(n){i=r(n.enter)
o=r(n.leave)}if(i===t&&o===t)throw new Error("Neither `enter` nor `leave` walker handler is set or both aren't a function")
!function e(t){i.call(a,t)
switch(t.type){case"Group":t.terms.forEach(e)
break
case"Multiplier":e(t.term)
break
case"Type":case"Property":case"Keyword":case"AtKeyword":case"Function":case"String":case"Token":case"Comma":break
default:throw new Error("Unknown type: "+t.type)}o.call(a,t)}(e)}},2987:(e,t,r)=>{var n=r(9539)
var a=Object.prototype.hasOwnProperty
function i(e,t){var r=e.children
var n=null
"function"!=typeof t?r.forEach(this.node,this):r.forEach((function(e){null!==n&&t.call(this,n)
this.node(e)
n=e}),this)}e.exports=function(e){function t(e){if(!a.call(r,e.type))throw new Error("Unknown node type: "+e.type)
r[e.type].call(this,e)}var r={}
if(e.node)for(var o in e.node)r[o]=e.node[o].generate
return function(e,r){var a=""
var o={children:i,node:t,chunk:function(e){a+=e},result:function(){return a}}
if(r){"function"==typeof r.decorator&&(o=r.decorator(o))
r.sourceMap&&(o=n(o))}o.node(e)
return o.result()}}},9539:(e,t,r)=>{var n=r(2400).h
var a={Atrule:!0,Selector:!0,Declaration:!0}
e.exports=function(e){var t=new n
var r=1
var i=0
var o={line:1,column:0}
var s={line:0,column:0}
var l=!1
var c={line:1,column:0}
var d={generated:c}
var u=e.node
e.node=function(e){if(e.loc&&e.loc.start&&a.hasOwnProperty(e.type)){var n=e.loc.start.line
var p=e.loc.start.column-1
if(s.line!==n||s.column!==p){s.line=n
s.column=p
o.line=r
o.column=i
if(l){l=!1
o.line===c.line&&o.column===c.column||t.addMapping(d)}l=!0
t.addMapping({source:e.loc.source,original:s,generated:o})}}u.call(this,e)
if(l&&a.hasOwnProperty(e.type)){c.line=r
c.column=i}}
var p=e.chunk
e.chunk=function(e){for(var t=0;t<e.length;t++)if(10===e.charCodeAt(t)){r++
i=0}else i++
p(e)}
var m=e.result
e.result=function(){l&&t.addMapping(d)
return{css:m(),map:t}}
return e}},4662:(e,t,r)=>{e.exports=r(2326)},6944:(e,t,r)=>{var n=r(2122).SyntaxReferenceError
var a=r(2122).SyntaxMatchError
var i=r(4266)
var o=r(5323)
var s=r(8078)
var l=r(525)
var c=r(8264)
var d=r(9013)
var u=r(6186).buildMatchGraph
var p=r(8852).matchAsTree
var m=r(2803)
var f=r(5207)
var h=r(2956).getStructureFromConfig
var g=u("inherit | initial | unset")
var v=u("inherit | initial | unset | <-ms-legacy-expression>")
function y(e,t,r){var n={}
for(var a in e)e[a].syntax&&(n[a]=r?e[a].syntax:l(e[a].syntax,{compact:t}))
return n}function b(e,t,r){const n={}
for(const[a,i]of Object.entries(e))n[a]={prelude:i.prelude&&(r?i.prelude.syntax:l(i.prelude.syntax,{compact:t})),descriptors:i.descriptors&&y(i.descriptors,t,r)}
return n}function S(e,t,r){return{matched:e,iterations:r,error:t,getTrace:m.getTrace,isType:m.isType,isProperty:m.isProperty,isKeyword:m.isKeyword}}function x(e,t,r,n){var i=d(r,e.syntax)
var o
if(function(e){for(var t=0;t<e.length;t++)if("var("===e[t].value.toLowerCase())return!0
return!1}(i))return S(null,new Error("Matching for a tree with var() is not supported"))
n&&(o=p(i,e.valueCommonSyntax,e))
return n&&o.match||(o=p(i,t.match,e)).match?S(o.match,null,o.iterations):S(null,new a(o.reason,t.syntax,r,o),o.iterations)}var k=function(e,t,r){this.valueCommonSyntax=g
this.syntax=t
this.generic=!1
this.atrules={}
this.properties={}
this.types={}
this.structure=r||h(e)
if(e){if(e.types)for(var n in e.types)this.addType_(n,e.types[n])
if(e.generic){this.generic=!0
for(var n in o)this.addType_(n,o[n])}if(e.atrules)for(var n in e.atrules)this.addAtrule_(n,e.atrules[n])
if(e.properties)for(var n in e.properties)this.addProperty_(n,e.properties[n])}}
k.prototype={structure:{},checkStructure:function(e){function t(e,t){n.push({node:e,message:t})}var r=this.structure
var n=[]
this.syntax.walk(e,(function(e){r.hasOwnProperty(e.type)?r[e.type].check(e,t):t(e,"Unknown node type `"+e.type+"`")}))
return!!n.length&&n},createDescriptor:function(e,t,r,n=null){var a={type:t,name:r}
var i={type:t,name:r,parent:n,syntax:null,match:null}
if("function"==typeof e)i.match=u(e,a)
else{"string"==typeof e?Object.defineProperty(i,"syntax",{get:function(){Object.defineProperty(i,"syntax",{value:s(e)})
return i.syntax}}):i.syntax=e
Object.defineProperty(i,"match",{get:function(){Object.defineProperty(i,"match",{value:u(i.syntax,a)})
return i.match}})}return i},addAtrule_:function(e,t){t&&(this.atrules[e]={type:"Atrule",name:e,prelude:t.prelude?this.createDescriptor(t.prelude,"AtrulePrelude",e):null,descriptors:t.descriptors?Object.keys(t.descriptors).reduce(((r,n)=>{r[n]=this.createDescriptor(t.descriptors[n],"AtruleDescriptor",n,e)
return r}),{}):null})},addProperty_:function(e,t){t&&(this.properties[e]=this.createDescriptor(t,"Property",e))},addType_:function(e,t){if(t){this.types[e]=this.createDescriptor(t,"Type",e)
t===o["-ms-legacy-expression"]&&(this.valueCommonSyntax=v)}},checkAtruleName:function(e){if(!this.getAtrule(e))return new n("Unknown at-rule","@"+e)},checkAtrulePrelude:function(e,t){let r=this.checkAtruleName(e)
if(r)return r
var n=this.getAtrule(e)
return!n.prelude&&t?new SyntaxError("At-rule `@"+e+"` should not contain a prelude"):n.prelude&&!t?new SyntaxError("At-rule `@"+e+"` should contain a prelude"):void 0},checkAtruleDescriptorName:function(e,t){let r=this.checkAtruleName(e)
if(r)return r
var a=this.getAtrule(e)
var o=i.keyword(t)
return a.descriptors?a.descriptors[o.name]||a.descriptors[o.basename]?void 0:new n("Unknown at-rule descriptor",t):new SyntaxError("At-rule `@"+e+"` has no known descriptors")},checkPropertyName:function(e){return i.property(e).custom?new Error("Lexer matching doesn't applicable for custom properties"):this.getProperty(e)?void 0:new n("Unknown property",e)},matchAtrulePrelude:function(e,t){var r=this.checkAtrulePrelude(e,t)
return r?S(null,r):t?x(this,this.getAtrule(e).prelude,t,!0):S(null,null)},matchAtruleDescriptor:function(e,t,r){var n=this.checkAtruleDescriptorName(e,t)
if(n)return S(null,n)
var a=this.getAtrule(e)
var o=i.keyword(t)
return x(this,a.descriptors[o.name]||a.descriptors[o.basename],r,!0)},matchDeclaration:function(e){return"Declaration"!==e.type?S(null,new Error("Not a Declaration node")):this.matchProperty(e.property,e.value)},matchProperty:function(e,t){var r=this.checkPropertyName(e)
return r?S(null,r):x(this,this.getProperty(e),t,!0)},matchType:function(e,t){var r=this.getType(e)
return r?x(this,r,t,!1):S(null,new n("Unknown type",e))},match:function(e,t){if(!("string"==typeof e||e&&e.type))return S(null,new n("Bad syntax"))
"string"!=typeof e&&e.match||(e=this.createDescriptor(e,"Type","anonymous"))
return x(this,e,t,!1)},findValueFragments:function(e,t,r,n){return f.matchFragments(this,t,this.matchProperty(e,t),r,n)},findDeclarationValueFragments:function(e,t,r){return f.matchFragments(this,e.value,this.matchDeclaration(e),t,r)},findAllFragments:function(e,t,r){var n=[]
this.syntax.walk(e,{visit:"Declaration",enter:function(e){n.push.apply(n,this.findDeclarationValueFragments(e,t,r))}.bind(this)})
return n},getAtrule:function(e,t=!0){var r=i.keyword(e)
return(r.vendor&&t?this.atrules[r.name]||this.atrules[r.basename]:this.atrules[r.name])||null},getAtrulePrelude:function(e,t=!0){const r=this.getAtrule(e,t)
return r&&r.prelude||null},getAtruleDescriptor:function(e,t){return this.atrules.hasOwnProperty(e)&&this.atrules.declarators&&this.atrules[e].declarators[t]||null},getProperty:function(e,t=!0){var r=i.property(e)
return(r.vendor&&t?this.properties[r.name]||this.properties[r.basename]:this.properties[r.name])||null},getType:function(e){return this.types.hasOwnProperty(e)?this.types[e]:null},validate:function(){function e(n,a,i,o){if(i.hasOwnProperty(a))return i[a]
i[a]=!1
null!==o.syntax&&c(o.syntax,(function(o){if("Type"===o.type||"Property"===o.type){var s="Type"===o.type?n.types:n.properties
var l="Type"===o.type?t:r
s.hasOwnProperty(o.name)&&!e(n,o.name,l,s[o.name])||(i[a]=!0)}}),this)}var t={}
var r={}
for(var n in this.types)e(this,n,t,this.types[n])
for(var n in this.properties)e(this,n,r,this.properties[n])
t=Object.keys(t).filter((function(e){return t[e]}))
r=Object.keys(r).filter((function(e){return r[e]}))
return t.length||r.length?{types:t,properties:r}:null},dump:function(e,t){return{generic:this.generic,types:y(this.types,!t,e),properties:y(this.properties,!t,e),atrules:b(this.atrules,!t,e)}},toString:function(){return JSON.stringify(this.dump())}}
e.exports=k},2122:(e,t,r)=>{const n=r(3095)
const a=r(525)
const i={offset:0,line:1,column:1}
function o(e,t){const r=e&&e.loc&&e.loc[t]
return r?"line"in r?s(r):r:null}function s({offset:e,line:t,column:r},n){const a={offset:e,line:t,column:r}
if(n){const e=n.split(/\n|\r\n?|\f/)
a.offset+=n.length
a.line+=e.length-1
a.column=1===e.length?a.column+n.length:e.pop().length+1}return a}e.exports={SyntaxReferenceError:function(e,t){const r=n("SyntaxReferenceError",e+(t?" `"+t+"`":""))
r.reference=t
return r},SyntaxMatchError:function(e,t,r,l){const c=n("SyntaxMatchError",e)
const{css:d,mismatchOffset:u,mismatchLength:p,start:m,end:f}=function(e,t){const r=e.tokens
const n=e.longestMatch
const a=n<r.length&&r[n].node||null
const l=a!==t?a:null
let c=0
let d=0
let u=0
let p=""
let m
let f
for(let e=0;e<r.length;e++){const t=r[e].value
if(e===n){d=t.length
c=p.length}null!==l&&r[e].node===l&&(e<=n?u++:u=0)
p+=t}if(n===r.length||u>1){m=o(l||t,"end")||s(i,p)
f=s(m)}else{m=o(l,"start")||s(o(t,"start")||i,p.slice(0,c))
f=o(l,"end")||s(m,p.substr(c,d))}return{css:p,mismatchOffset:c,mismatchLength:d,start:m,end:f}}(l,r)
c.rawMessage=e
c.syntax=t?a(t):"<generic>"
c.css=d
c.mismatchOffset=u
c.mismatchLength=p
c.message=e+"\n  syntax: "+c.syntax+"\n   value: "+(d||"<empty string>")+"\n  --------"+new Array(c.mismatchOffset+1).join("-")+"^"
Object.assign(c,m)
c.loc={source:r&&r.loc&&r.loc.source||"<unknown>",start:m,end:f}
return c}}},1725:(e,t,r)=>{var n=r(8074).isDigit
var a=r(8074).cmpChar
var i=r(8074).TYPE
var o=i.Delim
var s=i.WhiteSpace
var l=i.Comment
var c=i.Ident
var d=i.Number
var u=i.Dimension
var p=45
var m=!0
function f(e,t){return null!==e&&e.type===o&&e.value.charCodeAt(0)===t}function h(e,t,r){for(;null!==e&&(e.type===s||e.type===l);)e=r(++t)
return t}function g(e,t,r,a){if(!e)return 0
var i=e.value.charCodeAt(t)
if(43===i||i===p){if(r)return 0
t++}for(;t<e.value.length;t++)if(!n(e.value.charCodeAt(t)))return 0
return a+1}function v(e,t,r){var n=!1
var a=h(e,t,r)
if(null===(e=r(a)))return t
if(e.type!==d){if(!f(e,43)&&!f(e,p))return t
n=!0
a=h(r(++a),a,r)
if(null===(e=r(a))&&e.type!==d)return 0}if(!n){var i=e.value.charCodeAt(0)
if(43!==i&&i!==p)return 0}return g(e,n?0:1,n,a)}e.exports=function(e,t){var r=0
if(!e)return 0
if(e.type===d)return g(e,0,!1,r)
if(e.type===c&&e.value.charCodeAt(0)===p){if(!a(e.value,1,110))return 0
switch(e.value.length){case 2:return v(t(++r),r,t)
case 3:if(e.value.charCodeAt(2)!==p)return 0
r=h(t(++r),r,t)
return g(e=t(r),0,m,r)
default:return e.value.charCodeAt(2)!==p?0:g(e,3,m,r)}}else if(e.type===c||f(e,43)&&t(r+1).type===c){e.type!==c&&(e=t(++r))
if(null===e||!a(e.value,0,110))return 0
switch(e.value.length){case 1:return v(t(++r),r,t)
case 2:if(e.value.charCodeAt(1)!==p)return 0
r=h(t(++r),r,t)
return g(e=t(r),0,m,r)
default:return e.value.charCodeAt(1)!==p?0:g(e,2,m,r)}}else if(e.type===u){var i=e.value.charCodeAt(0)
var o=43===i||i===p?1:0
for(var s=o;s<e.value.length&&n(e.value.charCodeAt(s));s++);if(s===o)return 0
if(!a(e.value,s,110))return 0
if(s+1===e.value.length)return v(t(++r),r,t)
if(e.value.charCodeAt(s+1)!==p)return 0
if(s+2===e.value.length){r=h(t(++r),r,t)
return g(e=t(r),0,m,r)}return g(e,s+2,m,r)}return 0}},6435:(e,t,r)=>{var n=r(8074).isHexDigit
var a=r(8074).cmpChar
var i=r(8074).TYPE
var o=i.Ident
var s=i.Delim
var l=i.Number
var c=i.Dimension
function d(e,t){return null!==e&&e.type===s&&e.value.charCodeAt(0)===t}function u(e,t){return e.value.charCodeAt(0)===t}function p(e,t,r){for(var a=t,i=0;a<e.value.length;a++){var o=e.value.charCodeAt(a)
if(45===o&&r&&0!==i)return p(e,t+i+1,!1)>0?6:0
if(!n(o))return 0
if(++i>6)return 0}return i}function m(e,t,r){if(!e)return 0
for(;d(r(t),63);){if(++e>6)return 0
t++}return t}e.exports=function(e,t){var r=0
if(null===e||e.type!==o||!a(e.value,0,117))return 0
if(null===(e=t(++r)))return 0
if(d(e,43))return null===(e=t(++r))?0:e.type===o?m(p(e,0,!0),++r,t):d(e,63)?m(1,++r,t):0
if(e.type===l){if(!u(e,43))return 0
var n=p(e,1,!0)
return 0===n?0:null===(e=t(++r))?r:e.type===c||e.type===l?u(e,45)&&p(e,1,!1)?r+1:0:m(n,r,t)}return e.type===c&&u(e,43)?m(p(e,1,!0),++r,t):0}},5323:(e,t,r)=>{var n=r(8074)
var a=n.isIdentifierStart
var i=n.isHexDigit
var o=n.isDigit
var s=n.cmpStr
var l=n.consumeNumber
var c=n.TYPE
var d=r(1725)
var u=r(6435)
var p=["unset","initial","inherit"]
var m=["calc(","-moz-calc(","-webkit-calc("]
function f(e,t){return t<e.length?e.charCodeAt(t):0}function h(e,t){return s(e,0,e.length,t)}function g(e,t){for(var r=0;r<t.length;r++)if(h(e,t[r]))return!0
return!1}function v(e,t){return t===e.length-2&&92===e.charCodeAt(t)&&o(e.charCodeAt(t+1))}function y(e,t,r){if(e&&"Range"===e.type){var n=Number(void 0!==r&&r!==t.length?t.substr(0,r):t)
if(isNaN(n))return!0
if(null!==e.min&&n<e.min)return!0
if(null!==e.max&&n>e.max)return!0}return!1}function b(e,t){var r=e.index
var n=0
do{n++
if(e.balance<=r)break}while(e=t(n))
return n}function S(e){return function(t,r,n){return null===t?0:t.type===c.Function&&g(t.value,m)?b(t,r):e(t,r,n)}}function x(e){return function(t){return null===t||t.type!==e?0:1}}function k(e){return function(t,r,n){if(null===t||t.type!==c.Dimension)return 0
var a=l(t.value,0)
if(null!==e){var i=t.value.indexOf("\\",a)
var o=-1!==i&&v(t.value,i)?t.value.substring(a,i):t.value.substr(a)
if(!1===e.hasOwnProperty(o.toLowerCase()))return 0}return y(n,t.value,a)?0:1}}function w(e){"function"!=typeof e&&(e=function(){return 0})
return function(t,r,n){return null!==t&&t.type===c.Number&&0===Number(t.value)?1:e(t,r,n)}}e.exports={"ident-token":x(c.Ident),"function-token":x(c.Function),"at-keyword-token":x(c.AtKeyword),"hash-token":x(c.Hash),"string-token":x(c.String),"bad-string-token":x(c.BadString),"url-token":x(c.Url),"bad-url-token":x(c.BadUrl),"delim-token":x(c.Delim),"number-token":x(c.Number),"percentage-token":x(c.Percentage),"dimension-token":x(c.Dimension),"whitespace-token":x(c.WhiteSpace),"CDO-token":x(c.CDO),"CDC-token":x(c.CDC),"colon-token":x(c.Colon),"semicolon-token":x(c.Semicolon),"comma-token":x(c.Comma),"[-token":x(c.LeftSquareBracket),"]-token":x(c.RightSquareBracket),"(-token":x(c.LeftParenthesis),")-token":x(c.RightParenthesis),"{-token":x(c.LeftCurlyBracket),"}-token":x(c.RightCurlyBracket),string:x(c.String),ident:x(c.Ident),"custom-ident":function(e){if(null===e||e.type!==c.Ident)return 0
var t=e.value.toLowerCase()
return g(t,p)||h(t,"default")?0:1},"custom-property-name":function(e){return null===e||e.type!==c.Ident||45!==f(e.value,0)||45!==f(e.value,1)?0:1},"hex-color":function(e){if(null===e||e.type!==c.Hash)return 0
var t=e.value.length
if(4!==t&&5!==t&&7!==t&&9!==t)return 0
for(var r=1;r<t;r++)if(!i(e.value.charCodeAt(r)))return 0
return 1},"id-selector":function(e){return null===e||e.type!==c.Hash?0:a(f(e.value,1),f(e.value,2),f(e.value,3))?1:0},"an-plus-b":d,urange:u,"declaration-value":function(e,t){if(!e)return 0
var r=0
var n=0
var a=e.index
e:do{switch(e.type){case c.BadString:case c.BadUrl:break e
case c.RightCurlyBracket:case c.RightParenthesis:case c.RightSquareBracket:if(e.balance>e.index||e.balance<a)break e
n--
break
case c.Semicolon:if(0===n)break e
break
case c.Delim:if("!"===e.value&&0===n)break e
break
case c.Function:case c.LeftParenthesis:case c.LeftSquareBracket:case c.LeftCurlyBracket:n++}r++
if(e.balance<=a)break}while(e=t(r))
return r},"any-value":function(e,t){if(!e)return 0
var r=e.index
var n=0
e:do{switch(e.type){case c.BadString:case c.BadUrl:break e
case c.RightCurlyBracket:case c.RightParenthesis:case c.RightSquareBracket:if(e.balance>e.index||e.balance<r)break e}n++
if(e.balance<=r)break}while(e=t(n))
return n},dimension:S(k(null)),angle:S(k({deg:!0,grad:!0,rad:!0,turn:!0})),decibel:S(k({db:!0})),frequency:S(k({hz:!0,khz:!0})),flex:S(k({fr:!0})),length:S(w(k({px:!0,mm:!0,cm:!0,in:!0,pt:!0,pc:!0,q:!0,em:!0,ex:!0,ch:!0,rem:!0,vh:!0,vw:!0,vmin:!0,vmax:!0,vm:!0}))),resolution:S(k({dpi:!0,dpcm:!0,dppx:!0,x:!0})),semitones:S(k({st:!0})),time:S(k({s:!0,ms:!0})),percentage:S((function(e,t,r){return null===e||e.type!==c.Percentage||y(r,e.value,e.value.length-1)?0:1})),zero:w(),number:S((function(e,t,r){if(null===e)return 0
var n=l(e.value,0)
return n===e.value.length||v(e.value,n)?y(r,e.value,n)?0:1:0})),integer:S((function(e,t,r){if(null===e||e.type!==c.Number)return 0
var n=43===e.value.charCodeAt(0)||45===e.value.charCodeAt(0)?1:0
for(;n<e.value.length;n++)if(!o(e.value.charCodeAt(n)))return 0
return y(r,e.value,n)?0:1})),"-ms-legacy-expression":function(e){;"("
return function(e,t){return null!==e&&h(e.value,"expression(")?b(e,t):0}}()}},6186:(e,t,r)=>{var n=r(8078)
var a={type:"Match"}
var i={type:"Mismatch"}
var o={type:"DisallowEmpty"}
function s(e,t,r){if(t===a&&r===i)return e
if(e===a&&t===a&&r===a)return e
if("If"===e.type&&e.else===i&&t===a){t=e.then
e=e.match}return{type:"If",match:e,then:t,else:r}}function l(e){return e.length>2&&40===e.charCodeAt(e.length-2)&&41===e.charCodeAt(e.length-1)}function c(e){return"Keyword"===e.type||"AtKeyword"===e.type||"Function"===e.type||"Type"===e.type&&l(e.name)}function d(e,t,r){switch(e){case" ":var n=a
for(var o=t.length-1;o>=0;o--)n=s(m=t[o],n,i)
return n
case"|":n=i
var u=null
for(o=t.length-1;o>=0;o--){if(c(m=t[o])){null===u&&o>0&&c(t[o-1])&&(n=s({type:"Enum",map:u=Object.create(null)},a,n))
if(null!==u){var p=(l(m.name)?m.name.slice(0,-1):m.name).toLowerCase()
if(p in u==0){u[p]=m
continue}}}u=null
n=s(m,a,n)}return n
case"&&":if(t.length>5)return{type:"MatchOnce",terms:t,all:!0}
n=i
for(o=t.length-1;o>=0;o--){var m=t[o]
f=t.length>1?d(e,t.filter((function(e){return e!==m})),!1):a
n=s(m,f,n)}return n
case"||":if(t.length>5)return{type:"MatchOnce",terms:t,all:!1}
n=r?a:i
for(o=t.length-1;o>=0;o--){m=t[o]
var f
f=t.length>1?d(e,t.filter((function(e){return e!==m})),!0):a
n=s(m,f,n)}return n}}function u(e){if("function"==typeof e)return{type:"Generic",fn:e}
switch(e.type){case"Group":var t=d(e.combinator,e.terms.map(u),!1)
e.disallowEmpty&&(t=s(t,o,i))
return t
case"Multiplier":return function(e){var t=a
var r=u(e.term)
if(0===e.max){r=s(r,o,i);(t=s(r,null,i)).then=s(a,a,t)
e.comma&&(t.then.else=s({type:"Comma",syntax:e},t,i))}else for(var n=e.min||1;n<=e.max;n++){e.comma&&t!==a&&(t=s({type:"Comma",syntax:e},t,i))
t=s(r,s(a,a,t),i)}if(0===e.min)t=s(a,a,t)
else for(n=0;n<e.min-1;n++){e.comma&&t!==a&&(t=s({type:"Comma",syntax:e},t,i))
t=s(r,t,i)}return t}(e)
case"Type":case"Property":return{type:e.type,name:e.name,syntax:e}
case"Keyword":return{type:e.type,name:e.name.toLowerCase(),syntax:e}
case"AtKeyword":return{type:e.type,name:"@"+e.name.toLowerCase(),syntax:e}
case"Function":return{type:e.type,name:e.name.toLowerCase()+"(",syntax:e}
case"String":return 3===e.value.length?{type:"Token",value:e.value.charAt(1),syntax:e}:{type:e.type,value:e.value.substr(1,e.value.length-2).replace(/\\'/g,"'"),syntax:e}
case"Token":return{type:e.type,value:e.value,syntax:e}
case"Comma":return{type:e.type,syntax:e}
default:throw new Error("Unknown node type:",e.type)}}e.exports={MATCH:a,MISMATCH:i,DISALLOW_EMPTY:o,buildMatchGraph:function(e,t){"string"==typeof e&&(e=n(e))
return{type:"MatchGraph",match:u(e),syntax:t||null,source:e}}}},8852:(e,t,r)=>{var n=Object.prototype.hasOwnProperty
var a=r(6186)
var i=a.MATCH
var o=a.MISMATCH
var s=a.DISALLOW_EMPTY
var l=r(9856).TYPE
var c="Match"
var d=0
function u(e){var t=null
var r=null
var n=e
for(;null!==n;){r=n.prev
n.prev=t
t=n
n=r}return t}function p(e,t){if(e.length!==t.length)return!1
for(var r=0;r<e.length;r++){var n=e.charCodeAt(r)
n>=65&&n<=90&&(n|=32)
if(n!==t.charCodeAt(r))return!1}return!0}function m(e){return null===e||e.type===l.Comma||e.type===l.Function||e.type===l.LeftParenthesis||e.type===l.LeftSquareBracket||e.type===l.LeftCurlyBracket||function(e){return e.type===l.Delim&&"?"!==e.value}(e)}function f(e){return null===e||e.type===l.RightParenthesis||e.type===l.RightSquareBracket||e.type===l.RightCurlyBracket||e.type===l.Delim}function h(e,t,r){function a(){do{O++
E=O<e.length?e[O]:null}while(null!==E&&(E.type===l.WhiteSpace||E.type===l.Comment))}function u(t){var r=O+t
return r<e.length?e[r]:null}function h(e,t){return{nextState:e,matchStack:_,syntaxStack:x,thenStack:k,tokenIndex:O,prev:t}}function g(e){k={nextState:e,matchStack:_,syntaxStack:x,prev:k}}function v(e){w=h(e,w)}function y(){_={type:1,syntax:t.syntax,token:E,prev:_}
a()
C=null
O>z&&(z=O)}function b(){x={syntax:t.syntax,opts:t.syntax.opts||null!==x&&x.opts||null,prev:x}
_={type:2,syntax:t.syntax,token:_.token,prev:_}}function S(){_=2===_.type?_.prev:{type:3,syntax:x.syntax,token:_.token,prev:_}
x=x.prev}var x=null
var k=null
var w=null
var C=null
var T=0
var A=null
var E=null
var O=-1
var z=0
var _={type:0,syntax:null,token:null,prev:null}
a()
for(;null===A&&++T<15e3;)switch(t.type){case"Match":if(null===k){if(null!==E&&(O!==e.length-1||"\\0"!==E.value&&"\\9"!==E.value)){t=o
break}A=c
break}if((t=k.nextState)===s){if(k.matchStack===_){t=o
break}t=i}for(;k.syntaxStack!==x;)S()
k=k.prev
break
case"Mismatch":if(null!==C&&!1!==C){if(null===w||O>w.tokenIndex){w=C
C=!1}}else if(null===w){A="Mismatch"
break}t=w.nextState
k=w.thenStack
x=w.syntaxStack
_=w.matchStack
O=w.tokenIndex
E=O<e.length?e[O]:null
w=w.prev
break
case"MatchGraph":t=t.match
break
case"If":t.else!==o&&v(t.else)
t.then!==i&&g(t.then)
t=t.match
break
case"MatchOnce":t={type:"MatchOnceBuffer",syntax:t,index:0,mask:0}
break
case"MatchOnceBuffer":var P=t.syntax.terms
if(t.index===P.length){if(0===t.mask||t.syntax.all){t=o
break}t=i
break}if(t.mask===(1<<P.length)-1){t=i
break}for(;t.index<P.length;t.index++){var q=1<<t.index
if(0==(t.mask&q)){v(t)
g({type:"AddMatchOnce",syntax:t.syntax,mask:t.mask|q})
t=P[t.index++]
break}}break
case"AddMatchOnce":t={type:"MatchOnceBuffer",syntax:t.syntax,index:0,mask:t.mask}
break
case"Enum":if(null!==E){-1!==(R=E.value.toLowerCase()).indexOf("\\")&&(R=R.replace(/\\[09].*$/,""))
if(n.call(t.map,R)){t=t.map[R]
break}}t=o
break
case"Generic":var L=null!==x?x.opts:null
var W=O+Math.floor(t.fn(E,u,L))
if(!isNaN(W)&&W>O){for(;O<W;)y()
t=i}else t=o
break
case"Type":case"Property":var B="Type"===t.type?"types":"properties"
var M=n.call(r,B)?r[B][t.name]:null
if(!M||!M.match)throw new Error("Bad syntax reference: "+("Type"===t.type?"<"+t.name+">":"<'"+t.name+"'>"))
if(!1!==C&&null!==E&&"Type"===t.type&&("custom-ident"===t.name&&E.type===l.Ident||"length"===t.name&&"0"===E.value)){null===C&&(C=h(t,w))
t=o
break}b()
t=M.match
break
case"Keyword":var R=t.name
if(null!==E){var I=E.value;-1!==I.indexOf("\\")&&(I=I.replace(/\\[09].*$/,""))
if(p(I,R)){y()
t=i
break}}t=o
break
case"AtKeyword":case"Function":if(null!==E&&p(E.value,t.name)){y()
t=i
break}t=o
break
case"Token":if(null!==E&&E.value===t.value){y()
t=i
break}t=o
break
case"Comma":if(null!==E&&E.type===l.Comma)if(m(_.token))t=o
else{y()
t=f(E)?o:i}else t=m(_.token)||f(E)?i:o
break
case"String":var D=""
for(W=O;W<e.length&&D.length<t.value.length;W++)D+=e[W].value
if(p(D,t.value)){for(;O<W;)y()
t=i}else t=o
break
default:throw new Error("Unknown node type: "+t.type)}d+=T
switch(A){case null:console.warn("[csstree-match] BREAK after 15000 iterations")
A="Maximum iteration number exceeded (please fill an issue on https://github.com/csstree/csstree/issues)"
_=null
break
case c:for(;null!==x;)S()
break
default:_=null}return{tokens:e,reason:A,iterations:T,match:_,longestMatch:z}}e.exports={matchAsList:function(e,t,r){var n=h(e,t,r||{})
if(null!==n.match){var a=u(n.match).prev
n.match=[]
for(;null!==a;){switch(a.type){case 0:break
case 2:case 3:n.match.push({type:a.type,syntax:a.syntax})
break
default:n.match.push({token:a.token.value,node:a.token.node})}a=a.prev}}return n},matchAsTree:function(e,t,r){var n=h(e,t,r||{})
if(null===n.match)return n
var a=n.match
var i=n.match={syntax:t.syntax||null,match:[]}
var o=[i]
a=u(a).prev
for(;null!==a;){switch(a.type){case 2:i.match.push(i={syntax:a.syntax,match:[]})
o.push(i)
break
case 3:o.pop()
i=o[o.length-1]
break
default:i.match.push({syntax:a.syntax||null,token:a.token.value,node:a.token.node})}a=a.prev}return n},getTotalIterationCount:function(){return d}}},9013:(e,t,r)=>{var n=r(8074)
var a=new(r(6418))
var i={decorator:function(e){var t=null
var r={len:0,node:null}
var n=[r]
var a=""
return{children:e.children,node:function(r){var n=t
t=r
e.node.call(this,r)
t=n},chunk:function(e){a+=e
r.node!==t?n.push({len:e.length,node:t}):r.len+=e.length},result:function(){return o(a,n)}}}}
function o(e,t){var r=[]
var i=0
var o=0
var s=t?t[o].node:null
n(e,a)
for(;!a.eof;){if(t)for(;o<t.length&&i+t[o].len<=a.tokenStart;){i+=t[o++].len
s=t[o].node}r.push({type:a.tokenType,value:a.getTokenValue(),index:a.tokenIndex,balance:a.balance[a.tokenIndex],node:s})
a.next()}return r}e.exports=function(e,t){return"string"==typeof e?o(e,null):t.generate(e,i)}},5207:(e,t,r)=>{var n=r(1922)
function a(e){return"node"in e?e.node:a(e.match[0])}function i(e){return"node"in e?e.node:i(e.match[e.match.length-1])}e.exports={matchFragments:function(e,t,r,o,s){var l=[]
null!==r.matched&&function r(c){if(null!==c.syntax&&c.syntax.type===o&&c.syntax.name===s){var d=a(c)
var u=i(c)
e.syntax.walk(t,(function(e,t,r){if(e===d){var a=new n
do{a.appendData(t.data)
if(t.data===u)break
t=t.next}while(null!==t)
l.push({parent:r,nodes:a})}}))}Array.isArray(c.match)&&c.match.forEach(r)}(r.matched)
return l}}},2956:(e,t,r)=>{var n=r(1922)
var a=Object.prototype.hasOwnProperty
function i(e){return"number"==typeof e&&isFinite(e)&&Math.floor(e)===e&&e>=0}function o(e){return Boolean(e)&&i(e.offset)&&i(e.line)&&i(e.column)}function s(e,t){return function(r,i){if(!r||r.constructor!==Object)return i(r,"Type of node should be an Object")
for(var s in r){var l=!0
if(!1!==a.call(r,s)){if("type"===s)r.type!==e&&i(r,"Wrong node type `"+r.type+"`, expected `"+e+"`")
else if("loc"===s){if(null===r.loc)continue
if(r.loc&&r.loc.constructor===Object)if("string"!=typeof r.loc.source)s+=".source"
else if(o(r.loc.start)){if(o(r.loc.end))continue
s+=".end"}else s+=".start"
l=!1}else if(t.hasOwnProperty(s)){var c=0
for(l=!1;!l&&c<t[s].length;c++){var d=t[s][c]
switch(d){case String:l="string"==typeof r[s]
break
case Boolean:l="boolean"==typeof r[s]
break
case null:l=null===r[s]
break
default:"string"==typeof d?l=r[s]&&r[s].type===d:Array.isArray(d)&&(l=r[s]instanceof n)}}}else i(r,"Unknown field `"+s+"` for "+e+" node type")
l||i(r,"Bad value for `"+e+"."+s+"`")}}for(var s in t)a.call(t,s)&&!1===a.call(r,s)&&i(r,"Field `"+e+"."+s+"` is missed")}}function l(e,t){var r=t.structure
var n={type:String,loc:!0}
var i={type:'"'+e+'"'}
for(var o in r)if(!1!==a.call(r,o)){var l=[]
var c=n[o]=Array.isArray(r[o])?r[o].slice():[r[o]]
for(var d=0;d<c.length;d++){var u=c[d]
if(u===String||u===Boolean)l.push(u.name)
else if(null===u)l.push("null")
else if("string"==typeof u)l.push("<"+u+">")
else{if(!Array.isArray(u))throw new Error("Wrong value `"+u+"` in `"+e+"."+o+"` structure definition")
l.push("List")}}i[o]=l.join(" | ")}return{docs:i,check:s(e,n)}}e.exports={getStructureFromConfig:function(e){var t={}
if(e.node)for(var r in e.node)if(a.call(e.node,r)){var n=e.node[r]
if(!n.structure)throw new Error("Missed `structure` field in `"+r+"` node type definition")
t[r]=l(r,n)}return t}}},2803:e=>{function t(e){function t(e){return null!==e&&("Type"===e.type||"Property"===e.type||"Keyword"===e.type)}var r=null
null!==this.matched&&function n(a){if(Array.isArray(a.match)){for(var i=0;i<a.match.length;i++)if(n(a.match[i])){t(a.syntax)&&r.unshift(a.syntax)
return!0}}else if(a.node===e){r=t(a.syntax)?[a.syntax]:[]
return!0}return!1}(this.matched)
return r}function r(e,r,n){var a=t.call(e,r)
return null!==a&&a.some(n)}e.exports={getTrace:t,isType:function(e,t){return r(this,e,(function(e){return"Type"===e.type&&e.name===t}))},isProperty:function(e,t){return r(this,e,(function(e){return"Property"===e.type&&e.name===t}))},isKeyword:function(e){return r(this,e,(function(e){return"Keyword"===e.type}))}}},8675:(e,t,r)=>{var n=r(2060)
var a=r(2325)
var i=r(6418)
var o=r(1922)
var s=r(8074)
var l=r(9856)
var{findWhiteSpaceStart:c,cmpStr:d}=r(456)
var u=r(9252)
var p=function(){}
var m=l.TYPE
var f=l.NAME
var h=m.WhiteSpace
var g=m.Comment
var v=m.Ident
var y=m.Function
var b=m.Url
var S=m.Hash
var x=m.Percentage
var k=m.Number
function w(e){return function(){return this[e]()}}e.exports=function(e){var t={scanner:new i,locationMap:new n,filename:"<unknown>",needPositions:!1,onParseError:p,onParseErrorThrow:!1,parseAtrulePrelude:!0,parseRulePrelude:!0,parseValue:!0,parseCustomProperty:!1,readSequence:u,createList:function(){return new o},createSingleNodeList:function(e){return(new o).appendData(e)},getFirstListNode:function(e){return e&&e.first()},getLastListNode:function(e){return e.last()},parseWithFallback:function(e,t){var r=this.scanner.tokenIndex
try{return e.call(this)}catch(e){if(this.onParseErrorThrow)throw e
var n=t.call(this,r)
this.onParseErrorThrow=!0
this.onParseError(e,n)
this.onParseErrorThrow=!1
return n}},lookupNonWSType:function(e){do{var t=this.scanner.lookupType(e++)
if(t!==h)return t}while(0!==t)
return 0},eat:function(e){if(this.scanner.tokenType!==e){var t=this.scanner.tokenStart
var r=f[e]+" is expected"
switch(e){case v:if(this.scanner.tokenType===y||this.scanner.tokenType===b){t=this.scanner.tokenEnd-1
r="Identifier is expected but function found"}else r="Identifier is expected"
break
case S:if(this.scanner.isDelim(35)){this.scanner.next()
t++
r="Name is expected"}break
case x:if(this.scanner.tokenType===k){t=this.scanner.tokenEnd
r="Percent sign is expected"}break
default:this.scanner.source.charCodeAt(this.scanner.tokenStart)===e&&(t+=1)}this.error(r,t)}this.scanner.next()},consume:function(e){var t=this.scanner.getTokenValue()
this.eat(e)
return t},consumeFunctionName:function(){var e=this.scanner.source.substring(this.scanner.tokenStart,this.scanner.tokenEnd-1)
this.eat(y)
return e},getLocation:function(e,t){return this.needPositions?this.locationMap.getLocationRange(e,t,this.filename):null},getLocationFromList:function(e){if(this.needPositions){var t=this.getFirstListNode(e)
var r=this.getLastListNode(e)
return this.locationMap.getLocationRange(null!==t?t.loc.start.offset-this.locationMap.startOffset:this.scanner.tokenStart,null!==r?r.loc.end.offset-this.locationMap.startOffset:this.scanner.tokenStart,this.filename)}return null},error:function(e,t){var r=void 0!==t&&t<this.scanner.source.length?this.locationMap.getLocation(t):this.scanner.eof?this.locationMap.getLocation(c(this.scanner.source,this.scanner.source.length-1)):this.locationMap.getLocation(this.scanner.tokenStart)
throw new a(e||"Unexpected input",this.scanner.source,r.offset,r.line,r.column)}}
e=function(e){var t={context:{},scope:{},atrule:{},pseudo:{}}
if(e.parseContext)for(var r in e.parseContext)switch(typeof e.parseContext[r]){case"function":t.context[r]=e.parseContext[r]
break
case"string":t.context[r]=w(e.parseContext[r])}if(e.scope)for(var r in e.scope)t.scope[r]=e.scope[r]
if(e.atrule)for(var r in e.atrule){var n=e.atrule[r]
n.parse&&(t.atrule[r]=n.parse)}if(e.pseudo)for(var r in e.pseudo){var a=e.pseudo[r]
a.parse&&(t.pseudo[r]=a.parse)}if(e.node)for(var r in e.node)t[r]=e.node[r].parse
return t}(e||{})
for(var r in e)t[r]=e[r]
return function(e,r){var n=(r=r||{}).context||"default"
var a=r.onComment
var i
s(e,t.scanner)
t.locationMap.setSource(e,r.offset,r.line,r.column)
t.filename=r.filename||"<unknown>"
t.needPositions=Boolean(r.positions)
t.onParseError="function"==typeof r.onParseError?r.onParseError:p
t.onParseErrorThrow=!1
t.parseAtrulePrelude=!("parseAtrulePrelude"in r)||Boolean(r.parseAtrulePrelude)
t.parseRulePrelude=!("parseRulePrelude"in r)||Boolean(r.parseRulePrelude)
t.parseValue=!("parseValue"in r)||Boolean(r.parseValue)
t.parseCustomProperty="parseCustomProperty"in r&&Boolean(r.parseCustomProperty)
if(!t.context.hasOwnProperty(n))throw new Error("Unknown context `"+n+"`")
"function"==typeof a&&t.scanner.forEachToken(((r,n,i)=>{if(r===g){const r=t.getLocation(n,i)
const o=d(e,i-2,i,"*/")?e.slice(n+2,i-2):e.slice(n+2,i)
a(o,r)}}))
i=t.context[n].call(t,r)
t.scanner.eof||t.error()
return i}}},9252:(e,t,r)=>{var n=r(8074).TYPE
var a=n.WhiteSpace
var i=n.Comment
e.exports=function(e){var t=this.createList()
var r=null
var n={recognizer:e,space:null,ignoreWS:!1,ignoreWSAfter:!1}
this.scanner.skipSC()
for(;!this.scanner.eof;){switch(this.scanner.tokenType){case i:this.scanner.next()
continue
case a:n.ignoreWS?this.scanner.next():n.space=this.WhiteSpace()
continue}if(void 0===(r=e.getNode.call(this,n)))break
if(null!==n.space){t.push(n.space)
n.space=null}t.push(r)
if(n.ignoreWSAfter){n.ignoreWSAfter=!1
n.ignoreWS=!0}else n.ignoreWS=!1}return t}},639:e=>{e.exports={parse:{prelude:null,block:function(){return this.Block(!0)}}}},9633:(e,t,r)=>{var n=r(8074).TYPE
var a=n.String
var i=n.Ident
var o=n.Url
var s=n.Function
var l=n.LeftParenthesis
e.exports={parse:{prelude:function(){var e=this.createList()
this.scanner.skipSC()
switch(this.scanner.tokenType){case a:e.push(this.String())
break
case o:case s:e.push(this.Url())
break
default:this.error("String or url() is expected")}if(this.lookupNonWSType(0)===i||this.lookupNonWSType(0)===l){e.push(this.WhiteSpace())
e.push(this.MediaQueryList())}return e},block:null}}},3778:(e,t,r)=>{e.exports={"font-face":r(639),import:r(9633),media:r(7352),page:r(2480),supports:r(1267)}},7352:e=>{e.exports={parse:{prelude:function(){return this.createSingleNodeList(this.MediaQueryList())},block:function(){return this.Block(!1)}}}},2480:e=>{e.exports={parse:{prelude:function(){return this.createSingleNodeList(this.SelectorList())},block:function(){return this.Block(!0)}}}},1267:(e,t,r)=>{var n=r(8074).TYPE
var a=n.WhiteSpace
var i=n.Comment
var o=n.Ident
var s=n.Function
var l=n.Colon
var c=n.LeftParenthesis
function d(){return this.createSingleNodeList(this.Raw(this.scanner.tokenIndex,null,!1))}function u(){this.scanner.skipSC()
return this.scanner.tokenType===o&&this.lookupNonWSType(1)===l?this.createSingleNodeList(this.Declaration()):p.call(this)}function p(){var e=this.createList()
var t=null
var r
this.scanner.skipSC()
e:for(;!this.scanner.eof;){switch(this.scanner.tokenType){case a:t=this.WhiteSpace()
continue
case i:this.scanner.next()
continue
case s:r=this.Function(d,this.scope.AtrulePrelude)
break
case o:r=this.Identifier()
break
case c:r=this.Parentheses(u,this.scope.AtrulePrelude)
break
default:break e}if(null!==t){e.push(t)
t=null}e.push(r)}return e}e.exports={parse:{prelude:function(){var e=p.call(this)
null===this.getFirstListNode(e)&&this.error("Condition is expected")
return e},block:function(){return this.Block(!1)}}}},2980:(e,t,r)=>{var n=r(7681)
e.exports={generic:!0,types:n.types,atrules:n.atrules,properties:n.properties,node:r(6518)}},6338:e=>{const t=Object.prototype.hasOwnProperty
const r={generic:!0,types:o,atrules:{prelude:s,descriptors:s},properties:o,parseContext:function(e,t){return Object.assign(e,t)},scope:function e(r,i){for(const o in i)t.call(i,o)&&(n(r[o])?e(r[o],a(i[o])):r[o]=a(i[o]))
return r},atrule:["parse"],pseudo:["parse"],node:["name","structure","parse","generate","walkContext"]}
function n(e){return e&&e.constructor===Object}function a(e){return n(e)?Object.assign({},e):e}function i(e,t){return"string"==typeof t&&/^\s*\|/.test(t)?"string"==typeof e?e+t:t.replace(/^\s*\|\s*/,""):t||null}function o(e,r){if("string"==typeof r)return i(e,r)
const n=Object.assign({},e)
for(let a in r)t.call(r,a)&&(n[a]=i(t.call(e,a)?e[a]:void 0,r[a]))
return n}function s(e,t){const r=o(e,t)
return!n(r)||Object.keys(r).length?r:null}function l(e,r,i){for(const o in i)if(!1!==t.call(i,o))if(!0===i[o])o in r&&t.call(r,o)&&(e[o]=a(r[o]))
else if(i[o])if("function"==typeof i[o]){const t=i[o]
e[o]=t({},e[o])
e[o]=t(e[o]||{},r[o])}else if(n(i[o])){const t={}
for(let r in e[o])t[r]=l({},e[o][r],i[o])
for(let e in r[o])t[e]=l(t[e]||{},r[o][e],i[o])
e[o]=t}else if(Array.isArray(i[o])){const n={}
const a=i[o].reduce((function(e,t){e[t]=!0
return e}),{})
for(const[t,r]of Object.entries(e[o]||{})){n[t]={}
r&&l(n[t],r,a)}for(const e in r[o])if(t.call(r[o],e)){n[e]||(n[e]={})
r[o]&&r[o][e]&&l(n[e],r[o][e],a)}e[o]=n}return e}e.exports=(e,t)=>l(e,t,r)},6497:(e,t,r)=>{e.exports={parseContext:{default:"StyleSheet",stylesheet:"StyleSheet",atrule:"Atrule",atrulePrelude:function(e){return this.AtrulePrelude(e.atrule?String(e.atrule):null)},mediaQueryList:"MediaQueryList",mediaQuery:"MediaQuery",rule:"Rule",selectorList:"SelectorList",selector:"Selector",block:function(){return this.Block(!0)},declarationList:"DeclarationList",declaration:"Declaration",value:"Value"},scope:r(4598),atrule:r(3778),pseudo:r(3553),node:r(6518)}},7600:(e,t,r)=>{e.exports={node:r(6518)}},4521:(e,t,r)=>{var n=r(1922)
var a=r(2325)
var i=r(6418)
var o=r(6944)
var s=r(9540)
var l=r(8074)
var c=r(8675)
var d=r(2987)
var u=r(7851)
var p=r(9772)
var m=r(4432)
var f=r(4266)
var h=r(6338)
function g(e){var t=c(e)
var r=p(e)
var v=d(e)
var y=u(r)
var b={List:n,SyntaxError:a,TokenStream:i,Lexer:o,vendorPrefix:f.vendorPrefix,keyword:f.keyword,property:f.property,isCustomProperty:f.isCustomProperty,definitionSyntax:s,lexer:null,createLexer:function(e){return new o(e,b,b.lexer.structure)},tokenize:l,parse:t,walk:r,generate:v,find:r.find,findLast:r.findLast,findAll:r.findAll,clone:m,fromPlainObject:y.fromPlainObject,toPlainObject:y.toPlainObject,createSyntax:function(e){return g(h({},e))},fork:function(t){var r=h({},e)
return g("function"==typeof t?t(r,Object.assign):h(r,t))}}
b.lexer=new o({generic:!0,types:e.types,atrules:e.atrules,properties:e.properties,node:e.node},b)
return b}t.create=function(e){return g(h({},e))}},3369:e=>{e.exports=function(){return this.createSingleNodeList(this.Raw(this.scanner.tokenIndex,null,!1))}},126:(e,t,r)=>{var n=r(8074).TYPE
var a=r(2832).mode
var i=n.Comma
var o=n.WhiteSpace
e.exports=function(){var e=this.createList()
this.scanner.skipSC()
e.push(this.Identifier())
this.scanner.skipSC()
if(this.scanner.tokenType===i){e.push(this.Operator())
const t=this.scanner.tokenIndex
const r=this.parseCustomProperty?this.Value(null):this.Raw(this.scanner.tokenIndex,a.exclamationMarkOrSemicolon,!1)
if("Value"===r.type&&r.children.isEmpty())for(let e=t-this.scanner.tokenIndex;e<=0;e++)if(this.scanner.lookupType(e)===o){r.children.appendData({type:"WhiteSpace",loc:null,value:" "})
break}e.push(r)}return e}},2326:(e,t,r)=>{e.exports=r(4521).create(function(){var e={}
for(var t=0;t<arguments.length;t++){var r=arguments[t]
for(var n in r)e[n]=r[n]}return e}(r(2980),r(6497),r(7600)))
e.exports.version=r(2781).version},8850:(e,t,r)=>{var n=r(8074).cmpChar
var a=r(8074).isDigit
var i=r(8074).TYPE
var o=i.WhiteSpace
var s=i.Comment
var l=i.Ident
var c=i.Number
var d=i.Dimension
var u=43
var p=45
var m=110
var f=!0
function h(e,t){var r=this.scanner.tokenStart+e
var n=this.scanner.source.charCodeAt(r)
if(n===u||n===p){t&&this.error("Number sign is not allowed")
r++}for(;r<this.scanner.tokenEnd;r++)a(this.scanner.source.charCodeAt(r))||this.error("Integer is expected",r)}function g(e){return h.call(this,0,e)}function v(e,t){if(!n(this.scanner.source,this.scanner.tokenStart+e,t)){var r=""
switch(t){case m:r="N is expected"
break
case p:r="HyphenMinus is expected"}this.error(r,this.scanner.tokenStart+e)}}function y(){var e=0
var t=0
var r=this.scanner.tokenType
for(;r===o||r===s;)r=this.scanner.lookupType(++e)
if(r!==c){if(!this.scanner.isDelim(u,e)&&!this.scanner.isDelim(p,e))return null
t=this.scanner.isDelim(u,e)?u:p
do{r=this.scanner.lookupType(++e)}while(r===o||r===s)
if(r!==c){this.scanner.skip(e)
g.call(this,f)}}e>0&&this.scanner.skip(e)
0===t&&(r=this.scanner.source.charCodeAt(this.scanner.tokenStart))!==u&&r!==p&&this.error("Number sign is expected")
g.call(this,0!==t)
return t===p?"-"+this.consume(c):this.consume(c)}e.exports={name:"AnPlusB",structure:{a:[String,null],b:[String,null]},parse:function(){var e=this.scanner.tokenStart
var t=null
var r=null
if(this.scanner.tokenType===c){g.call(this,!1)
r=this.consume(c)}else if(this.scanner.tokenType===l&&n(this.scanner.source,this.scanner.tokenStart,p)){t="-1"
v.call(this,1,m)
switch(this.scanner.getTokenLength()){case 2:this.scanner.next()
r=y.call(this)
break
case 3:v.call(this,2,p)
this.scanner.next()
this.scanner.skipSC()
g.call(this,f)
r="-"+this.consume(c)
break
default:v.call(this,2,p)
h.call(this,3,f)
this.scanner.next()
r=this.scanner.substrToCursor(e+2)}}else if(this.scanner.tokenType===l||this.scanner.isDelim(u)&&this.scanner.lookupType(1)===l){var i=0
t="1"
if(this.scanner.isDelim(u)){i=1
this.scanner.next()}v.call(this,0,m)
switch(this.scanner.getTokenLength()){case 1:this.scanner.next()
r=y.call(this)
break
case 2:v.call(this,1,p)
this.scanner.next()
this.scanner.skipSC()
g.call(this,f)
r="-"+this.consume(c)
break
default:v.call(this,1,p)
h.call(this,2,f)
this.scanner.next()
r=this.scanner.substrToCursor(e+i+1)}}else if(this.scanner.tokenType===d){var o=this.scanner.source.charCodeAt(this.scanner.tokenStart)
i=o===u||o===p
for(var s=this.scanner.tokenStart+i;s<this.scanner.tokenEnd&&a(this.scanner.source.charCodeAt(s));s++);s===this.scanner.tokenStart+i&&this.error("Integer is expected",this.scanner.tokenStart+i)
v.call(this,s-this.scanner.tokenStart,m)
t=this.scanner.source.substring(e,s)
if(s+1===this.scanner.tokenEnd){this.scanner.next()
r=y.call(this)}else{v.call(this,s-this.scanner.tokenStart+1,p)
if(s+2===this.scanner.tokenEnd){this.scanner.next()
this.scanner.skipSC()
g.call(this,f)
r="-"+this.consume(c)}else{h.call(this,s-this.scanner.tokenStart+2,f)
this.scanner.next()
r=this.scanner.substrToCursor(s+1)}}}else this.error()
null!==t&&t.charCodeAt(0)===u&&(t=t.substr(1))
null!==r&&r.charCodeAt(0)===u&&(r=r.substr(1))
return{type:"AnPlusB",loc:this.getLocation(e,this.scanner.tokenStart),a:t,b:r}},generate:function(e){var t=null!==e.a&&void 0!==e.a
var r=null!==e.b&&void 0!==e.b
if(t){this.chunk("+1"===e.a?"+n":"1"===e.a?"n":"-1"===e.a?"-n":e.a+"n")
if(r)if("-"===(r=String(e.b)).charAt(0)||"+"===r.charAt(0)){this.chunk(r.charAt(0))
this.chunk(r.substr(1))}else{this.chunk("+")
this.chunk(r)}}else this.chunk(String(e.b))}}},7440:(e,t,r)=>{var n=r(8074).TYPE
var a=r(2832).mode
var i=n.AtKeyword
var o=n.Semicolon
var s=n.LeftCurlyBracket
var l=n.RightCurlyBracket
function c(e){return this.Raw(e,a.leftCurlyBracketOrSemicolon,!0)}function d(){for(var e,t=1;e=this.scanner.lookupType(t);t++){if(e===l)return!0
if(e===s||e===i)return!1}return!1}e.exports={name:"Atrule",structure:{name:String,prelude:["AtrulePrelude","Raw",null],block:["Block",null]},parse:function(){var e=this.scanner.tokenStart
var t
var r
var n=null
var a=null
this.eat(i)
r=(t=this.scanner.substrToCursor(e+1)).toLowerCase()
this.scanner.skipSC()
if(!1===this.scanner.eof&&this.scanner.tokenType!==s&&this.scanner.tokenType!==o){this.parseAtrulePrelude?"AtrulePrelude"===(n=this.parseWithFallback(this.AtrulePrelude.bind(this,t),c)).type&&null===n.children.head&&(n=null):n=c.call(this,this.scanner.tokenIndex)
this.scanner.skipSC()}switch(this.scanner.tokenType){case o:this.scanner.next()
break
case s:a=this.atrule.hasOwnProperty(r)&&"function"==typeof this.atrule[r].block?this.atrule[r].block.call(this):this.Block(d.call(this))}return{type:"Atrule",loc:this.getLocation(e,this.scanner.tokenStart),name:t,prelude:n,block:a}},generate:function(e){this.chunk("@")
this.chunk(e.name)
if(null!==e.prelude){this.chunk(" ")
this.node(e.prelude)}e.block?this.node(e.block):this.chunk(";")},walkContext:"atrule"}},4e3:(e,t,r)=>{var n=r(8074).TYPE
var a=n.Semicolon
var i=n.LeftCurlyBracket
e.exports={name:"AtrulePrelude",structure:{children:[[]]},parse:function(e){var t=null
null!==e&&(e=e.toLowerCase())
this.scanner.skipSC()
t=this.atrule.hasOwnProperty(e)&&"function"==typeof this.atrule[e].prelude?this.atrule[e].prelude.call(this):this.readSequence(this.scope.AtrulePrelude)
this.scanner.skipSC()
!0!==this.scanner.eof&&this.scanner.tokenType!==i&&this.scanner.tokenType!==a&&this.error("Semicolon or block is expected")
null===t&&(t=this.createList())
return{type:"AtrulePrelude",loc:this.getLocationFromList(t),children:t}},generate:function(e){this.children(e)},walkContext:"atrulePrelude"}},5337:(e,t,r)=>{var n=r(8074).TYPE
var a=n.Ident
var i=n.String
var o=n.Colon
var s=n.LeftSquareBracket
var l=n.RightSquareBracket
function c(){this.scanner.eof&&this.error("Unexpected end of input")
var e=this.scanner.tokenStart
var t=!1
var r=!0
if(this.scanner.isDelim(42)){t=!0
r=!1
this.scanner.next()}else this.scanner.isDelim(124)||this.eat(a)
if(this.scanner.isDelim(124))if(61!==this.scanner.source.charCodeAt(this.scanner.tokenStart+1)){this.scanner.next()
this.eat(a)}else t&&this.error("Identifier is expected",this.scanner.tokenEnd)
else t&&this.error("Vertical line is expected")
if(r&&this.scanner.tokenType===o){this.scanner.next()
this.eat(a)}return{type:"Identifier",loc:this.getLocation(e,this.scanner.tokenStart),name:this.scanner.substrToCursor(e)}}function d(){var e=this.scanner.tokenStart
var t=this.scanner.source.charCodeAt(e)
61!==t&&126!==t&&94!==t&&36!==t&&42!==t&&124!==t&&this.error("Attribute selector (=, ~=, ^=, $=, *=, |=) is expected")
this.scanner.next()
if(61!==t){this.scanner.isDelim(61)||this.error("Equal sign is expected")
this.scanner.next()}return this.scanner.substrToCursor(e)}e.exports={name:"AttributeSelector",structure:{name:"Identifier",matcher:[String,null],value:["String","Identifier",null],flags:[String,null]},parse:function(){var e=this.scanner.tokenStart
var t
var r=null
var n=null
var o=null
this.eat(s)
this.scanner.skipSC()
t=c.call(this)
this.scanner.skipSC()
if(this.scanner.tokenType!==l){if(this.scanner.tokenType!==a){r=d.call(this)
this.scanner.skipSC()
n=this.scanner.tokenType===i?this.String():this.Identifier()
this.scanner.skipSC()}if(this.scanner.tokenType===a){o=this.scanner.getTokenValue()
this.scanner.next()
this.scanner.skipSC()}}this.eat(l)
return{type:"AttributeSelector",loc:this.getLocation(e,this.scanner.tokenStart),name:t,matcher:r,value:n,flags:o}},generate:function(e){var t=" "
this.chunk("[")
this.node(e.name)
if(null!==e.matcher){this.chunk(e.matcher)
if(null!==e.value){this.node(e.value)
"String"===e.value.type&&(t="")}}if(null!==e.flags){this.chunk(t)
this.chunk(e.flags)}this.chunk("]")}}},2061:(e,t,r)=>{var n=r(8074).TYPE
var a=r(2832).mode
var i=n.WhiteSpace
var o=n.Comment
var s=n.Semicolon
var l=n.AtKeyword
var c=n.LeftCurlyBracket
var d=n.RightCurlyBracket
function u(e){return this.Raw(e,null,!0)}function p(){return this.parseWithFallback(this.Rule,u)}function m(e){return this.Raw(e,a.semicolonIncluded,!0)}function f(){if(this.scanner.tokenType===s)return m.call(this,this.scanner.tokenIndex)
var e=this.parseWithFallback(this.Declaration,m)
this.scanner.tokenType===s&&this.scanner.next()
return e}e.exports={name:"Block",structure:{children:[["Atrule","Rule","Declaration"]]},parse:function(e){var t=e?f:p
var r=this.scanner.tokenStart
var n=this.createList()
this.eat(c)
e:for(;!this.scanner.eof;)switch(this.scanner.tokenType){case d:break e
case i:case o:this.scanner.next()
break
case l:n.push(this.parseWithFallback(this.Atrule,u))
break
default:n.push(t.call(this))}this.scanner.eof||this.eat(d)
return{type:"Block",loc:this.getLocation(r,this.scanner.tokenStart),children:n}},generate:function(e){this.chunk("{")
this.children(e,(function(e){"Declaration"===e.type&&this.chunk(";")}))
this.chunk("}")},walkContext:"block"}},8298:(e,t,r)=>{var n=r(8074).TYPE
var a=n.LeftSquareBracket
var i=n.RightSquareBracket
e.exports={name:"Brackets",structure:{children:[[]]},parse:function(e,t){var r=this.scanner.tokenStart
var n
this.eat(a)
n=e.call(this,t)
this.scanner.eof||this.eat(i)
return{type:"Brackets",loc:this.getLocation(r,this.scanner.tokenStart),children:n}},generate:function(e){this.chunk("[")
this.children(e)
this.chunk("]")}}},6057:(e,t,r)=>{var n=r(8074).TYPE.CDC
e.exports={name:"CDC",structure:[],parse:function(){var e=this.scanner.tokenStart
this.eat(n)
return{type:"CDC",loc:this.getLocation(e,this.scanner.tokenStart)}},generate:function(){this.chunk("--\x3e")}}},4048:(e,t,r)=>{var n=r(8074).TYPE.CDO
e.exports={name:"CDO",structure:[],parse:function(){var e=this.scanner.tokenStart
this.eat(n)
return{type:"CDO",loc:this.getLocation(e,this.scanner.tokenStart)}},generate:function(){this.chunk("\x3c!--")}}},5227:(e,t,r)=>{var n=r(8074).TYPE.Ident
e.exports={name:"ClassSelector",structure:{name:String},parse:function(){this.scanner.isDelim(46)||this.error("Full stop is expected")
this.scanner.next()
return{type:"ClassSelector",loc:this.getLocation(this.scanner.tokenStart-1,this.scanner.tokenEnd),name:this.consume(n)}},generate:function(e){this.chunk(".")
this.chunk(e.name)}}},1274:(e,t,r)=>{var n=r(8074).TYPE.Ident
e.exports={name:"Combinator",structure:{name:String},parse:function(){var e=this.scanner.tokenStart
switch(this.scanner.source.charCodeAt(this.scanner.tokenStart)){case 62:case 43:case 126:this.scanner.next()
break
case 47:this.scanner.next()
this.scanner.tokenType===n&&!1!==this.scanner.lookupValue(0,"deep")||this.error("Identifier `deep` is expected")
this.scanner.next()
this.scanner.isDelim(47)||this.error("Solidus is expected")
this.scanner.next()
break
default:this.error("Combinator is expected")}return{type:"Combinator",loc:this.getLocation(e,this.scanner.tokenStart),name:this.scanner.substrToCursor(e)}},generate:function(e){this.chunk(e.name)}}},9548:(e,t,r)=>{var n=r(8074).TYPE.Comment
e.exports={name:"Comment",structure:{value:String},parse:function(){var e=this.scanner.tokenStart
var t=this.scanner.tokenEnd
this.eat(n)
t-e+2>=2&&42===this.scanner.source.charCodeAt(t-2)&&47===this.scanner.source.charCodeAt(t-1)&&(t-=2)
return{type:"Comment",loc:this.getLocation(e,this.scanner.tokenStart),value:this.scanner.source.substring(e+2,t)}},generate:function(e){this.chunk("/*")
this.chunk(e.value)
this.chunk("*/")}}},2766:(e,t,r)=>{var n=r(4266).isCustomProperty
var a=r(8074).TYPE
var i=r(2832).mode
var o=a.Ident
var s=a.Hash
var l=a.Colon
var c=a.Semicolon
var d=a.Delim
var u=a.WhiteSpace
function p(e){return this.Raw(e,i.exclamationMarkOrSemicolon,!0)}function m(e){return this.Raw(e,i.exclamationMarkOrSemicolon,!1)}function f(){var e=this.scanner.tokenIndex
var t=this.Value()
"Raw"!==t.type&&!1===this.scanner.eof&&this.scanner.tokenType!==c&&!1===this.scanner.isDelim(33)&&!1===this.scanner.isBalanceEdge(e)&&this.error()
return t}e.exports={name:"Declaration",structure:{important:[Boolean,String],property:String,value:["Value","Raw"]},parse:function(){var e=this.scanner.tokenStart
var t=this.scanner.tokenIndex
var r=h.call(this)
var a=n(r)
var i=a?this.parseCustomProperty:this.parseValue
var o=a?m:p
var s=!1
var d
this.scanner.skipSC()
this.eat(l)
const v=this.scanner.tokenIndex
a||this.scanner.skipSC()
d=i?this.parseWithFallback(f,o):o.call(this,this.scanner.tokenIndex)
if(a&&"Value"===d.type&&d.children.isEmpty())for(let e=v-this.scanner.tokenIndex;e<=0;e++)if(this.scanner.lookupType(e)===u){d.children.appendData({type:"WhiteSpace",loc:null,value:" "})
break}if(this.scanner.isDelim(33)){s=g.call(this)
this.scanner.skipSC()}!1===this.scanner.eof&&this.scanner.tokenType!==c&&!1===this.scanner.isBalanceEdge(t)&&this.error()
return{type:"Declaration",loc:this.getLocation(e,this.scanner.tokenStart),important:s,property:r,value:d}},generate:function(e){this.chunk(e.property)
this.chunk(":")
this.node(e.value)
e.important&&this.chunk(!0===e.important?"!important":"!"+e.important)},walkContext:"declaration"}
function h(){var e=this.scanner.tokenStart
if(this.scanner.tokenType===d)switch(this.scanner.source.charCodeAt(this.scanner.tokenStart)){case 42:case 36:case 43:case 35:case 38:this.scanner.next()
break
case 47:this.scanner.next()
this.scanner.isDelim(47)&&this.scanner.next()}this.scanner.tokenType===s?this.eat(s):this.eat(o)
return this.scanner.substrToCursor(e)}function g(){this.eat(d)
this.scanner.skipSC()
var e=this.consume(o)
return"important"===e||e}},688:(e,t,r)=>{var n=r(8074).TYPE
var a=r(2832).mode
var i=n.WhiteSpace
var o=n.Comment
var s=n.Semicolon
function l(e){return this.Raw(e,a.semicolonIncluded,!0)}e.exports={name:"DeclarationList",structure:{children:[["Declaration"]]},parse:function(){var e=this.createList()
for(;!this.scanner.eof;)switch(this.scanner.tokenType){case i:case o:case s:this.scanner.next()
break
default:e.push(this.parseWithFallback(this.Declaration,l))}return{type:"DeclarationList",loc:this.getLocationFromList(e),children:e}},generate:function(e){this.children(e,(function(e){"Declaration"===e.type&&this.chunk(";")}))}}},9898:(e,t,r)=>{var n=r(456).consumeNumber
var a=r(8074).TYPE.Dimension
e.exports={name:"Dimension",structure:{value:String,unit:String},parse:function(){var e=this.scanner.tokenStart
var t=n(this.scanner.source,e)
this.eat(a)
return{type:"Dimension",loc:this.getLocation(e,this.scanner.tokenStart),value:this.scanner.source.substring(e,t),unit:this.scanner.source.substring(t,this.scanner.tokenStart)}},generate:function(e){this.chunk(e.value)
this.chunk(e.unit)}}},9467:(e,t,r)=>{var n=r(8074).TYPE.RightParenthesis
e.exports={name:"Function",structure:{name:String,children:[[]]},parse:function(e,t){var r=this.scanner.tokenStart
var a=this.consumeFunctionName()
var i=a.toLowerCase()
var o
o=t.hasOwnProperty(i)?t[i].call(this,t):e.call(this,t)
this.scanner.eof||this.eat(n)
return{type:"Function",loc:this.getLocation(r,this.scanner.tokenStart),name:a,children:o}},generate:function(e){this.chunk(e.name)
this.chunk("(")
this.children(e)
this.chunk(")")},walkContext:"function"}},5333:(e,t,r)=>{var n=r(8074).TYPE.Hash
e.exports={name:"Hash",structure:{value:String},parse:function(){var e=this.scanner.tokenStart
this.eat(n)
return{type:"Hash",loc:this.getLocation(e,this.scanner.tokenStart),value:this.scanner.substrToCursor(e+1)}},generate:function(e){this.chunk("#")
this.chunk(e.value)}}},5452:(e,t,r)=>{var n=r(8074).TYPE.Hash
e.exports={name:"IdSelector",structure:{name:String},parse:function(){var e=this.scanner.tokenStart
this.eat(n)
return{type:"IdSelector",loc:this.getLocation(e,this.scanner.tokenStart),name:this.scanner.substrToCursor(e+1)}},generate:function(e){this.chunk("#")
this.chunk(e.name)}}},2087:(e,t,r)=>{var n=r(8074).TYPE.Ident
e.exports={name:"Identifier",structure:{name:String},parse:function(){return{type:"Identifier",loc:this.getLocation(this.scanner.tokenStart,this.scanner.tokenEnd),name:this.consume(n)}},generate:function(e){this.chunk(e.name)}}},6917:(e,t,r)=>{var n=r(8074).TYPE
var a=n.Ident
var i=n.Number
var o=n.Dimension
var s=n.LeftParenthesis
var l=n.RightParenthesis
var c=n.Colon
var d=n.Delim
e.exports={name:"MediaFeature",structure:{name:String,value:["Identifier","Number","Dimension","Ratio",null]},parse:function(){var e=this.scanner.tokenStart
var t
var r=null
this.eat(s)
this.scanner.skipSC()
t=this.consume(a)
this.scanner.skipSC()
if(this.scanner.tokenType!==l){this.eat(c)
this.scanner.skipSC()
switch(this.scanner.tokenType){case i:r=this.lookupNonWSType(1)===d?this.Ratio():this.Number()
break
case o:r=this.Dimension()
break
case a:r=this.Identifier()
break
default:this.error("Number, dimension, ratio or identifier is expected")}this.scanner.skipSC()}this.eat(l)
return{type:"MediaFeature",loc:this.getLocation(e,this.scanner.tokenStart),name:t,value:r}},generate:function(e){this.chunk("(")
this.chunk(e.name)
if(null!==e.value){this.chunk(":")
this.node(e.value)}this.chunk(")")}}},2356:(e,t,r)=>{var n=r(8074).TYPE
var a=n.WhiteSpace
var i=n.Comment
var o=n.Ident
var s=n.LeftParenthesis
e.exports={name:"MediaQuery",structure:{children:[["Identifier","MediaFeature","WhiteSpace"]]},parse:function(){this.scanner.skipSC()
var e=this.createList()
var t=null
var r=null
e:for(;!this.scanner.eof;){switch(this.scanner.tokenType){case i:this.scanner.next()
continue
case a:r=this.WhiteSpace()
continue
case o:t=this.Identifier()
break
case s:t=this.MediaFeature()
break
default:break e}if(null!==r){e.push(r)
r=null}e.push(t)}null===t&&this.error("Identifier or parenthesis is expected")
return{type:"MediaQuery",loc:this.getLocationFromList(e),children:e}},generate:function(e){this.children(e)}}},9985:(e,t,r)=>{var n=r(8074).TYPE.Comma
e.exports={name:"MediaQueryList",structure:{children:[["MediaQuery"]]},parse:function(e){var t=this.createList()
this.scanner.skipSC()
for(;!this.scanner.eof;){t.push(this.MediaQuery(e))
if(this.scanner.tokenType!==n)break
this.scanner.next()}return{type:"MediaQueryList",loc:this.getLocationFromList(t),children:t}},generate:function(e){this.children(e,(function(){this.chunk(",")}))}}},6846:e=>{e.exports={name:"Nth",structure:{nth:["AnPlusB","Identifier"],selector:["SelectorList",null]},parse:function(e){this.scanner.skipSC()
var t=this.scanner.tokenStart
var r=t
var n=null
var a
a=this.scanner.lookupValue(0,"odd")||this.scanner.lookupValue(0,"even")?this.Identifier():this.AnPlusB()
this.scanner.skipSC()
if(e&&this.scanner.lookupValue(0,"of")){this.scanner.next()
n=this.SelectorList()
this.needPositions&&(r=this.getLastListNode(n.children).loc.end.offset)}else this.needPositions&&(r=a.loc.end.offset)
return{type:"Nth",loc:this.getLocation(t,r),nth:a,selector:n}},generate:function(e){this.node(e.nth)
if(null!==e.selector){this.chunk(" of ")
this.node(e.selector)}}}},8780:(e,t,r)=>{var n=r(8074).TYPE.Number
e.exports={name:"Number",structure:{value:String},parse:function(){return{type:"Number",loc:this.getLocation(this.scanner.tokenStart,this.scanner.tokenEnd),value:this.consume(n)}},generate:function(e){this.chunk(e.value)}}},9882:e=>{e.exports={name:"Operator",structure:{value:String},parse:function(){var e=this.scanner.tokenStart
this.scanner.next()
return{type:"Operator",loc:this.getLocation(e,this.scanner.tokenStart),value:this.scanner.substrToCursor(e)}},generate:function(e){this.chunk(e.value)}}},851:(e,t,r)=>{var n=r(8074).TYPE
var a=n.LeftParenthesis
var i=n.RightParenthesis
e.exports={name:"Parentheses",structure:{children:[[]]},parse:function(e,t){var r=this.scanner.tokenStart
var n
this.eat(a)
n=e.call(this,t)
this.scanner.eof||this.eat(i)
return{type:"Parentheses",loc:this.getLocation(r,this.scanner.tokenStart),children:n}},generate:function(e){this.chunk("(")
this.children(e)
this.chunk(")")}}},5824:(e,t,r)=>{var n=r(456).consumeNumber
var a=r(8074).TYPE.Percentage
e.exports={name:"Percentage",structure:{value:String},parse:function(){var e=this.scanner.tokenStart
var t=n(this.scanner.source,e)
this.eat(a)
return{type:"Percentage",loc:this.getLocation(e,this.scanner.tokenStart),value:this.scanner.source.substring(e,t)}},generate:function(e){this.chunk(e.value)
this.chunk("%")}}},5520:(e,t,r)=>{var n=r(8074).TYPE
var a=n.Ident
var i=n.Function
var o=n.Colon
var s=n.RightParenthesis
e.exports={name:"PseudoClassSelector",structure:{name:String,children:[["Raw"],null]},parse:function(){var e=this.scanner.tokenStart
var t=null
var r
var n
this.eat(o)
if(this.scanner.tokenType===i){n=(r=this.consumeFunctionName()).toLowerCase()
if(this.pseudo.hasOwnProperty(n)){this.scanner.skipSC()
t=this.pseudo[n].call(this)
this.scanner.skipSC()}else(t=this.createList()).push(this.Raw(this.scanner.tokenIndex,null,!1))
this.eat(s)}else r=this.consume(a)
return{type:"PseudoClassSelector",loc:this.getLocation(e,this.scanner.tokenStart),name:r,children:t}},generate:function(e){this.chunk(":")
this.chunk(e.name)
if(null!==e.children){this.chunk("(")
this.children(e)
this.chunk(")")}},walkContext:"function"}},3094:(e,t,r)=>{var n=r(8074).TYPE
var a=n.Ident
var i=n.Function
var o=n.Colon
var s=n.RightParenthesis
e.exports={name:"PseudoElementSelector",structure:{name:String,children:[["Raw"],null]},parse:function(){var e=this.scanner.tokenStart
var t=null
var r
var n
this.eat(o)
this.eat(o)
if(this.scanner.tokenType===i){n=(r=this.consumeFunctionName()).toLowerCase()
if(this.pseudo.hasOwnProperty(n)){this.scanner.skipSC()
t=this.pseudo[n].call(this)
this.scanner.skipSC()}else(t=this.createList()).push(this.Raw(this.scanner.tokenIndex,null,!1))
this.eat(s)}else r=this.consume(a)
return{type:"PseudoElementSelector",loc:this.getLocation(e,this.scanner.tokenStart),name:r,children:t}},generate:function(e){this.chunk("::")
this.chunk(e.name)
if(null!==e.children){this.chunk("(")
this.children(e)
this.chunk(")")}},walkContext:"function"}},951:(e,t,r)=>{var n=r(8074).isDigit
var a=r(8074).TYPE
var i=a.Number
var o=a.Delim
function s(){this.scanner.skipWS()
var e=this.consume(i)
for(var t=0;t<e.length;t++){var r=e.charCodeAt(t)
n(r)||46===r||this.error("Unsigned number is expected",this.scanner.tokenStart-e.length+t)}0===Number(e)&&this.error("Zero number is not allowed",this.scanner.tokenStart-e.length)
return e}e.exports={name:"Ratio",structure:{left:String,right:String},parse:function(){var e=this.scanner.tokenStart
var t=s.call(this)
var r
this.scanner.skipWS()
this.scanner.isDelim(47)||this.error("Solidus is expected")
this.eat(o)
r=s.call(this)
return{type:"Ratio",loc:this.getLocation(e,this.scanner.tokenStart),left:t,right:r}},generate:function(e){this.chunk(e.left)
this.chunk("/")
this.chunk(e.right)}}},2832:(e,t,r)=>{var n=r(8074).TYPE
var a=n.WhiteSpace
var i=n.Semicolon
var o=n.LeftCurlyBracket
var s=n.Delim
function l(){return this.scanner.tokenIndex>0&&this.scanner.lookupType(-1)===a?this.scanner.tokenIndex>1?this.scanner.getTokenStart(this.scanner.tokenIndex-1):this.scanner.firstCharOffset:this.scanner.tokenStart}function c(){return 0}e.exports={name:"Raw",structure:{value:String},parse:function(e,t,r){var n=this.scanner.getTokenStart(e)
var a
this.scanner.skip(this.scanner.getRawLength(e,t||c))
a=r&&this.scanner.tokenStart>n?l.call(this):this.scanner.tokenStart
return{type:"Raw",loc:this.getLocation(n,a),value:this.scanner.source.substring(n,a)}},generate:function(e){this.chunk(e.value)},mode:{default:c,leftCurlyBracket:function(e){return e===o?1:0},leftCurlyBracketOrSemicolon:function(e){return e===o||e===i?1:0},exclamationMarkOrSemicolon:function(e,t,r){return e===s&&33===t.charCodeAt(r)||e===i?1:0},semicolonIncluded:function(e){return e===i?2:0}}}},646:(e,t,r)=>{var n=r(8074).TYPE
var a=r(2832).mode
var i=n.LeftCurlyBracket
function o(e){return this.Raw(e,a.leftCurlyBracket,!0)}function s(){var e=this.SelectorList()
"Raw"!==e.type&&!1===this.scanner.eof&&this.scanner.tokenType!==i&&this.error()
return e}e.exports={name:"Rule",structure:{prelude:["SelectorList","Raw"],block:["Block"]},parse:function(){var e=this.scanner.tokenIndex
var t=this.scanner.tokenStart
var r
var n
r=this.parseRulePrelude?this.parseWithFallback(s,o):o.call(this,e)
n=this.Block(!0)
return{type:"Rule",loc:this.getLocation(t,this.scanner.tokenStart),prelude:r,block:n}},generate:function(e){this.node(e.prelude)
this.node(e.block)},walkContext:"rule"}},5760:e=>{e.exports={name:"Selector",structure:{children:[["TypeSelector","IdSelector","ClassSelector","AttributeSelector","PseudoClassSelector","PseudoElementSelector","Combinator","WhiteSpace"]]},parse:function(){var e=this.readSequence(this.scope.Selector)
null===this.getFirstListNode(e)&&this.error("Selector is expected")
return{type:"Selector",loc:this.getLocationFromList(e),children:e}},generate:function(e){this.children(e)}}},4555:(e,t,r)=>{var n=r(8074).TYPE.Comma
e.exports={name:"SelectorList",structure:{children:[["Selector","Raw"]]},parse:function(){var e=this.createList()
for(;!this.scanner.eof;){e.push(this.Selector())
if(this.scanner.tokenType!==n)break
this.scanner.next()}return{type:"SelectorList",loc:this.getLocationFromList(e),children:e}},generate:function(e){this.children(e,(function(){this.chunk(",")}))},walkContext:"selector"}},6015:(e,t,r)=>{var n=r(8074).TYPE.String
e.exports={name:"String",structure:{value:String},parse:function(){return{type:"String",loc:this.getLocation(this.scanner.tokenStart,this.scanner.tokenEnd),value:this.consume(n)}},generate:function(e){this.chunk(e.value)}}},6796:(e,t,r)=>{var n=r(8074).TYPE
var a=n.WhiteSpace
var i=n.Comment
var o=n.AtKeyword
var s=n.CDO
var l=n.CDC
function c(e){return this.Raw(e,null,!1)}e.exports={name:"StyleSheet",structure:{children:[["Comment","CDO","CDC","Atrule","Rule","Raw"]]},parse:function(){var e=this.scanner.tokenStart
var t=this.createList()
var r
for(;!this.scanner.eof;){switch(this.scanner.tokenType){case a:this.scanner.next()
continue
case i:if(33!==this.scanner.source.charCodeAt(this.scanner.tokenStart+2)){this.scanner.next()
continue}r=this.Comment()
break
case s:r=this.CDO()
break
case l:r=this.CDC()
break
case o:r=this.parseWithFallback(this.Atrule,c)
break
default:r=this.parseWithFallback(this.Rule,c)}t.push(r)}return{type:"StyleSheet",loc:this.getLocation(e,this.scanner.tokenStart),children:t}},generate:function(e){this.children(e)},walkContext:"stylesheet"}},9422:(e,t,r)=>{var n=r(8074).TYPE.Ident
function a(){this.scanner.tokenType!==n&&!1===this.scanner.isDelim(42)&&this.error("Identifier or asterisk is expected")
this.scanner.next()}e.exports={name:"TypeSelector",structure:{name:String},parse:function(){var e=this.scanner.tokenStart
if(this.scanner.isDelim(124)){this.scanner.next()
a.call(this)}else{a.call(this)
if(this.scanner.isDelim(124)){this.scanner.next()
a.call(this)}}return{type:"TypeSelector",loc:this.getLocation(e,this.scanner.tokenStart),name:this.scanner.substrToCursor(e)}},generate:function(e){this.chunk(e.name)}}},7759:(e,t,r)=>{var n=r(8074).isHexDigit
var a=r(8074).cmpChar
var i=r(8074).TYPE
var o=r(8074).NAME
var s=i.Ident
var l=i.Number
var c=i.Dimension
function d(e,t){for(var r=this.scanner.tokenStart+e,a=0;r<this.scanner.tokenEnd;r++){var i=this.scanner.source.charCodeAt(r)
if(45===i&&t&&0!==a){0===d.call(this,e+a+1,!1)&&this.error()
return-1}n(i)||this.error(t&&0!==a?"HyphenMinus"+(a<6?" or hex digit":"")+" is expected":a<6?"Hex digit is expected":"Unexpected input",r);++a>6&&this.error("Too many hex digits",r)}this.scanner.next()
return a}function u(e){var t=0
for(;this.scanner.isDelim(63);){++t>e&&this.error("Too many question marks")
this.scanner.next()}}function p(e){this.scanner.source.charCodeAt(this.scanner.tokenStart)!==e&&this.error(o[e]+" is expected")}function m(){var e=0
if(this.scanner.isDelim(43)){this.scanner.next()
if(this.scanner.tokenType===s){(e=d.call(this,0,!0))>0&&u.call(this,6-e)
return}if(this.scanner.isDelim(63)){this.scanner.next()
u.call(this,5)
return}this.error("Hex digit or question mark is expected")}else if(this.scanner.tokenType!==l)if(this.scanner.tokenType!==c)this.error()
else{p.call(this,43);(e=d.call(this,1,!0))>0&&u.call(this,6-e)}else{p.call(this,43)
e=d.call(this,1,!0)
if(this.scanner.isDelim(63)){u.call(this,6-e)
return}if(this.scanner.tokenType===c||this.scanner.tokenType===l){p.call(this,45)
d.call(this,1,!1)
return}}}e.exports={name:"UnicodeRange",structure:{value:String},parse:function(){var e=this.scanner.tokenStart
a(this.scanner.source,e,117)||this.error("U is expected")
a(this.scanner.source,e+1,43)||this.error("Plus sign is expected")
this.scanner.next()
m.call(this)
return{type:"UnicodeRange",loc:this.getLocation(e,this.scanner.tokenStart),value:this.scanner.substrToCursor(e)}},generate:function(e){this.chunk(e.value)}}},7980:(e,t,r)=>{var n=r(8074).isWhiteSpace
var a=r(8074).cmpStr
var i=r(8074).TYPE
var o=i.Function
var s=i.Url
var l=i.RightParenthesis
e.exports={name:"Url",structure:{value:["String","Raw"]},parse:function(){var e=this.scanner.tokenStart
var t
switch(this.scanner.tokenType){case s:var r=e+4
var i=this.scanner.tokenEnd-1
for(;r<i&&n(this.scanner.source.charCodeAt(r));)r++
for(;r<i&&n(this.scanner.source.charCodeAt(i-1));)i--
t={type:"Raw",loc:this.getLocation(r,i),value:this.scanner.source.substring(r,i)}
this.eat(s)
break
case o:a(this.scanner.source,this.scanner.tokenStart,this.scanner.tokenEnd,"url(")||this.error("Function name must be `url`")
this.eat(o)
this.scanner.skipSC()
t=this.String()
this.scanner.skipSC()
this.eat(l)
break
default:this.error("Url or Function is expected")}return{type:"Url",loc:this.getLocation(e,this.scanner.tokenStart),value:t}},generate:function(e){this.chunk("url")
this.chunk("(")
this.node(e.value)
this.chunk(")")}}},2560:e=>{e.exports={name:"Value",structure:{children:[[]]},parse:function(){var e=this.scanner.tokenStart
var t=this.readSequence(this.scope.Value)
return{type:"Value",loc:this.getLocation(e,this.scanner.tokenStart),children:t}},generate:function(e){this.children(e)}}},5292:(e,t,r)=>{var n=r(8074).TYPE.WhiteSpace
var a=Object.freeze({type:"WhiteSpace",loc:null,value:" "})
e.exports={name:"WhiteSpace",structure:{value:String},parse:function(){this.eat(n)
return a},generate:function(e){this.chunk(e.value)}}},6518:(e,t,r)=>{e.exports={AnPlusB:r(8850),Atrule:r(7440),AtrulePrelude:r(4e3),AttributeSelector:r(5337),Block:r(2061),Brackets:r(8298),CDC:r(6057),CDO:r(4048),ClassSelector:r(5227),Combinator:r(1274),Comment:r(9548),Declaration:r(2766),DeclarationList:r(688),Dimension:r(9898),Function:r(9467),Hash:r(5333),Identifier:r(2087),IdSelector:r(5452),MediaFeature:r(6917),MediaQuery:r(2356),MediaQueryList:r(9985),Nth:r(6846),Number:r(8780),Operator:r(9882),Parentheses:r(851),Percentage:r(5824),PseudoClassSelector:r(5520),PseudoElementSelector:r(3094),Ratio:r(951),Raw:r(2832),Rule:r(646),Selector:r(5760),SelectorList:r(4555),String:r(6015),StyleSheet:r(6796),TypeSelector:r(9422),UnicodeRange:r(7759),Url:r(7980),Value:r(2560),WhiteSpace:r(5292)}},6121:e=>{e.exports={parse:function(){return this.createSingleNodeList(this.Nth(!1))}}},1998:e=>{e.exports={parse:function(){return this.createSingleNodeList(this.Nth(!0))}}},3467:e=>{e.exports={parse:function(){return this.createSingleNodeList(this.SelectorList())}}},5081:e=>{e.exports={parse:function(){return this.createSingleNodeList(this.Identifier())}}},1669:e=>{e.exports={parse:function(){return this.createSingleNodeList(this.SelectorList())}}},3553:(e,t,r)=>{e.exports={dir:r(5081),has:r(1669),lang:r(2374),matches:r(5526),not:r(5171),"nth-child":r(170),"nth-last-child":r(3298),"nth-last-of-type":r(9648),"nth-of-type":r(661),slotted:r(6329)}},2374:e=>{e.exports={parse:function(){return this.createSingleNodeList(this.Identifier())}}},5526:(e,t,r)=>{e.exports=r(3467)},5171:(e,t,r)=>{e.exports=r(3467)},170:(e,t,r)=>{e.exports=r(1998)},3298:(e,t,r)=>{e.exports=r(1998)},9648:(e,t,r)=>{e.exports=r(6121)},661:(e,t,r)=>{e.exports=r(6121)},6329:e=>{e.exports={parse:function(){return this.createSingleNodeList(this.Selector())}}},8830:(e,t,r)=>{e.exports={getNode:r(7879)}},7879:(e,t,r)=>{var n=r(8074).cmpChar
var a=r(8074).cmpStr
var i=r(8074).TYPE
var o=i.Ident
var s=i.String
var l=i.Number
var c=i.Function
var d=i.Url
var u=i.Hash
var p=i.Dimension
var m=i.Percentage
var f=i.LeftParenthesis
var h=i.LeftSquareBracket
var g=i.Comma
var v=i.Delim
e.exports=function(e){switch(this.scanner.tokenType){case u:return this.Hash()
case g:e.space=null
e.ignoreWSAfter=!0
return this.Operator()
case f:return this.Parentheses(this.readSequence,e.recognizer)
case h:return this.Brackets(this.readSequence,e.recognizer)
case s:return this.String()
case p:return this.Dimension()
case m:return this.Percentage()
case l:return this.Number()
case c:return a(this.scanner.source,this.scanner.tokenStart,this.scanner.tokenEnd,"url(")?this.Url():this.Function(this.readSequence,e.recognizer)
case d:return this.Url()
case o:return n(this.scanner.source,this.scanner.tokenStart,117)&&n(this.scanner.source,this.scanner.tokenStart+1,43)?this.UnicodeRange():this.Identifier()
case v:var t=this.scanner.source.charCodeAt(this.scanner.tokenStart)
if(47===t||42===t||43===t||45===t)return this.Operator()
35===t&&this.error("Hex or identifier is expected",this.scanner.tokenStart+1)}}},4598:(e,t,r)=>{e.exports={AtrulePrelude:r(8830),Selector:r(5212),Value:r(7144)}},5212:(e,t,r)=>{var n=r(8074).TYPE
var a=n.Delim
var i=n.Ident
var o=n.Dimension
var s=n.Percentage
var l=n.Number
var c=n.Hash
var d=n.Colon
var u=n.LeftSquareBracket
e.exports={getNode:function(e){switch(this.scanner.tokenType){case u:return this.AttributeSelector()
case c:return this.IdSelector()
case d:return this.scanner.lookupType(1)===d?this.PseudoElementSelector():this.PseudoClassSelector()
case i:return this.TypeSelector()
case l:case s:return this.Percentage()
case o:46===this.scanner.source.charCodeAt(this.scanner.tokenStart)&&this.error("Identifier is expected",this.scanner.tokenStart+1)
break
case a:switch(this.scanner.source.charCodeAt(this.scanner.tokenStart)){case 43:case 62:case 126:e.space=null
e.ignoreWSAfter=!0
return this.Combinator()
case 47:return this.Combinator()
case 46:return this.ClassSelector()
case 42:case 124:return this.TypeSelector()
case 35:return this.IdSelector()}}}}},7144:(e,t,r)=>{e.exports={getNode:r(7879),expression:r(3369),var:r(126)}},9035:e=>{function t(e){return e>=48&&e<=57}function r(e){return e>=65&&e<=90}function n(e){return e>=97&&e<=122}function a(e){return r(e)||n(e)}function i(e){return e>=128}function o(e){return a(e)||i(e)||95===e}function s(e){return e>=0&&e<=8||11===e||e>=14&&e<=31||127===e}function l(e){return 10===e||13===e||12===e}function c(e){return l(e)||32===e||9===e}function d(e,t){return 92===e&&!l(t)&&0!==t}var u=new Array(128)
m.Eof=128
m.WhiteSpace=130
m.Digit=131
m.NameStart=132
m.NonPrintable=133
for(var p=0;p<u.length;p++)switch(!0){case c(p):u[p]=m.WhiteSpace
break
case t(p):u[p]=m.Digit
break
case o(p):u[p]=m.NameStart
break
case s(p):u[p]=m.NonPrintable
break
default:u[p]=p||m.Eof}function m(e){return e<128?u[e]:m.NameStart}e.exports={isDigit:t,isHexDigit:function(e){return t(e)||e>=65&&e<=70||e>=97&&e<=102},isUppercaseLetter:r,isLowercaseLetter:n,isLetter:a,isNonAscii:i,isNameStart:o,isName:function(e){return o(e)||t(e)||45===e},isNonPrintable:s,isNewline:l,isWhiteSpace:c,isValidEscape:d,isIdentifierStart:function(e,t,r){return 45===e?o(t)||45===t||d(t,r):!!o(e)||92===e&&d(e,t)},isNumberStart:function(e,r,n){return 43===e||45===e?t(r)?2:46===r&&t(n)?3:0:46===e?t(r)?2:0:t(e)?1:0},isBOM:function(e){return 65279===e||65534===e?1:0},charCodeCategory:m}},9856:e=>{var t={EOF:0,Ident:1,Function:2,AtKeyword:3,Hash:4,String:5,BadString:6,Url:7,BadUrl:8,Delim:9,Number:10,Percentage:11,Dimension:12,WhiteSpace:13,CDO:14,CDC:15,Colon:16,Semicolon:17,Comma:18,LeftSquareBracket:19,RightSquareBracket:20,LeftParenthesis:21,RightParenthesis:22,LeftCurlyBracket:23,RightCurlyBracket:24,Comment:25}
var r=Object.keys(t).reduce((function(e,r){e[t[r]]=r
return e}),{})
e.exports={TYPE:t,NAME:r}},8074:(e,t,r)=>{var n=r(6418)
var a=r(6048)
var i=r(9856)
var o=i.TYPE
var s=r(9035)
var l=s.isNewline
var c=s.isName
var d=s.isValidEscape
var u=s.isNumberStart
var p=s.isIdentifierStart
var m=s.charCodeCategory
var f=s.isBOM
var h=r(456)
var g=h.cmpStr
var v=h.getNewlineLength
var y=h.findWhiteSpaceEnd
var b=h.consumeEscaped
var S=h.consumeName
var x=h.consumeNumber
var k=h.consumeBadUrlRemnants
var w=16777215
var C=24
function T(e,t){function r(t){return t<T?e.charCodeAt(t):0}function i(){_=x(e,_)
if(p(r(_),r(_+1),r(_+2))){B=o.Dimension
_=S(e,_)}else if(37!==r(_))B=o.Number
else{B=o.Percentage
_++}}function s(){const t=_
_=S(e,_)
if(g(e,t,_,"url")&&40===r(_)){if(34===r(_=y(e,_+1))||39===r(_)){B=o.Function
_=t+4
return}!function(){B=o.Url
_=y(e,_)
for(;_<e.length;_++){var t=e.charCodeAt(_)
switch(m(t)){case 41:_++
return
case m.Eof:return
case m.WhiteSpace:if(41===r(_=y(e,_))||_>=e.length){_<e.length&&_++
return}_=k(e,_)
B=o.BadUrl
return
case 34:case 39:case 40:case m.NonPrintable:_=k(e,_)
B=o.BadUrl
return
case 92:if(d(t,r(_+1))){_=b(e,_)-1
break}_=k(e,_)
B=o.BadUrl
return}}}()}else if(40!==r(_))B=o.Ident
else{B=o.Function
_++}}function h(t){t||(t=r(_++))
B=o.String
for(;_<e.length;_++){var n=e.charCodeAt(_)
switch(m(n)){case t:_++
return
case m.Eof:return
case m.WhiteSpace:if(l(n)){_+=v(e,_,n)
B=o.BadString
return}break
case 92:if(_===e.length-1)break
var a=r(_+1)
l(a)?_+=v(e,_+1,a):d(n,a)&&(_=b(e,_)-1)}}}t||(t=new n)
var T=(e=String(e||"")).length
var A=a(t.offsetAndType,T+1)
var E=a(t.balance,T+1)
var O=0
var z=f(r(0))
var _=z
var P=0
var q=0
var L=0
for(;_<T;){var W=e.charCodeAt(_)
var B=0
E[O]=T
switch(m(W)){case m.WhiteSpace:B=o.WhiteSpace
_=y(e,_+1)
break
case 34:h()
break
case 35:if(c(r(_+1))||d(r(_+1),r(_+2))){B=o.Hash
_=S(e,_+1)}else{B=o.Delim
_++}break
case 39:h()
break
case 40:B=o.LeftParenthesis
_++
break
case 41:B=o.RightParenthesis
_++
break
case 43:if(u(W,r(_+1),r(_+2)))i()
else{B=o.Delim
_++}break
case 44:B=o.Comma
_++
break
case 45:if(u(W,r(_+1),r(_+2)))i()
else if(45===r(_+1)&&62===r(_+2)){B=o.CDC
_+=3}else if(p(W,r(_+1),r(_+2)))s()
else{B=o.Delim
_++}break
case 46:if(u(W,r(_+1),r(_+2)))i()
else{B=o.Delim
_++}break
case 47:if(42===r(_+1)){B=o.Comment
1===(_=e.indexOf("*/",_+2)+2)&&(_=e.length)}else{B=o.Delim
_++}break
case 58:B=o.Colon
_++
break
case 59:B=o.Semicolon
_++
break
case 60:if(33===r(_+1)&&45===r(_+2)&&45===r(_+3)){B=o.CDO
_+=4}else{B=o.Delim
_++}break
case 64:if(p(r(_+1),r(_+2),r(_+3))){B=o.AtKeyword
_=S(e,_+1)}else{B=o.Delim
_++}break
case 91:B=o.LeftSquareBracket
_++
break
case 92:if(d(W,r(_+1)))s()
else{B=o.Delim
_++}break
case 93:B=o.RightSquareBracket
_++
break
case 123:B=o.LeftCurlyBracket
_++
break
case 125:B=o.RightCurlyBracket
_++
break
case m.Digit:i()
break
case m.NameStart:s()
break
case m.Eof:break
default:B=o.Delim
_++}switch(B){case P:P=(q=E[L=q&w])>>C
E[O]=L
E[L++]=O
for(;L<O;L++)E[L]===T&&(E[L]=O)
break
case o.LeftParenthesis:case o.Function:E[O]=q
q=(P=o.RightParenthesis)<<C|O
break
case o.LeftSquareBracket:E[O]=q
q=(P=o.RightSquareBracket)<<C|O
break
case o.LeftCurlyBracket:E[O]=q
q=(P=o.RightCurlyBracket)<<C|O}A[O++]=B<<C|_}A[O]=o.EOF<<C|_
E[O]=T
E[T]=T
for(;0!==q;){q=E[L=q&w]
E[L]=T}t.source=e
t.firstCharOffset=z
t.offsetAndType=A
t.tokenCount=O
t.balance=E
t.reset()
t.next()
return t}Object.keys(i).forEach((function(e){T[e]=i[e]}))
Object.keys(s).forEach((function(e){T[e]=s[e]}))
Object.keys(h).forEach((function(e){T[e]=h[e]}))
e.exports=T},456:(e,t,r)=>{var n=r(9035)
var a=n.isDigit
var i=n.isHexDigit
var o=n.isUppercaseLetter
var s=n.isName
var l=n.isWhiteSpace
var c=n.isValidEscape
function d(e,t){return t<e.length?e.charCodeAt(t):0}function u(e,t,r){return 13===r&&10===d(e,t+1)?2:1}function p(e,t,r){var n=e.charCodeAt(t)
o(n)&&(n|=32)
return n===r}function m(e,t){for(;t<e.length&&a(e.charCodeAt(t));t++);return t}function f(e,t){if(i(d(e,(t+=2)-1))){for(var r=Math.min(e.length,t+5);t<r&&i(d(e,t));t++);var n=d(e,t)
l(n)&&(t+=u(e,t,n))}return t}e.exports={consumeEscaped:f,consumeName:function(e,t){for(;t<e.length;t++){var r=e.charCodeAt(t)
if(!s(r)){if(!c(r,d(e,t+1)))break
t=f(e,t)-1}}return t},consumeNumber:function(e,t){var r=e.charCodeAt(t)
43!==r&&45!==r||(r=e.charCodeAt(t+=1))
if(a(r)){t=m(e,t+1)
r=e.charCodeAt(t)}if(46===r&&a(e.charCodeAt(t+1))){r=e.charCodeAt(t+=2)
t=m(e,t)}if(p(e,t,101)){var n=0
if(45===(r=e.charCodeAt(t+1))||43===r){n=1
r=e.charCodeAt(t+2)}a(r)&&(t=m(e,t+1+n+1))}return t},consumeBadUrlRemnants:function(e,t){for(;t<e.length;t++){var r=e.charCodeAt(t)
if(41===r){t++
break}c(r,d(e,t+1))&&(t=f(e,t))}return t},cmpChar:p,cmpStr:function(e,t,r,n){if(r-t!==n.length)return!1
if(t<0||r>e.length)return!1
for(var a=t;a<r;a++){var i=e.charCodeAt(a)
var s=n.charCodeAt(a-t)
o(i)&&(i|=32)
if(i!==s)return!1}return!0},getNewlineLength:u,findWhiteSpaceStart:function(e,t){for(;t>=0&&l(e.charCodeAt(t));t--);return t+1},findWhiteSpaceEnd:function(e,t){for(;t<e.length&&l(e.charCodeAt(t));t++);return t}}},4432:(e,t,r)=>{var n=r(1922)
e.exports=function e(t){var r={}
for(var a in t){var i=t[a]
i&&(Array.isArray(i)||i instanceof n?i=i.map(e):i.constructor===Object&&(i=e(i)))
r[a]=i}return r}},3095:e=>{e.exports=function(e,t){var r=Object.create(SyntaxError.prototype)
var n=new Error
r.name=e
r.message=t
Object.defineProperty(r,"stack",{get:function(){return(n.stack||"").replace(/^(.+\n){1,3}/,e+": "+t+"\n")}})
return r}},4266:e=>{var t=Object.prototype.hasOwnProperty
var r=Object.create(null)
var n=Object.create(null)
function a(e,t){t=t||0
return e.length-t>=2&&45===e.charCodeAt(t)&&45===e.charCodeAt(t+1)}function i(e,t){t=t||0
if(e.length-t>=3&&45===e.charCodeAt(t)&&45!==e.charCodeAt(t+1)){var r=e.indexOf("-",t+2)
if(-1!==r)return e.substring(t,r+1)}return""}e.exports={keyword:function(e){if(t.call(r,e))return r[e]
var n=e.toLowerCase()
if(t.call(r,n))return r[e]=r[n]
var o=a(n,0)
var s=o?"":i(n,0)
return r[e]=Object.freeze({basename:n.substr(s.length),name:n,vendor:s,prefix:s,custom:o})},property:function(e){if(t.call(n,e))return n[e]
var r=e
var o=e[0]
"/"===o?o="/"===e[1]?"//":"/":"_"!==o&&"*"!==o&&"$"!==o&&"#"!==o&&"+"!==o&&"&"!==o&&(o="")
var s=a(r,o.length)
if(!s){r=r.toLowerCase()
if(t.call(n,r))return n[e]=n[r]}var l=s?"":i(r,o.length)
var c=r.substr(0,o.length+l.length)
return n[e]=Object.freeze({basename:r.substr(c.length),name:r.substr(o.length),hack:o,vendor:l,prefix:c,custom:s})},isCustomProperty:a,vendorPrefix:i}},9772:e=>{var t=Object.prototype.hasOwnProperty
var r=function(){}
function n(e){return"function"==typeof e?e:r}function a(e,t){return function(r,n,a){r.type===t&&e.call(this,r,n,a)}}function i(e,r){var n=r.structure
var a=[]
for(var i in n)if(!1!==t.call(n,i)){var o=n[i]
var s={name:i,type:!1,nullable:!1}
Array.isArray(n[i])||(o=[n[i]])
for(var l=0;l<o.length;l++){var c=o[l]
null===c?s.nullable=!0:"string"==typeof c?s.type="node":Array.isArray(c)&&(s.type="list")}s.type&&a.push(s)}return a.length?{context:r.walkContext,fields:a}:null}function o(e,t){var r=e.fields.slice()
var n=e.context
var a="string"==typeof n
t&&r.reverse()
return function(e,i,o,s){var l
if(a){l=i[n]
i[n]=e}for(var c=0;c<r.length;c++){var d=r[c]
var u=e[d.name]
if(!d.nullable||u)if("list"===d.type){if(t?u.reduceRight(s,!1):u.reduce(s,!1))return!0}else if(o(u))return!0}a&&(i[n]=l)}}function s(e){return{Atrule:{StyleSheet:e.StyleSheet,Atrule:e.Atrule,Rule:e.Rule,Block:e.Block},Rule:{StyleSheet:e.StyleSheet,Atrule:e.Atrule,Rule:e.Rule,Block:e.Block},Declaration:{StyleSheet:e.StyleSheet,Atrule:e.Atrule,Rule:e.Rule,Block:e.Block,DeclarationList:e.DeclarationList}}}e.exports=function(e){var l=function(e){var r={}
for(var n in e.node)if(t.call(e.node,n)){var a=e.node[n]
if(!a.structure)throw new Error("Missed `structure` field in `"+n+"` node type definition")
r[n]=i(0,a)}return r}(e)
var c={}
var d={}
var u=Symbol("break-walk")
var p=Symbol("skip-node")
for(var m in l)if(t.call(l,m)&&null!==l[m]){c[m]=o(l[m],!1)
d[m]=o(l[m],!0)}var f=s(c)
var h=s(d)
var g=function(e,t){function i(e,t,r){var n=s.call(v,e,t,r)
return n===u||n!==p&&(!(!g.hasOwnProperty(e.type)||!g[e.type](e,v,i,o))||m.call(v,e,t,r)===u)}var o=(e,t,r,n)=>e||i(t,r,n)
var s=r
var m=r
var g=c
var v={break:u,skip:p,root:e,stylesheet:null,atrule:null,atrulePrelude:null,rule:null,selector:null,block:null,declaration:null,function:null}
if("function"==typeof t)s=t
else if(t){s=n(t.enter)
m=n(t.leave)
t.reverse&&(g=d)
if(t.visit){if(f.hasOwnProperty(t.visit))g=t.reverse?h[t.visit]:f[t.visit]
else if(!l.hasOwnProperty(t.visit))throw new Error("Bad value `"+t.visit+"` for `visit` option (should be: "+Object.keys(l).join(", ")+")")
s=a(s,t.visit)
m=a(m,t.visit)}}if(s===r&&m===r)throw new Error("Neither `enter` nor `leave` walker handler is set or both aren't a function")
i(e)}
g.break=u
g.skip=p
g.find=function(e,t){var r=null
g(e,(function(e,n,a){if(t.call(this,e,n,a)){r=e
return u}}))
return r}
g.findLast=function(e,t){var r=null
g(e,{reverse:!0,enter:function(e,n,a){if(t.call(this,e,n,a)){r=e
return u}}})
return r}
g.findAll=function(e,t){var r=[]
g(e,(function(e,n,a){t.call(this,e,n,a)&&r.push(e)}))
return r}
return g}},9528:function(e,t,r){"use strict"
var n=this&&this.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r)
Object.defineProperty(e,n,{enumerable:!0,get:function(){return t[r]}})}:function(e,t,r,n){void 0===n&&(n=r)
e[n]=t[r]})
var a=this&&this.__exportStar||function(e,t){for(var r in e)"default"===r||Object.prototype.hasOwnProperty.call(t,r)||n(t,e,r)}
var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}}
Object.defineProperty(t,"__esModule",{value:!0})
t.stringify=t.parse=void 0
a(r(155),t)
var o=r(155)
Object.defineProperty(t,"parse",{enumerable:!0,get:function(){return i(o).default}})
var s=r(6566)
Object.defineProperty(t,"stringify",{enumerable:!0,get:function(){return i(s).default}})},155:function(e,t){"use strict"
var r=this&&this.__spreadArrays||function(){for(var e=0,t=0,r=arguments.length;t<r;t++)e+=arguments[t].length
var n=Array(e),a=0
for(t=0;t<r;t++)for(var i=arguments[t],o=0,s=i.length;o<s;o++,a++)n[a]=i[o]
return n}
Object.defineProperty(t,"__esModule",{value:!0})
t.isTraversal=void 0
var n=/^[^\\#]?(?:\\(?:[\da-f]{1,6}\s?|.)|[\w\-\u00b0-\uFFFF])+/
var a=/\\([\da-f]{1,6}\s?|(\s)|.)/gi
var i=/^\s*(?:(\*|[-\w]*)\|)?((?:\\.|[\w\u00b0-\uFFFF-])+)\s*(?:(\S?)=\s*(?:(['"])((?:[^\\]|\\[^])*?)\4|(#?(?:\\.|[\w\u00b0-\uFFFF-])*)|)|)\s*([iI])?\]/
var o={undefined:"exists","":"equals","~":"element","^":"start",$:"end","*":"any","!":"not","|":"hyphen"}
var s={">":"child","<":"parent","~":"sibling","+":"adjacent"}
var l={"#":["id","equals"],".":["class","element"]}
var c=new Set(["has","not","matches","is","host","host-context"])
var d=new Set(r(["descendant"],Object.keys(s).map((function(e){return s[e]}))))
function u(e){return d.has(e.type)}t.isTraversal=u
var p=new Set(["contains","icontains"])
var m=new Set(['"',"'"])
function f(e,t,r){var n=parseInt(t,16)-65536
return n!=n||r?t:n<0?String.fromCharCode(n+65536):String.fromCharCode(n>>10|55296,1023&n|56320)}function h(e){return e.replace(a,f)}function g(e){return" "===e||"\n"===e||"\t"===e||"\f"===e||"\r"===e}t.default=function(e,t){var r=[]
var n=v(r,""+e,t,0)
if(n<e.length)throw new Error("Unmatched selector: "+e.slice(n))
return r}
function v(e,t,r,a){var d,f
void 0===r&&(r={})
var b=[]
var S=!1
function x(e){var r=t.slice(a+e).match(n)
if(!r)throw new Error("Expected name, found "+t.slice(a))
var i=r[0]
a+=e+i.length
return h(i)}function k(e){for(;g(t.charAt(a+e));)e++
a+=e}function w(e){var r=0
for(;"\\"===t.charAt(--e);)r++
return 1==(1&r)}function C(){if(b.length>0&&u(b[b.length-1]))throw new Error("Did not expect successive traversals.")}k(0)
for(;""!==t;){var T=t.charAt(a)
if(g(T)){S=!0
k(1)}else if(T in s){C()
b.push({type:s[T]})
S=!1
k(1)}else if(","===T){if(0===b.length)throw new Error("Empty sub-selector")
e.push(b)
b=[]
S=!1
k(1)}else{if(S){C()
b.push({type:"descendant"})
S=!1}if(T in l){var A=l[T],E=A[0],O=A[1]
b.push({type:"attribute",name:E,action:O,value:x(1),ignoreCase:!1,namespace:null})}else if("["===T){var z=t.slice(a+1).match(i)
if(!z)throw new Error("Malformed attribute selector: "+t.slice(a))
var _=z[0],P=z[1],q=void 0===P?null:P,L=z[2],W=z[3],B=z[5],M=void 0===B?"":B,R=z[6],I=void 0===R?M:R,D=z[7]
a+=_.length+1
var N=h(L);(null!==(d=r.lowerCaseAttributeNames)&&void 0!==d?d:!r.xmlMode)&&(N=N.toLowerCase())
b.push({type:"attribute",name:N,action:o[W],value:h(I),namespace:q,ignoreCase:!!D})}else if(":"===T){if(":"===t.charAt(a+1)){b.push({type:"pseudo-element",name:x(2).toLowerCase()})
continue}var G=x(1).toLowerCase()
var F=null
if("("===t.charAt(a))if(c.has(G)){if(m.has(t.charAt(a+1)))throw new Error("Pseudo-selector "+G+" cannot be quoted")
a=v(F=[],t,r,a+1)
if(")"!==t.charAt(a))throw new Error("Missing closing parenthesis in :"+G+" ("+t+")")
a+=1}else{var V=a+=1
var j=1
for(;j>0&&a<t.length;a++)"("!==t.charAt(a)||w(a)?")"!==t.charAt(a)||w(a)||j--:j++
if(j)throw new Error("Parenthesis not matched")
F=t.slice(V,a-1)
if(p.has(G)){var U=F.charAt(0)
U===F.slice(-1)&&m.has(U)&&(F=F.slice(1,-1))
F=h(F)}}b.push({type:"pseudo",name:G,data:F})}else{q=null
var H=void 0
if("*"===T){a+=1
H="*"}else{if(!n.test(t.slice(a))){b.length&&"descendant"===b[b.length-1].type&&b.pop()
y(e,b)
return a}H=x(0)}if("|"===t.charAt(a)){q=H
if("*"===t.charAt(a+1)){H="*"
a+=2}else H=x(1)}if("*"===H)b.push({type:"universal",namespace:q})
else{(null!==(f=r.lowerCaseTags)&&void 0!==f?f:!r.xmlMode)&&(H=H.toLowerCase())
b.push({type:"tag",name:H,namespace:q})}}}}y(e,b)
return a}function y(e,t){if(e.length>0&&0===t.length)throw new Error("Empty sub-selector")
e.push(t)}},6566:function(e,t){"use strict"
var r=this&&this.__spreadArrays||function(){for(var e=0,t=0,r=arguments.length;t<r;t++)e+=arguments[t].length
var n=Array(e),a=0
for(t=0;t<r;t++)for(var i=arguments[t],o=0,s=i.length;o<s;o++,a++)n[a]=i[o]
return n}
Object.defineProperty(t,"__esModule",{value:!0})
var n={equals:"",element:"~",start:"^",end:"$",any:"*",not:"!",hyphen:"|"}
var a=new Set(r(Object.keys(n).map((function(e){return n[e]})).filter(Boolean),[":","[","]"," ","\\","(",")"]))
function i(e){return e.map(o).join(", ")}t.default=i
function o(e){return e.map(s).join("")}function s(e){switch(e.type){case"child":return" > "
case"parent":return" < "
case"sibling":return" ~ "
case"adjacent":return" + "
case"descendant":return" "
case"universal":return c(e.namespace)+"*"
case"tag":return l(e)
case"pseudo-element":return"::"+d(e.name)
case"pseudo":return null===e.data?":"+d(e.name):"string"==typeof e.data?":"+d(e.name)+"("+d(e.data)+")":":"+d(e.name)+"("+i(e.data)+")"
case"attribute":if("id"===e.name&&"equals"===e.action&&!e.ignoreCase&&!e.namespace)return"#"+d(e.value)
if("class"===e.name&&"element"===e.action&&!e.ignoreCase&&!e.namespace)return"."+d(e.value)
var t=l(e)
return"exists"===e.action?"["+t+"]":"["+t+n[e.action]+"='"+d(e.value)+"'"+(e.ignoreCase?"i":"")+"]"}}function l(e){return""+c(e.namespace)+d(e.name)}function c(e){return e?("*"===e?"*":d(e))+"|":""}function d(e){return e.split("").map((function(e){return a.has(e)?"\\"+e:e})).join("")}},48:(e,t,r)=>{var n=r(4662).keyword
var{hasNoChildren:a}=r(2017)
e.exports=function(e,t,r){if(e.block){null!==this.stylesheet&&(this.stylesheet.firstAtrulesAllowed=!1)
if(a(e.block)){r.remove(t)
return}}switch(e.name){case"charset":if(a(e.prelude)){r.remove(t)
return}if(t.prev){r.remove(t)
return}break
case"import":if(null===this.stylesheet||!this.stylesheet.firstAtrulesAllowed){r.remove(t)
return}r.prevUntil(t.prev,(function(e){if("Atrule"!==e.type||"import"!==e.name&&"charset"!==e.name){this.root.firstAtrulesAllowed=!1
r.remove(t)
return!0}}),this)
break
default:var i=n(e.name).basename
"keyframes"!==i&&"media"!==i&&"supports"!==i||(a(e.prelude)||a(e.block))&&r.remove(t)}}},2501:e=>{e.exports=function(e,t,r){r.remove(t)}},7300:(e,t,r)=>{var n=r(4662).property
e.exports=function(e,t,r){e.value.children&&e.value.children.isEmpty()?r.remove(t):n(e.property).custom&&/\S/.test(e.value.value)&&(e.value.value=e.value.value.trim())}},2136:(e,t,r)=>{var{isNodeChildrenList:n}=r(2017)
e.exports=function(e,t,r){(n(this.stylesheet,r)||n(this.block,r))&&r.remove(t)}},209:(e,t,r)=>{var n=Object.prototype.hasOwnProperty
var a=r(4662).walk
var{hasNoChildren:i}=r(2017)
function o(e,t){e.children.each((function(r,i,s){var l=!1
a(r,(function(r){if(null===this.selector||this.selector===e)switch(r.type){case"SelectorList":null!==this.function&&"not"===this.function.name.toLowerCase()||o(r,t)&&(l=!0)
break
case"ClassSelector":null===t.whitelist||null===t.whitelist.classes||n.call(t.whitelist.classes,r.name)||(l=!0)
null!==t.blacklist&&null!==t.blacklist.classes&&n.call(t.blacklist.classes,r.name)&&(l=!0)
break
case"IdSelector":null===t.whitelist||null===t.whitelist.ids||n.call(t.whitelist.ids,r.name)||(l=!0)
null!==t.blacklist&&null!==t.blacklist.ids&&n.call(t.blacklist.ids,r.name)&&(l=!0)
break
case"TypeSelector":if("*"!==r.name.charAt(r.name.length-1)){null===t.whitelist||null===t.whitelist.tags||n.call(t.whitelist.tags,r.name.toLowerCase())||(l=!0)
null!==t.blacklist&&null!==t.blacklist.tags&&n.call(t.blacklist.tags,r.name.toLowerCase())&&(l=!0)}}}))
l&&s.remove(i)}))
return e.children.isEmpty()}e.exports=function(e,t,r,n){if(i(e.prelude)||i(e.block))r.remove(t)
else{var a=n.usage
if(a&&(null!==a.whitelist||null!==a.blacklist)){o(e.prelude,a)
if(i(e.prelude)){r.remove(t)
return}}}}},9081:e=>{e.exports=function(e,t,r){if("*"===t.data.name){var n=t.next&&t.next.data.type
"IdSelector"!==n&&"ClassSelector"!==n&&"AttributeSelector"!==n&&"PseudoClassSelector"!==n&&"PseudoElementSelector"!==n||r.remove(t)}}},2268:(e,t,r)=>{var{isNodeChildrenList:n}=r(2017)
function a(e){return"Operator"===e.type&&"+"!==e.value&&"-"!==e.value}e.exports=function(e,t,r){null!==t.next&&null!==t.prev?n(this.stylesheet,r)||n(this.block,r)?r.remove(t):"WhiteSpace"!==t.next.data.type?(a(t.prev.data)||a(t.next.data))&&r.remove(t):r.remove(t):r.remove(t)}},4142:(e,t,r)=>{var n=r(4662).walk
var a={Atrule:r(48),Comment:r(2501),Declaration:r(7300),Raw:r(2136),Rule:r(209),TypeSelector:r(9081),WhiteSpace:r(2268)}
e.exports=function(e,t){n(e,{leave:function(e,r,n){a.hasOwnProperty(e.type)&&a[e.type].call(this,e,r,n,t)}})}},2017:e=>{e.exports={hasNoChildren:function(e){return!e||!e.children||e.children.isEmpty()},isNodeChildrenList:function(e,t){return null!==e&&e.children===t}}},3916:(e,t,r)=>{var n=r(4662).List
var a=r(4662).clone
var i=r(9334)
var o=r(4142)
var s=r(1513)
var l=r(9050)
var c=r(4662).walk
function d(e,t){var r=new n
var a=!1
var i
e.nextUntil(e.head,(function(e,n,o){if("Comment"!==e.type){"WhiteSpace"!==e.type&&(a=!0)
r.insert(o.remove(n))}else{if(!t||"!"!==e.value.charAt(0)){o.remove(n)
return}if(a||i)return!0
o.remove(n)
i=e}}))
return{comment:i,stylesheet:{type:"StyleSheet",loc:null,children:r}}}function u(e,t,r,n){n.logger("Compress block #"+r,null,!0)
var a=1
if("StyleSheet"===e.type){e.firstAtrulesAllowed=t
e.id=a++}c(e,{visit:"Atrule",enter:function(e){null!==e.block&&(e.block.id=a++)}})
n.logger("init",e)
o(e,n)
n.logger("clean",e)
s(e,n)
n.logger("replace",e)
n.restructuring&&l(e,n)
return e}function p(e){return"restructure"in e?e.restructure:!("restructuring"in e)||e.restructuring}e.exports=function(e,t){e=e||{type:"StyleSheet",loc:null,children:new n}
var r={logger:"function"==typeof(t=t||{}).logger?t.logger:function(){},restructuring:p(t),forceMediaMerge:Boolean(t.forceMediaMerge),usage:!!t.usage&&i.buildIndex(t.usage)}
var o=function(e){var t="comments"in e?e.comments:"exclamation"
"boolean"==typeof t?t=!!t&&"exclamation":"exclamation"!==t&&"first-exclamation"!==t&&(t=!1)
return t}(t)
var s=!0
var l
var c=new n
var m
var f=1
var h
t.clone&&(e=a(e))
if("StyleSheet"===e.type){l=e.children
e.children=c}else l=(g=e,(new n).appendData({type:"Rule",loc:null,prelude:{type:"SelectorList",loc:null,children:(new n).appendData({type:"Selector",loc:null,children:(new n).appendData({type:"TypeSelector",loc:null,name:"x"})})},block:g}))
var g
do{u((m=d(l,Boolean(o))).stylesheet,s,f++,r)
h=m.stylesheet.children
if(m.comment){c.isEmpty()||c.insert(n.createItem({type:"Raw",value:"\n"}))
c.insert(n.createItem(m.comment))
h.isEmpty()||c.insert(n.createItem({type:"Raw",value:"\n"}))}if(s&&!h.isEmpty()){var v=h.last();("Atrule"!==v.type||"import"!==v.name&&"charset"!==v.name)&&(s=!1)}"exclamation"!==o&&(o=!1)
c.appendList(h)}while(!l.isEmpty())
return{ast:e}}},4758:(e,t,r)=>{var n=r(4662)
var a=n.parse
var i=r(3916)
var o=n.generate
function s(e,t,r,n){t.debug&&console.error("## "+e+" done in %d ms\n",Date.now()-r)
return n}function l(e,t,r){Array.isArray(r)||(r=[r])
r.forEach((function(r){r(e,t)}))}function c(e,t,r){var n=(r=r||{}).filename||"<unknown>"
var c=s("parsing",r,Date.now(),a(t,{context:e,filename:n,positions:Boolean(r.sourceMap)}))
r.beforeCompress&&s("beforeCompress",r,Date.now(),l(c,r,r.beforeCompress))
var d=s("compress",r,Date.now(),i(c,function(e){"function"!=typeof(e=function(e){var t={}
for(var r in e)t[r]=e[r]
return t}(e)).logger&&e.debug&&(e.logger=(t=e.debug,function(e,n){var a=e
n&&(a="["+((Date.now()-r)/1e3).toFixed(3)+"s] "+a)
if(t>1&&n){var i=o(n)
2===t&&i.length>256&&(i=i.substr(0,256)+"...")
a+="\n  "+i+"\n"}console.error(a)
r=Date.now()}))
var t,r
return e}(r)))
r.afterCompress&&s("afterCompress",r,Date.now(),l(d,r,r.afterCompress))
return r.sourceMap?s("generate(sourceMap: true)",r,Date.now(),function(){var e=o(d.ast,{sourceMap:!0})
e.map._file=n
e.map.setSourceContent(n,t)
return e}()):s("generate",r,Date.now(),{css:o(d.ast),map:null})}e.exports={version:r(6012).i,minify:function(e,t){return c("stylesheet",e,t)},minifyBlock:function(e,t){return c("declarationList",e,t)},syntax:Object.assign({compress:i},n)}},8096:(e,t,r)=>{var n=r(4662).keyword
var a=r(2919)
e.exports=function(e){"keyframes"===n(e.name).basename&&a(e)}},1757:e=>{var t=/\\([0-9A-Fa-f]{1,6})(\r\n|[ \t\n\f\r])?|\\./g
var r=/^(-?\d|--)|[\u0000-\u002c\u002e\u002f\u003A-\u0040\u005B-\u005E\u0060\u007B-\u009f]/
e.exports=function(e){var n=e.value
if(n&&"String"===n.type){var a=n.value.replace(/^(.)(.*)\1$/,"$2");(function(e){if(""!==e&&"-"!==e){e=e.replace(t,"a")
return!r.test(e)}})(a)&&(e.value={type:"Identifier",loc:n.loc,name:a})}}},5399:(e,t,r)=>{var n=r(7782).pack
var a={calc:!0,min:!0,max:!0,clamp:!0}
var i={px:!0,mm:!0,cm:!0,in:!0,pt:!0,pc:!0,em:!0,ex:!0,ch:!0,rem:!0,vh:!0,vw:!0,vmin:!0,vmax:!0,vm:!0}
e.exports=function(e,t){var r=n(e.value,t)
e.value=r
if("0"===r&&null!==this.declaration&&null===this.atrulePrelude){var o=e.unit.toLowerCase()
if(!i.hasOwnProperty(o))return
if("-ms-flex"===this.declaration.property||"flex"===this.declaration.property)return
if(this.function&&a.hasOwnProperty(this.function.name))return
t.data={type:"Number",loc:e.loc,value:r}}}},7782:e=>{var t=/^(?:\+|(-))?0*(\d*)(?:\.0*|(\.\d*?)0*)?$/
var r=/^([\+\-])?0*(\d*)(?:\.0*|(\.\d*?)0*)?$/
var n={Dimension:!0,Hash:!0,Identifier:!0,Number:!0,Raw:!0,UnicodeRange:!0}
function a(e,a){var i=a&&null!==a.prev&&n.hasOwnProperty(a.prev.data.type)?r:t
""!==(e=String(e).replace(i,"$1$2$3"))&&"-"!==e||(e="0")
return e}e.exports=function(e,t){e.value=a(e.value,t)}
e.exports.pack=a},2686:(e,t,r)=>{var n=r(4662).lexer
var a=r(7782).pack
var i=new Set(["width","min-width","max-width","height","min-height","max-height","flex","-ms-flex"])
e.exports=function(e,t){e.value=a(e.value,t)
if("0"===e.value&&this.declaration&&!i.has(this.declaration.property)){t.data={type:"Number",loc:e.loc,value:e.value}
n.matchDeclaration(this.declaration).isType(t.data,"length")||(t.data=e)}}},3797:e=>{e.exports=function(e){var t=e.value
t=t.replace(/\\(\r\n|\r|\n|\f)/g,"")
e.value=t}},6051:e=>{var t=new RegExp("^((\\\\[0-9a-f]{1,6}(\\r\\n|[ \\n\\r\\t\\f])?|\\\\[^\\n\\r\\f0-9a-fA-F])|[^\"'\\(\\)\\\\\\s\0\b\v-])*$","i")
e.exports=function(e){var r=e.value
if("String"===r.type){var n=r.value[0]
var a=r.value.substr(1,r.value.length-2)
a=a.replace(/\\\\/g,"/")
t.test(a)?e.value={type:"Raw",loc:e.value.loc,value:a}:e.value.value=-1===a.indexOf('"')?'"'+a+'"':n+a+n}}},2449:(e,t,r)=>{var n=r(4662).property
var a={font:r(8461),"font-weight":r(8403),background:r(5117),border:r(1439),outline:r(1439)}
e.exports=function(e){if(this.declaration){var t=n(this.declaration.property)
a.hasOwnProperty(t.basename)&&a[t.basename](e)}}},2919:e=>{e.exports=function(e){e.block.children.each((function(e){e.prelude.children.each((function(e){e.children.each((function(e,t){"Percentage"===e.type&&"100"===e.value?t.data={type:"TypeSelector",loc:e.loc,name:"to"}:"TypeSelector"===e.type&&"from"===e.name&&(t.data={type:"Percentage",loc:e.loc,value:"0"})}))}))}))}},7520:(e,t,r)=>{var n=r(4662).lexer
var a=r(7782).pack
var i={aliceblue:"f0f8ff",antiquewhite:"faebd7",aqua:"0ff",aquamarine:"7fffd4",azure:"f0ffff",beige:"f5f5dc",bisque:"ffe4c4",black:"000",blanchedalmond:"ffebcd",blue:"00f",blueviolet:"8a2be2",brown:"a52a2a",burlywood:"deb887",cadetblue:"5f9ea0",chartreuse:"7fff00",chocolate:"d2691e",coral:"ff7f50",cornflowerblue:"6495ed",cornsilk:"fff8dc",crimson:"dc143c",cyan:"0ff",darkblue:"00008b",darkcyan:"008b8b",darkgoldenrod:"b8860b",darkgray:"a9a9a9",darkgrey:"a9a9a9",darkgreen:"006400",darkkhaki:"bdb76b",darkmagenta:"8b008b",darkolivegreen:"556b2f",darkorange:"ff8c00",darkorchid:"9932cc",darkred:"8b0000",darksalmon:"e9967a",darkseagreen:"8fbc8f",darkslateblue:"483d8b",darkslategray:"2f4f4f",darkslategrey:"2f4f4f",darkturquoise:"00ced1",darkviolet:"9400d3",deeppink:"ff1493",deepskyblue:"00bfff",dimgray:"696969",dimgrey:"696969",dodgerblue:"1e90ff",firebrick:"b22222",floralwhite:"fffaf0",forestgreen:"228b22",fuchsia:"f0f",gainsboro:"dcdcdc",ghostwhite:"f8f8ff",gold:"ffd700",goldenrod:"daa520",gray:"808080",grey:"808080",green:"008000",greenyellow:"adff2f",honeydew:"f0fff0",hotpink:"ff69b4",indianred:"cd5c5c",indigo:"4b0082",ivory:"fffff0",khaki:"f0e68c",lavender:"e6e6fa",lavenderblush:"fff0f5",lawngreen:"7cfc00",lemonchiffon:"fffacd",lightblue:"add8e6",lightcoral:"f08080",lightcyan:"e0ffff",lightgoldenrodyellow:"fafad2",lightgray:"d3d3d3",lightgrey:"d3d3d3",lightgreen:"90ee90",lightpink:"ffb6c1",lightsalmon:"ffa07a",lightseagreen:"20b2aa",lightskyblue:"87cefa",lightslategray:"789",lightslategrey:"789",lightsteelblue:"b0c4de",lightyellow:"ffffe0",lime:"0f0",limegreen:"32cd32",linen:"faf0e6",magenta:"f0f",maroon:"800000",mediumaquamarine:"66cdaa",mediumblue:"0000cd",mediumorchid:"ba55d3",mediumpurple:"9370db",mediumseagreen:"3cb371",mediumslateblue:"7b68ee",mediumspringgreen:"00fa9a",mediumturquoise:"48d1cc",mediumvioletred:"c71585",midnightblue:"191970",mintcream:"f5fffa",mistyrose:"ffe4e1",moccasin:"ffe4b5",navajowhite:"ffdead",navy:"000080",oldlace:"fdf5e6",olive:"808000",olivedrab:"6b8e23",orange:"ffa500",orangered:"ff4500",orchid:"da70d6",palegoldenrod:"eee8aa",palegreen:"98fb98",paleturquoise:"afeeee",palevioletred:"db7093",papayawhip:"ffefd5",peachpuff:"ffdab9",peru:"cd853f",pink:"ffc0cb",plum:"dda0dd",powderblue:"b0e0e6",purple:"800080",rebeccapurple:"639",red:"f00",rosybrown:"bc8f8f",royalblue:"4169e1",saddlebrown:"8b4513",salmon:"fa8072",sandybrown:"f4a460",seagreen:"2e8b57",seashell:"fff5ee",sienna:"a0522d",silver:"c0c0c0",skyblue:"87ceeb",slateblue:"6a5acd",slategray:"708090",slategrey:"708090",snow:"fffafa",springgreen:"00ff7f",steelblue:"4682b4",tan:"d2b48c",teal:"008080",thistle:"d8bfd8",tomato:"ff6347",turquoise:"40e0d0",violet:"ee82ee",wheat:"f5deb3",white:"fff",whitesmoke:"f5f5f5",yellow:"ff0",yellowgreen:"9acd32"}
var o={8e5:"maroon",800080:"purple",808e3:"olive",808080:"gray","00ffff":"cyan",f0ffff:"azure",f5f5dc:"beige",ffe4c4:"bisque","000000":"black","0000ff":"blue",a52a2a:"brown",ff7f50:"coral",ffd700:"gold","008000":"green","4b0082":"indigo",fffff0:"ivory",f0e68c:"khaki","00ff00":"lime",faf0e6:"linen","000080":"navy",ffa500:"orange",da70d6:"orchid",cd853f:"peru",ffc0cb:"pink",dda0dd:"plum",f00:"red",ff0000:"red",fa8072:"salmon",a0522d:"sienna",c0c0c0:"silver",fffafa:"snow",d2b48c:"tan","008080":"teal",ff6347:"tomato",ee82ee:"violet",f5deb3:"wheat",ffffff:"white",ffff00:"yellow"}
function s(e,t,r){r<0&&(r+=1)
r>1&&(r-=1)
return r<1/6?e+6*(t-e)*r:r<.5?t:r<2/3?e+(t-e)*(2/3-r)*6:e}function l(e,t,r,n){var a
var i
var o
if(0===t)a=i=o=r
else{var l=r<.5?r*(1+t):r+t-r*t
var c=2*r-l
a=s(c,l,e+1/3)
i=s(c,l,e)
o=s(c,l,e-1/3)}return[Math.round(255*a),Math.round(255*i),Math.round(255*o),n]}function c(e){return 1===(e=e.toString(16)).length?"0"+e:e}function d(e,t,r){var n=e.head
var a=[]
var i=!1
for(;null!==n;){var o=n.data
var s=o.type
switch(s){case"Number":case"Percentage":if(i)return
i=!0
a.push({type:s,value:Number(o.value)})
break
case"Operator":if(","===o.value){if(!i)return
i=!1}else if(i||"+"!==o.value)return
break
default:return}n=n.next}if(a.length===t){if(4===a.length){if("Number"!==a[3].type)return
a[3].type="Alpha"}if(r){if(a[0].type!==a[1].type||a[0].type!==a[2].type)return}else{if("Number"!==a[0].type||"Percentage"!==a[1].type||"Percentage"!==a[2].type)return
a[0].type="Angle"}return a.map((function(e){var t=Math.max(0,e.value)
switch(e.type){case"Number":t=Math.min(t,255)
break
case"Percentage":t=Math.min(t,100)/100
if(!r)return t
t*=255
break
case"Angle":return(t%360+360)%360/360
case"Alpha":return Math.min(t,1)}return Math.round(t)}))}}function u(e,t){var r=e.value.toLowerCase()
6===r.length&&r[0]===r[1]&&r[2]===r[3]&&r[4]===r[5]&&(r=r[0]+r[2]+r[4])
o[r]?t.data={type:"Identifier",loc:e.loc,name:o[r]}:e.value=r}e.exports={compressFunction:function(e,t,r){var n=e.name
var i
if("rgba"===n||"hsla"===n){if(!(i=d(e.children,4,"rgba"===n)))return
if("hsla"===n){i=l.apply(null,i)
e.name="rgba"}if(0===i[3]){var o=this.function&&this.function.name
if(0===i[0]&&0===i[1]&&0===i[2]||!/^(?:to|from|color-stop)$|gradient$/i.test(o)){t.data={type:"Identifier",loc:e.loc,name:"transparent"}
return}}if(1!==i[3]){e.children.each((function(e,t,r){"Operator"!==e.type?t.data={type:"Number",loc:e.loc,value:a(i.shift(),null)}:","!==e.value&&r.remove(t)}))
return}n="rgb"}if("hsl"===n){if(!(i=i||d(e.children,3,!1)))return
i=l.apply(null,i)
n="rgb"}if("rgb"===n){if(!(i=i||d(e.children,3,!0)))return
var s=t.next
s&&"WhiteSpace"!==s.data.type&&r.insert(r.createItem({type:"WhiteSpace",value:" "}),s)
t.data={type:"Hash",loc:e.loc,value:c(i[0])+c(i[1])+c(i[2])}
u(t.data,t)}},compressIdent:function(e,t){if(null!==this.declaration){var r=e.name.toLowerCase()
if(i.hasOwnProperty(r)&&n.matchDeclaration(this.declaration).isType(e,"color")){var a=i[r]
if(a.length+1<=r.length)t.data={type:"Hash",loc:e.loc,value:a}
else{"grey"===r&&(r="gray")
e.name=r}}}},compressHex:u}},1513:(e,t,r)=>{var n=r(4662).walk
var a={Atrule:r(8096),AttributeSelector:r(1757),Value:r(2449),Dimension:r(5399),Percentage:r(2686),Number:r(7782),String:r(3797),Url:r(6051),Hash:r(7520).compressHex,Identifier:r(7520).compressIdent,Function:r(7520).compressFunction}
e.exports=function(e){n(e,{leave:function(e,t,r){a.hasOwnProperty(e.type)&&a[e.type].call(this,e,t,r)}})}},5117:(e,t,r)=>{var n=r(4662).List
e.exports=function(e){function t(){if(i.length)return i[i.length-1].type}function r(){"WhiteSpace"===t()&&i.pop()
i.length||i.unshift({type:"Number",loc:null,value:"0"},{type:"WhiteSpace",value:" "},{type:"Number",loc:null,value:"0"})
a.push.apply(a,i)
i=[]}var a=[]
var i=[]
e.children.each((function(e){if("Operator"!==e.type||","!==e.value)("Identifier"!==e.type||"transparent"!==e.name&&"none"!==e.name&&"repeat"!==e.name&&"scroll"!==e.name)&&("WhiteSpace"!==e.type||i.length&&"WhiteSpace"!==t())&&i.push(e)
else{r()
a.push(e)}}))
r()
e.children=(new n).fromArray(a)}},1439:e=>{e.exports=function(e){e.children.each((function(e,t,r){"Identifier"===e.type&&"none"===e.name.toLowerCase()&&(r.head===r.tail?t.data={type:"Number",loc:e.loc,value:"0"}:function(e,t){var r=t.prev
var n=t.next
null!==n?"WhiteSpace"!==n.data.type||null!==r&&"WhiteSpace"!==r.data.type||e.remove(n):null!==r&&"WhiteSpace"===r.data.type&&e.remove(r)
e.remove(t)}(r,t))}))}},8403:e=>{e.exports=function(e){var t=e.children.head.data
if("Identifier"===t.type)switch(t.name){case"normal":e.children.head.data={type:"Number",loc:t.loc,value:"400"}
break
case"bold":e.children.head.data={type:"Number",loc:t.loc,value:"700"}}}},8461:e=>{e.exports=function(e){var t=e.children
t.eachRight((function(e,t){if("Identifier"===e.type)if("bold"===e.name)t.data={type:"Number",loc:e.loc,value:"700"}
else if("normal"===e.name){var r=t.prev
r&&"Operator"===r.data.type&&"/"===r.data.value&&this.remove(r)
this.remove(t)}else if("medium"===e.name){var n=t.next
n&&"Operator"===n.data.type||this.remove(t)}}))
t.each((function(e,t){"WhiteSpace"===e.type&&(t.prev&&t.next&&"WhiteSpace"!==t.next.data.type||this.remove(t))}))
t.isEmpty()&&t.insert(t.createItem({type:"Identifier",name:"normal"}))}},3402:(e,t,r)=>{var n=r(4662).List
var a=r(4662).keyword
var i=Object.prototype.hasOwnProperty
var o=r(4662).walk
function s(e,t,r,o){var s=t.data
var l=a(s.name).basename
var c=s.name.toLowerCase()+"/"+(s.prelude?s.prelude.id:null)
i.call(e,l)||(e[l]=Object.create(null))
o&&delete e[l][c]
i.call(e[l],c)||(e[l][c]=new n)
e[l][c].append(r.remove(t))}function l(e){return"Atrule"===e.type&&"media"===e.name}function c(e,t,r){if(l(e)){var n=t.prev&&t.prev.data
if(n&&l(n)&&e.prelude&&n.prelude&&e.prelude.id===n.prelude.id){n.block.children.appendList(e.block.children)
r.remove(t)}}}e.exports=function(e,t){!function(e,t){var r=Object.create(null)
var n=null
e.children.each((function(e,i,o){if("Atrule"===e.type){var l=a(e.name).basename
switch(l){case"keyframes":s(r,i,o,!0)
return
case"media":if(t.forceMediaMerge){s(r,i,o,!1)
return}}null===n&&"charset"!==l&&"import"!==l&&(n=i)}else null===n&&(n=i)}))
for(var i in r)for(var o in r[i])e.children.insertList(r[i][o],"media"===i?null:n)}(e,t)
o(e,{visit:"Atrule",reverse:!0,enter:c})}},187:(e,t,r)=>{var n=r(4662).walk
var a=r(7932)
function i(e,t,r){var n=e.prelude.children
var i=e.block.children
r.prevUntil(t.prev,(function(o){if("Rule"!==o.type)return a.unsafeToSkipNode.call(n,o)
var s=o.prelude.children
var l=o.block.children
if(e.pseudoSignature===o.pseudoSignature){if(a.isEqualSelectors(s,n)){l.appendList(i)
r.remove(t)
return!0}if(a.isEqualDeclarations(i,l)){a.addSelectors(s,n)
r.remove(t)
return!0}}return a.hasSimilarSelectors(n,s)}))}e.exports=function(e){n(e,{visit:"Rule",enter:i})}},7604:(e,t,r)=>{var n=r(4662).List
var a=r(4662).walk
function i(e,t,r){var a=e.prelude.children
for(;a.head!==a.tail;){var i=new n
i.insert(a.remove(a.head))
r.insert(r.createItem({type:"Rule",loc:e.loc,prelude:{type:"SelectorList",loc:e.prelude.loc,children:i},block:{type:"Block",loc:e.block.loc,children:e.block.children.copy()},pseudoSignature:e.pseudoSignature}),t)}}e.exports=function(e){a(e,{visit:"Rule",reverse:!0,enter:i})}},7880:(e,t,r)=>{var n=r(4662).List
var a=r(4662).generate
var i=r(4662).walk
var o=["top","right","bottom","left"]
var s={"margin-top":"top","margin-right":"right","margin-bottom":"bottom","margin-left":"left","padding-top":"top","padding-right":"right","padding-bottom":"bottom","padding-left":"left","border-top-color":"top","border-right-color":"right","border-bottom-color":"bottom","border-left-color":"left","border-top-width":"top","border-right-width":"right","border-bottom-width":"bottom","border-left-width":"left","border-top-style":"top","border-right-style":"right","border-bottom-style":"bottom","border-left-style":"left"}
var l={margin:"margin","margin-top":"margin","margin-right":"margin","margin-bottom":"margin","margin-left":"margin",padding:"padding","padding-top":"padding","padding-right":"padding","padding-bottom":"padding","padding-left":"padding","border-color":"border-color","border-top-color":"border-color","border-right-color":"border-color","border-bottom-color":"border-color","border-left-color":"border-color","border-width":"border-width","border-top-width":"border-width","border-right-width":"border-width","border-bottom-width":"border-width","border-left-width":"border-width","border-style":"border-style","border-top-style":"border-style","border-right-style":"border-style","border-bottom-style":"border-style","border-left-style":"border-style"}
function c(e){this.name=e
this.loc=null
this.iehack=void 0
this.sides={top:null,right:null,bottom:null,left:null}}c.prototype.getValueSequence=function(e,t){var r=[]
var n=""
if("Value"!==e.value.type||e.value.children.some((function(t){var a=!1
switch(t.type){case"Identifier":switch(t.name){case"\\0":case"\\9":n=t.name
return
case"inherit":case"initial":case"unset":case"revert":a=t.name}break
case"Dimension":switch(t.unit){case"rem":case"vw":case"vh":case"vmin":case"vmax":case"vm":a=t.unit}break
case"Hash":case"Number":case"Percentage":break
case"Function":if("var"===t.name)return!0
a=t.name
break
case"WhiteSpace":return!1
default:return!0}r.push({node:t,special:a,important:e.important})}))||r.length>t)return!1
if("string"==typeof this.iehack&&this.iehack!==n)return!1
this.iehack=n
return r}
c.prototype.canOverride=function(e,t){var r=this.sides[e]
return!r||t.important&&!r.important}
c.prototype.add=function(e,t){if(!function(){var r=this.sides
var n=s[e]
if(n){if(n in r==0)return!1
if(!(i=this.getValueSequence(t,1))||!i.length)return!1
for(var a in r)if(null!==r[a]&&r[a].special!==i[0].special)return!1
if(!this.canOverride(n,i[0]))return!0
r[n]=i[0]
return!0}if(e===this.name){var i
if(!(i=this.getValueSequence(t,4))||!i.length)return!1
switch(i.length){case 1:i[1]=i[0]
i[2]=i[0]
i[3]=i[0]
break
case 2:i[2]=i[0]
i[3]=i[1]
break
case 3:i[3]=i[1]}for(var l=0;l<4;l++)for(var a in r)if(null!==r[a]&&r[a].special!==i[l].special)return!1
for(l=0;l<4;l++)this.canOverride(o[l],i[l])&&(r[o[l]]=i[l])
return!0}}.call(this))return!1
this.loc||(this.loc=t.loc)
return!0}
c.prototype.isOkToMinimize=function(){var e=this.sides.top
var t=this.sides.right
var r=this.sides.bottom
var n=this.sides.left
if(e&&t&&r&&n){var a=e.important+t.important+r.important+n.important
return 0===a||4===a}return!1}
c.prototype.getValue=function(){var e=new n
var t=this.sides
var r=[t.top,t.right,t.bottom,t.left]
var i=[a(t.top.node),a(t.right.node),a(t.bottom.node),a(t.left.node)]
if(i[3]===i[1]){r.pop()
if(i[2]===i[0]){r.pop()
i[1]===i[0]&&r.pop()}}for(var o=0;o<r.length;o++){o&&e.appendData({type:"WhiteSpace",value:" "})
e.appendData(r[o].node)}if(this.iehack){e.appendData({type:"WhiteSpace",value:" "})
e.appendData({type:"Identifier",loc:null,name:this.iehack})}return{type:"Value",loc:null,children:e}}
c.prototype.getDeclaration=function(){return{type:"Declaration",loc:this.loc,important:this.sides.top.important,property:this.name,value:this.getValue()}}
function d(e,t,r,n){var a=e.block.children
var i=e.prelude.children.first().id
e.block.children.eachRight((function(e,o){var s=e.property
if(l.hasOwnProperty(s)){var d=l[s]
var u
var p
if((!n||i===n)&&d in t){p=2
u=t[d]}if(!u||!u.add(s,e)){p=1
if(!(u=new c(d)).add(s,e)){n=null
return}}t[d]=u
r.push({operation:p,block:a,item:o,shorthand:u})
n=i}}))
return n}e.exports=function(e,t){var r={}
var n=[]
i(e,{visit:"Rule",reverse:!0,enter:function(e){var t=this.block||this.stylesheet
var a=(e.pseudoSignature||"")+"|"+e.prelude.children.first().id
var i
var o
if(r.hasOwnProperty(t.id))i=r[t.id]
else{i={lastShortSelector:null}
r[t.id]=i}if(i.hasOwnProperty(a))o=i[a]
else{o={}
i[a]=o}i.lastShortSelector=d.call(this,e,o,n,i.lastShortSelector)}})
!function(e,t){e.forEach((function(e){var r=e.shorthand
r.isOkToMinimize()&&(1===e.operation?e.item.data=t(r.getDeclaration()):e.block.remove(e.item))}))}(n,t.declaration)}},2920:(e,t,r)=>{var n=r(4662).property
var a=r(4662).keyword
var i=r(4662).walk
var o=r(4662).generate
var s=1
var l={src:1}
var c={display:/table|ruby|flex|-(flex)?box$|grid|contents|run-in/i,"text-align":/^(start|end|match-parent|justify-all)$/i}
var d={cursor:["auto","crosshair","default","move","text","wait","help","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","pointer","progress","not-allowed","no-drop","vertical-text","all-scroll","col-resize","row-resize"],overflow:["hidden","visible","scroll","auto"],position:["static","relative","absolute","fixed"]}
var u={"border-width":["border"],"border-style":["border"],"border-color":["border"],"border-top":["border"],"border-right":["border"],"border-bottom":["border"],"border-left":["border"],"border-top-width":["border-top","border-width","border"],"border-right-width":["border-right","border-width","border"],"border-bottom-width":["border-bottom","border-width","border"],"border-left-width":["border-left","border-width","border"],"border-top-style":["border-top","border-style","border"],"border-right-style":["border-right","border-style","border"],"border-bottom-style":["border-bottom","border-style","border"],"border-left-style":["border-left","border-style","border"],"border-top-color":["border-top","border-color","border"],"border-right-color":["border-right","border-color","border"],"border-bottom-color":["border-bottom","border-color","border"],"border-left-color":["border-left","border-color","border"],"margin-top":["margin"],"margin-right":["margin"],"margin-bottom":["margin"],"margin-left":["margin"],"padding-top":["padding"],"padding-right":["padding"],"padding-bottom":["padding"],"padding-left":["padding"],"font-style":["font"],"font-variant":["font"],"font-weight":["font"],"font-size":["font"],"font-family":["font"],"list-style-type":["list-style"],"list-style-position":["list-style"],"list-style-image":["list-style"]}
function p(e,t,r){var i=n(e).basename
if("background"===i)return e+":"+o(t.value)
var l=t.id
var u=r[l]
if(!u){switch(t.value.type){case"Value":var p=""
var m=""
var f={}
var h=!1
t.value.children.each((function e(t){switch(t.type){case"Value":case"Brackets":case"Parentheses":t.children.each(e)
break
case"Raw":h=!0
break
case"Identifier":var r=t.name
p||(p=a(r).vendor);/\\[09]/.test(r)&&(m=RegExp.lastMatch)
d.hasOwnProperty(i)?-1===d[i].indexOf(r)&&(f[r]=!0):c.hasOwnProperty(i)&&c[i].test(r)&&(f[r]=!0)
break
case"Function":r=t.name
p||(p=a(r).vendor)
"rect"===r&&(t.children.some((function(e){return"Operator"===e.type&&","===e.value}))||(r="rect-backward"))
f[r+"()"]=!0
t.children.each(e)
break
case"Dimension":var n=t.unit;/\\[09]/.test(n)&&(m=RegExp.lastMatch)
switch(n){case"rem":case"vw":case"vh":case"vmin":case"vmax":case"vm":f[n]=!0}}}))
u=h?"!"+s++:"!"+Object.keys(f).sort()+"|"+m+p
break
case"Raw":u="!"+t.value.value
break
default:u=o(t.value)}r[l]=u}return e+u}function m(e,t,r,a,i){var o=e.block.children
o.eachRight((function(e,t){var r=e.property
var s=p(r,e,i)
if((c=a[s])&&!l.hasOwnProperty(r))if(e.important&&!c.item.data.important){a[s]={block:o,item:t}
c.block.remove(c.item)}else o.remove(t)
else{var c
if(c=function(e,t,r){var a=n(t.property)
if(u.hasOwnProperty(a.basename)){var i=u[a.basename]
for(var o=0;o<i.length;o++){var s=p(a.prefix+i[o],t,r)
var l=e.hasOwnProperty(s)?e[s]:null
if(l&&(!t.important||l.item.data.important))return l}}}(a,e,i))o.remove(t)
else{e.fingerprint=s
a[s]={block:o,item:t}}}}))
o.isEmpty()&&r.remove(t)}e.exports=function(e){var t={}
var r=Object.create(null)
i(e,{visit:"Rule",reverse:!0,enter:function(e,n,a){var i=this.block||this.stylesheet
var o=(e.pseudoSignature||"")+"|"+e.prelude.children.first().id
var s
var l
if(t.hasOwnProperty(i.id))s=t[i.id]
else{s={}
t[i.id]=s}if(s.hasOwnProperty(o))l=s[o]
else{l={}
s[o]=l}m.call(this,e,n,a,l,r)}})}},9072:(e,t,r)=>{var n=r(4662).walk
var a=r(7932)
function i(e,t,r){var n=e.prelude.children
var i=e.block.children
var o=n.first().compareMarker
var s={}
r.nextUntil(t.next,(function(t,l){if("Rule"!==t.type)return a.unsafeToSkipNode.call(n,t)
if(e.pseudoSignature!==t.pseudoSignature)return!0
var c=t.prelude.children.head
var d=t.block.children
var u=c.data.compareMarker
if(u in s)return!0
if(n.head!==n.tail||n.first().id!==c.data.id)if(a.isEqualDeclarations(i,d)){var p=c.data.id
n.some((function(e,t){var r=e.id
if(p<r){n.insert(c,t)
return!0}if(!t.next){n.insert(c)
return!0}}))
r.remove(l)}else{if(u===o)return!0
s[u]=!0}else{i.appendList(d)
r.remove(l)}}))}e.exports=function(e){n(e,{visit:"Rule",enter:i})}},8268:(e,t,r)=>{var n=r(4662).List
var a=r(4662).walk
var i=r(7932)
function o(e){var t=0
e.each((function(e){t+=e.id.length+1}))
return t-1}function s(e){var t=0
for(var r=0;r<e.length;r++)t+=e[r].length
return t+e.length-1}function l(e,t,r){var l=null!==this.block&&this.block.avoidRulesMerge
var c=e.prelude.children
var d=e.block
var u=Object.create(null)
var p=!0
var m=!0
r.prevUntil(t.prev,(function(f,h){var g=f.block
var v=f.type
if("Rule"!==v){var y=i.unsafeToSkipNode.call(c,f)
!y&&"Atrule"===v&&g&&a(g,{visit:"Rule",enter:function(e){e.prelude.children.each((function(e){u[e.compareMarker]=!0}))}})
return y}var b=f.prelude.children
if(e.pseudoSignature!==f.pseudoSignature)return!0
if(!(m=!b.some((function(e){return e.compareMarker in u})))&&!p)return!0
if(p&&i.isEqualSelectors(b,c)){g.children.appendList(d.children)
r.remove(t)
return!0}var S=i.compareDeclarations(d.children,g.children)
if(S.eq.length){if(!S.ne1.length&&!S.ne2.length){if(m){i.addSelectors(c,b)
r.remove(h)}return!0}if(!l)if(S.ne1.length&&!S.ne2.length){var x=o(c)
var k=s(S.eq)
if(p&&x<k){i.addSelectors(b,c)
d.children=(new n).fromArray(S.ne1)}}else if(!S.ne1.length&&S.ne2.length){x=o(b)
k=s(S.eq)
if(m&&x<k){i.addSelectors(c,b)
g.children=(new n).fromArray(S.ne2)}}else{var w={type:"SelectorList",loc:null,children:i.addSelectors(b.copy(),c)}
var C=o(w.children)+2
if((k=s(S.eq))>=C){var T=r.createItem({type:"Rule",loc:null,prelude:w,block:{type:"Block",loc:null,children:(new n).fromArray(S.eq)},pseudoSignature:e.pseudoSignature})
d.children=(new n).fromArray(S.ne1)
g.children=(new n).fromArray(S.ne2overrided)
p?r.insert(T,h):r.insert(T,t)
return!0}}}p&&(p=!b.some((function(e){return c.some((function(t){return t.compareMarker===e.compareMarker}))})))
b.each((function(e){u[e.compareMarker]=!0}))}))}e.exports=function(e){a(e,{visit:"Rule",reverse:!0,enter:l})}},9050:(e,t,r)=>{var n=r(5045)
var a=r(3402)
var i=r(187)
var o=r(7604)
var s=r(7880)
var l=r(2920)
var c=r(9072)
var d=r(8268)
e.exports=function(e,t){var r=n(e,t)
t.logger("prepare",e)
a(e,t)
t.logger("mergeAtrule",e)
i(e)
t.logger("initialMergeRuleset",e)
o(e)
t.logger("disjoinRuleset",e)
s(e,r)
t.logger("restructShorthand",e)
l(e)
t.logger("restructBlock",e)
c(e)
t.logger("mergeRuleset",e)
d(e)
t.logger("restructRuleset",e)}},2335:(e,t,r)=>{var n=r(4662).generate
function a(){this.seed=0
this.map=Object.create(null)}a.prototype.resolve=function(e){var t=this.map[e]
if(!t){t=++this.seed
this.map[e]=t}return t}
e.exports=function(){var e=new a
return function(t){var r=n(t)
t.id=e.resolve(r)
t.length=r.length
t.fingerprint=null
return t}}},5045:(e,t,r)=>{var n=r(4662).keyword
var a=r(4662).walk
var i=r(4662).generate
var o=r(2335)
var s=r(2080)
e.exports=function(e,t){var r=o()
a(e,{visit:"Rule",enter:function(e){e.block.children.each(r)
s(e,t.usage)}})
a(e,{visit:"Atrule",enter:function(e){if(e.prelude){e.prelude.id=null
e.prelude.id=i(e.prelude)}if("keyframes"===n(e.name).basename){e.block.avoidRulesMerge=!0
e.block.children.each((function(e){e.prelude.children.each((function(e){e.compareMarker=e.id}))}))}}})
return{declaration:r}}},2080:(e,t,r)=>{var n=r(4662).generate
var a=r(2454)
var i={"first-letter":!0,"first-line":!0,after:!0,before:!0}
var o={link:!0,visited:!0,hover:!0,active:!0,"first-letter":!0,"first-line":!0,after:!0,before:!0}
e.exports=function(e,t){var r=Object.create(null)
var s=!1
e.prelude.children.each((function(e){var l="*"
var c=0
e.children.each((function(a){switch(a.type){case"ClassSelector":if(t&&t.scopes){var d=t.scopes[a.name]||0
if(0!==c&&d!==c)throw new Error("Selector can't has classes from different scopes: "+n(e))
c=d}break
case"PseudoClassSelector":var u=a.name.toLowerCase()
if(!o.hasOwnProperty(u)){r[":"+u]=!0
s=!0}break
case"PseudoElementSelector":u=a.name.toLowerCase()
if(!i.hasOwnProperty(u)){r["::"+u]=!0
s=!0}break
case"TypeSelector":l=a.name.toLowerCase()
break
case"AttributeSelector":if(a.flags){r["["+a.flags.toLowerCase()+"]"]=!0
s=!0}break
case"WhiteSpace":case"Combinator":l="*"}}))
e.compareMarker=a(e).toString()
e.id=null
e.id=n(e)
c&&(e.compareMarker+=":"+c)
"*"!==l&&(e.compareMarker+=","+l)}))
e.pseudoSignature=s&&Object.keys(r).sort().join(",")}},2454:e=>{e.exports=function(e){var t=0
var r=0
var n=0
e.children.each((function e(a){switch(a.type){case"SelectorList":case"Selector":a.children.each(e)
break
case"IdSelector":t++
break
case"ClassSelector":case"AttributeSelector":r++
break
case"PseudoClassSelector":switch(a.name.toLowerCase()){case"not":a.children.each(e)
break
case"before":case"after":case"first-line":case"first-letter":n++
break
default:r++}break
case"PseudoElementSelector":n++
break
case"TypeSelector":"*"!==a.name.charAt(a.name.length-1)&&n++}}))
return[t,r,n]}},7932:e=>{var t=Object.prototype.hasOwnProperty
function r(e,t){var r=e.head
for(;null!==r;){var n=t.head
for(;null!==n;){if(r.data.compareMarker===n.data.compareMarker)return!0
n=n.next}r=r.next}return!1}e.exports={isEqualSelectors:function(e,t){var r=e.head
var n=t.head
for(;null!==r&&null!==n&&r.data.id===n.data.id;){r=r.next
n=n.next}return null===r&&null===n},isEqualDeclarations:function(e,t){var r=e.head
var n=t.head
for(;null!==r&&null!==n&&r.data.id===n.data.id;){r=r.next
n=n.next}return null===r&&null===n},compareDeclarations:function(e,r){var n={eq:[],ne1:[],ne2:[],ne2overrided:[]}
var a=Object.create(null)
var i=Object.create(null)
for(var o=r.head;o;o=o.next)i[o.data.id]=!0
for(o=e.head;o;o=o.next){(s=o.data).fingerprint&&(a[s.fingerprint]=s.important)
if(i[s.id]){i[s.id]=!1
n.eq.push(s)}else n.ne1.push(s)}for(o=r.head;o;o=o.next){var s
if(i[(s=o.data).id]){(!t.call(a,s.fingerprint)||!a[s.fingerprint]&&s.important)&&n.ne2.push(s)
n.ne2overrided.push(s)}}return n},addSelectors:function(e,t){t.each((function(t){var r=t.id
var n=e.head
for(;n;){var a=n.data.id
if(a===r)return
if(a>r)break
n=n.next}e.insert(e.createItem(t),n)}))
return e},hasSimilarSelectors:r,unsafeToSkipNode:function e(t){switch(t.type){case"Rule":return r(t.prelude.children,this)
case"Atrule":if(t.block)return t.block.children.some(e,this)
break
case"Declaration":return!1}return!0}}},9334:e=>{var t=Object.prototype.hasOwnProperty
function r(e,t){var r=Object.create(null)
if(!Array.isArray(e))return null
for(var n=0;n<e.length;n++){var a=e[n]
t&&(a=a.toLowerCase())
r[a]=!0}return r}function n(e){if(!e)return null
var t=r(e.tags,!0)
var n=r(e.ids)
var a=r(e.classes)
return null===t&&null===n&&null===a?null:{tags:t,ids:n,classes:a}}e.exports={buildIndex:function(e){var r=!1
if(e.scopes&&Array.isArray(e.scopes)){r=Object.create(null)
for(var a=0;a<e.scopes.length;a++){var i=e.scopes[a]
if(!i||!Array.isArray(i))throw new Error("Wrong usage format")
for(var o=0;o<i.length;o++){var s=i[o]
if(t.call(r,s))throw new Error("Class can't be used for several scopes: "+s)
r[s]=a+1}}}return{whitelist:n(e),blacklist:n(e.blacklist),scopes:r}}}},3117:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.attributeNames=t.elementNames=void 0
t.elementNames=new Map([["altglyph","altGlyph"],["altglyphdef","altGlyphDef"],["altglyphitem","altGlyphItem"],["animatecolor","animateColor"],["animatemotion","animateMotion"],["animatetransform","animateTransform"],["clippath","clipPath"],["feblend","feBlend"],["fecolormatrix","feColorMatrix"],["fecomponenttransfer","feComponentTransfer"],["fecomposite","feComposite"],["feconvolvematrix","feConvolveMatrix"],["fediffuselighting","feDiffuseLighting"],["fedisplacementmap","feDisplacementMap"],["fedistantlight","feDistantLight"],["fedropshadow","feDropShadow"],["feflood","feFlood"],["fefunca","feFuncA"],["fefuncb","feFuncB"],["fefuncg","feFuncG"],["fefuncr","feFuncR"],["fegaussianblur","feGaussianBlur"],["feimage","feImage"],["femerge","feMerge"],["femergenode","feMergeNode"],["femorphology","feMorphology"],["feoffset","feOffset"],["fepointlight","fePointLight"],["fespecularlighting","feSpecularLighting"],["fespotlight","feSpotLight"],["fetile","feTile"],["feturbulence","feTurbulence"],["foreignobject","foreignObject"],["glyphref","glyphRef"],["lineargradient","linearGradient"],["radialgradient","radialGradient"],["textpath","textPath"]])
t.attributeNames=new Map([["definitionurl","definitionURL"],["attributename","attributeName"],["attributetype","attributeType"],["basefrequency","baseFrequency"],["baseprofile","baseProfile"],["calcmode","calcMode"],["clippathunits","clipPathUnits"],["diffuseconstant","diffuseConstant"],["edgemode","edgeMode"],["filterunits","filterUnits"],["glyphref","glyphRef"],["gradienttransform","gradientTransform"],["gradientunits","gradientUnits"],["kernelmatrix","kernelMatrix"],["kernelunitlength","kernelUnitLength"],["keypoints","keyPoints"],["keysplines","keySplines"],["keytimes","keyTimes"],["lengthadjust","lengthAdjust"],["limitingconeangle","limitingConeAngle"],["markerheight","markerHeight"],["markerunits","markerUnits"],["markerwidth","markerWidth"],["maskcontentunits","maskContentUnits"],["maskunits","maskUnits"],["numoctaves","numOctaves"],["pathlength","pathLength"],["patterncontentunits","patternContentUnits"],["patterntransform","patternTransform"],["patternunits","patternUnits"],["pointsatx","pointsAtX"],["pointsaty","pointsAtY"],["pointsatz","pointsAtZ"],["preservealpha","preserveAlpha"],["preserveaspectratio","preserveAspectRatio"],["primitiveunits","primitiveUnits"],["refx","refX"],["refy","refY"],["repeatcount","repeatCount"],["repeatdur","repeatDur"],["requiredextensions","requiredExtensions"],["requiredfeatures","requiredFeatures"],["specularconstant","specularConstant"],["specularexponent","specularExponent"],["spreadmethod","spreadMethod"],["startoffset","startOffset"],["stddeviation","stdDeviation"],["stitchtiles","stitchTiles"],["surfacescale","surfaceScale"],["systemlanguage","systemLanguage"],["tablevalues","tableValues"],["targetx","targetX"],["targety","targetY"],["textlength","textLength"],["viewbox","viewBox"],["viewtarget","viewTarget"],["xchannelselector","xChannelSelector"],["ychannelselector","yChannelSelector"],["zoomandpan","zoomAndPan"]])},1671:function(e,t,r){"use strict"
var n=this&&this.__assign||function(){return(n=Object.assign||function(e){for(var t,r=1,n=arguments.length;r<n;r++){t=arguments[r]
for(var a in t)Object.prototype.hasOwnProperty.call(t,a)&&(e[a]=t[a])}return e}).apply(this,arguments)}
var a=this&&this.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r)
Object.defineProperty(e,n,{enumerable:!0,get:function(){return t[r]}})}:function(e,t,r,n){void 0===n&&(n=r)
e[n]=t[r]})
var i=this&&this.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t})
var o=this&&this.__importStar||function(e){if(e&&e.__esModule)return e
var t={}
if(null!=e)for(var r in e)"default"!==r&&Object.prototype.hasOwnProperty.call(e,r)&&a(t,e,r)
i(t,e)
return t}
Object.defineProperty(t,"__esModule",{value:!0})
var s=o(r(7304))
var l=r(7531)
var c=r(3117)
var d=new Set(["style","script","xmp","iframe","noembed","noframes","plaintext","noscript"])
var u=new Set(["area","base","basefont","br","col","command","embed","frame","hr","img","input","isindex","keygen","link","meta","param","source","track","wbr"])
function p(e,t){void 0===t&&(t={})
var r=Array.isArray(e)||e.cheerio?e:[e]
var n=""
for(var a=0;a<r.length;a++)n+=m(r[a],t)
return n}t.default=p
function m(e,t){switch(e.type){case s.Root:return p(e.children,t)
case s.Directive:case s.Doctype:return"<"+e.data+">"
case s.Comment:return function(e){return"\x3c!--"+e.data+"--\x3e"}(e)
case s.CDATA:return function(e){return"<![CDATA["+e.children[0].data+"]]>"}(e)
case s.Script:case s.Style:case s.Tag:return function(e,t){var r
if("foreign"===t.xmlMode){e.name=null!==(r=c.elementNames.get(e.name))&&void 0!==r?r:e.name
e.parent&&f.has(e.parent.name)&&(t=n(n({},t),{xmlMode:!1}))}!t.xmlMode&&h.has(e.name)&&(t=n(n({},t),{xmlMode:"foreign"}))
var a="<"+e.name
var i=function(e,t){if(e)return Object.keys(e).map((function(r){var n,a
var i=null!==(n=e[r])&&void 0!==n?n:""
"foreign"===t.xmlMode&&(r=null!==(a=c.attributeNames.get(r))&&void 0!==a?a:r)
return t.emptyAttrs||t.xmlMode||""!==i?r+'="'+(t.decodeEntities?l.encodeXML(i):i.replace(/"/g,"&quot;"))+'"':r})).join(" ")}(e.attribs,t)
i&&(a+=" "+i)
if(0===e.children.length&&(t.xmlMode?!1!==t.selfClosingTags:t.selfClosingTags&&u.has(e.name))){t.xmlMode||(a+=" ")
a+="/>"}else{a+=">"
e.children.length>0&&(a+=p(e.children,t))
!t.xmlMode&&u.has(e.name)||(a+="</"+e.name+">")}return a}(e,t)
case s.Text:return function(e,t){var r=e.data||""
!t.decodeEntities||e.parent&&d.has(e.parent.name)||(r=l.encodeXML(r))
return r}(e,t)}}var f=new Set(["mi","mo","mn","ms","mtext","annotation-xml","foreignObject","desc","title"])
var h=new Set(["svg","math"])},7304:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.Doctype=t.CDATA=t.Tag=t.Style=t.Script=t.Comment=t.Directive=t.Text=t.Root=t.isTag=void 0
t.isTag=function(e){return"tag"===e.type||"script"===e.type||"style"===e.type}
t.Root="root"
t.Text="text"
t.Directive="directive"
t.Comment="comment"
t.Script="script"
t.Style="style"
t.Tag="tag"
t.CDATA="cdata"
t.Doctype="doctype"},3757:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.uniqueSort=t.compareDocumentPosition=t.removeSubsets=void 0
var n=r(4701)
t.removeSubsets=function(e){var t=e.length
for(;--t>=0;){var r=e[t]
if(t>0&&e.lastIndexOf(r,t-1)>=0)e.splice(t,1)
else for(var n=r.parent;n;n=n.parent)if(e.includes(n)){e.splice(t,1)
break}}return e}
function a(e,t){var r=[]
var a=[]
if(e===t)return 0
var i=n.hasChildren(e)?e:e.parent
for(;i;){r.unshift(i)
i=i.parent}i=n.hasChildren(t)?t:t.parent
for(;i;){a.unshift(i)
i=i.parent}var o=Math.min(r.length,a.length)
var s=0
for(;s<o&&r[s]===a[s];)s++
if(0===s)return 1
var l=r[s-1]
var c=l.children
var d=r[s]
var u=a[s]
return c.indexOf(d)>c.indexOf(u)?l===t?20:4:l===e?10:2}t.compareDocumentPosition=a
t.uniqueSort=function(e){(e=e.filter((function(e,t,r){return!r.includes(e,t+1)}))).sort((function(e,t){var r=a(e,t)
return 2&r?-1:4&r?1:0}))
return e}},5511:function(e,t,r){"use strict"
var n=this&&this.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r)
Object.defineProperty(e,n,{enumerable:!0,get:function(){return t[r]}})}:function(e,t,r,n){void 0===n&&(n=r)
e[n]=t[r]})
var a=this&&this.__exportStar||function(e,t){for(var r in e)"default"===r||Object.prototype.hasOwnProperty.call(t,r)||n(t,e,r)}
Object.defineProperty(t,"__esModule",{value:!0})
a(r(3633),t)
a(r(6530),t)
a(r(1833),t)
a(r(7062),t)
a(r(7344),t)
a(r(3757),t)
a(r(4701),t)},7344:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.getElementsByTagType=t.getElementsByTagName=t.getElementById=t.getElements=t.testElement=void 0
var n=r(7062)
var a=r(4701)
var i={tag_name:function(e){return"function"==typeof e?function(t){return a.isTag(t)&&e(t.name)}:"*"===e?a.isTag:function(t){return a.isTag(t)&&t.name===e}},tag_type:function(e){return"function"==typeof e?function(t){return e(t.type)}:function(t){return t.type===e}},tag_contains:function(e){return"function"==typeof e?function(t){return a.isText(t)&&e(t.data)}:function(t){return a.isText(t)&&t.data===e}}}
function o(e,t){return"function"==typeof t?function(r){return a.isTag(r)&&t(r.attribs[e])}:function(r){return a.isTag(r)&&r.attribs[e]===t}}function s(e,t){return function(r){return e(r)||t(r)}}function l(e){var t=Object.keys(e).map((function(t){var r=e[t]
return t in i?i[t](r):o(t,r)}))
return 0===t.length?null:t.reduce(s)}t.testElement=function(e,t){var r=l(e)
return!r||r(t)}
t.getElements=function(e,t,r,a){void 0===a&&(a=1/0)
var i=l(e)
return i?n.filter(i,t,r,a):[]}
t.getElementById=function(e,t,r){void 0===r&&(r=!0)
Array.isArray(t)||(t=[t])
return n.findOne(o("id",e),t,r)}
t.getElementsByTagName=function(e,t,r,a){void 0===r&&(r=!0)
void 0===a&&(a=1/0)
return n.filter(i.tag_name(e),t,r,a)}
t.getElementsByTagType=function(e,t,r,a){void 0===r&&(r=!0)
void 0===a&&(a=1/0)
return n.filter(i.tag_type(e),t,r,a)}},1833:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.prepend=t.prependChild=t.append=t.appendChild=t.replaceElement=t.removeElement=void 0
function r(e){e.prev&&(e.prev.next=e.next)
e.next&&(e.next.prev=e.prev)
if(e.parent){var t=e.parent.children
t.splice(t.lastIndexOf(e),1)}}t.removeElement=r
t.replaceElement=function(e,t){var r=t.prev=e.prev
r&&(r.next=t)
var n=t.next=e.next
n&&(n.prev=t)
var a=t.parent=e.parent
if(a){var i=a.children
i[i.lastIndexOf(e)]=t}}
t.appendChild=function(e,t){r(t)
t.next=null
t.parent=e
if(e.children.push(t)>1){var n=e.children[e.children.length-2]
n.next=t
t.prev=n}else t.prev=null}
t.append=function(e,t){r(t)
var n=e.parent
var a=e.next
t.next=a
t.prev=e
e.next=t
t.parent=n
if(a){a.prev=t
if(n){var i=n.children
i.splice(i.lastIndexOf(a),0,t)}}else n&&n.children.push(t)}
t.prependChild=function(e,t){r(t)
t.parent=e
t.prev=null
if(1!==e.children.unshift(t)){var n=e.children[1]
n.prev=t
t.next=n}else t.next=null}
t.prepend=function(e,t){r(t)
var n=e.parent
if(n){var a=n.children
a.splice(a.indexOf(e),0,t)}e.prev&&(e.prev.next=t)
t.parent=n
t.prev=e.prev
t.next=e
e.prev=t}},7062:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.findAll=t.existsOne=t.findOne=t.findOneChild=t.find=t.filter=void 0
var n=r(4701)
t.filter=function(e,t,r,n){void 0===r&&(r=!0)
void 0===n&&(n=1/0)
Array.isArray(t)||(t=[t])
return a(e,t,r,n)}
function a(e,t,r,i){var o=[]
for(var s=0,l=t;s<l.length;s++){var c=l[s]
if(e(c)){o.push(c)
if(--i<=0)break}if(r&&n.hasChildren(c)&&c.children.length>0){var d=a(e,c.children,r,i)
o.push.apply(o,d)
if((i-=d.length)<=0)break}}return o}t.find=a
t.findOneChild=function(e,t){return t.find(e)}
t.findOne=function e(t,r,a){void 0===a&&(a=!0)
var i=null
for(var o=0;o<r.length&&!i;o++){var s=r[o]
n.isTag(s)&&(t(s)?i=s:a&&s.children.length>0&&(i=e(t,s.children)))}return i}
t.existsOne=function e(t,r){return r.some((function(r){return n.isTag(r)&&(t(r)||r.children.length>0&&e(t,r.children))}))}
t.findAll=function(e,t){var r
var a=[]
var i=t.filter(n.isTag)
var o
for(;o=i.shift();){var s=null===(r=o.children)||void 0===r?void 0:r.filter(n.isTag)
s&&s.length>0&&i.unshift.apply(i,s)
e(o)&&a.push(o)}return a}},3633:function(e,t,r){"use strict"
var n=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}}
Object.defineProperty(t,"__esModule",{value:!0})
t.getText=t.getInnerHTML=t.getOuterHTML=void 0
var a=r(4701)
var i=n(r(1671))
function o(e,t){return i.default(e,t)}t.getOuterHTML=o
t.getInnerHTML=function(e,t){return a.hasChildren(e)?e.children.map((function(e){return o(e,t)})).join(""):""}
t.getText=function e(t){return Array.isArray(t)?t.map(e).join(""):a.isTag(t)?"br"===t.name?"\n":e(t.children):a.isCDATA(t)?e(t.children):a.isText(t)?t.data:""}},4701:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.hasChildren=t.isComment=t.isText=t.isCDATA=t.isTag=void 0
var n=r(7304)
t.isTag=function(e){return n.isTag(e)}
t.isCDATA=function(e){return"cdata"===e.type}
t.isText=function(e){return"text"===e.type}
t.isComment=function(e){return"comment"===e.type}
t.hasChildren=function(e){return Object.prototype.hasOwnProperty.call(e,"children")}},6530:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.nextElementSibling=t.getName=t.hasAttrib=t.getAttributeValue=t.getSiblings=t.getParent=t.getChildren=void 0
var n=r(4701)
var a=[]
function i(e){var t
return null!==(t=e.children)&&void 0!==t?t:a}t.getChildren=i
function o(e){return e.parent||null}t.getParent=o
t.getSiblings=function(e){var t=o(e)
if(null!=t)return i(t)
var r=[e]
var n=e.prev,a=e.next
for(;null!=n;){r.unshift(n)
n=n.prev}for(;null!=a;){r.push(a)
a=a.next}return r}
t.getAttributeValue=function(e,t){var r
return null===(r=e.attribs)||void 0===r?void 0:r[t]}
t.hasAttrib=function(e,t){return null!=e.attribs&&Object.prototype.hasOwnProperty.call(e.attribs,t)&&null!=e.attribs[t]}
t.getName=function(e){return e.name}
t.nextElementSibling=function(e){var t=e.next
for(;null!==t&&!n.isTag(t);)t=t.next
return t}},6347:function(e,t,r){"use strict"
var n=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}}
Object.defineProperty(t,"__esModule",{value:!0})
t.decodeHTML=t.decodeHTMLStrict=t.decodeXML=void 0
var a=n(r(4007))
var i=n(r(7802))
var o=n(r(2228))
var s=n(r(8271))
t.decodeXML=l(o.default)
t.decodeHTMLStrict=l(a.default)
function l(e){var t=Object.keys(e).join("|")
var r=d(e)
var n=new RegExp("&(?:"+(t+="|#[xX][\\da-fA-F]+|#\\d+")+");","g")
return function(e){return String(e).replace(n,r)}}var c=function(e,t){return e<t?1:-1}
t.decodeHTML=function(){var e=Object.keys(i.default).sort(c)
var t=Object.keys(a.default).sort(c)
for(var r=0,n=0;r<t.length;r++)if(e[n]===t[r]){t[r]+=";?"
n++}else t[r]+=";"
var o=new RegExp("&(?:"+t.join("|")+"|#[xX][\\da-fA-F]+;?|#\\d+;?)","g")
var s=d(a.default)
function l(e){";"!==e.substr(-1)&&(e+=";")
return s(e)}return function(e){return String(e).replace(o,l)}}()
function d(e){return function(t){if("#"===t.charAt(1)){var r=t.charAt(2)
return"X"===r||"x"===r?s.default(parseInt(t.substr(3),16)):s.default(parseInt(t.substr(2),10))}return e[t.slice(1,-1)]}}},8271:function(e,t,r){"use strict"
var n=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}}
Object.defineProperty(t,"__esModule",{value:!0})
var a=n(r(4589))
t.default=function(e){if(e>=55296&&e<=57343||e>1114111)return"�"
e in a.default&&(e=a.default[e])
var t=""
if(e>65535){e-=65536
t+=String.fromCharCode(e>>>10&1023|55296)
e=56320|1023&e}return t+String.fromCharCode(e)}},3393:function(e,t,r){"use strict"
var n=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}}
Object.defineProperty(t,"__esModule",{value:!0})
t.escape=t.encodeHTML=t.encodeXML=void 0
var a=l(n(r(2228)).default)
var i=c(a)
t.encodeXML=p(a,i)
var o=l(n(r(4007)).default)
var s=c(o)
t.encodeHTML=p(o,s)
function l(e){return Object.keys(e).sort().reduce((function(t,r){t[e[r]]="&"+r+";"
return t}),{})}function c(e){var t=[]
var r=[]
for(var n=0,a=Object.keys(e);n<a.length;n++){var i=a[n]
1===i.length?t.push("\\"+i):r.push(i)}t.sort()
for(var o=0;o<t.length-1;o++){var s=o
for(;s<t.length-1&&t[s].charCodeAt(1)+1===t[s+1].charCodeAt(1);)s+=1
var l=1+s-o
l<3||t.splice(o,l,t[o]+"-"+t[s])}r.unshift("["+t.join("")+"]")
return new RegExp(r.join("|"),"g")}var d=/(?:[\x80-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/g
function u(e){return"&#x"+e.codePointAt(0).toString(16).toUpperCase()+";"}function p(e,t){return function(r){return r.replace(t,(function(t){return e[t]})).replace(d,u)}}var m=c(a)
t.escape=function(e){return e.replace(m,u).replace(d,u)}},7531:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.decodeXMLStrict=t.decodeHTML5Strict=t.decodeHTML4Strict=t.decodeHTML5=t.decodeHTML4=t.decodeHTMLStrict=t.decodeHTML=t.decodeXML=t.encodeHTML5=t.encodeHTML4=t.escape=t.encodeHTML=t.encodeXML=t.encode=t.decodeStrict=t.decode=void 0
var n=r(6347)
var a=r(3393)
t.decode=function(e,t){return(!t||t<=0?n.decodeXML:n.decodeHTML)(e)}
t.decodeStrict=function(e,t){return(!t||t<=0?n.decodeXML:n.decodeHTMLStrict)(e)}
t.encode=function(e,t){return(!t||t<=0?a.encodeXML:a.encodeHTML)(e)}
var i=r(3393)
Object.defineProperty(t,"encodeXML",{enumerable:!0,get:function(){return i.encodeXML}})
Object.defineProperty(t,"encodeHTML",{enumerable:!0,get:function(){return i.encodeHTML}})
Object.defineProperty(t,"escape",{enumerable:!0,get:function(){return i.escape}})
Object.defineProperty(t,"encodeHTML4",{enumerable:!0,get:function(){return i.encodeHTML}})
Object.defineProperty(t,"encodeHTML5",{enumerable:!0,get:function(){return i.encodeHTML}})
var o=r(6347)
Object.defineProperty(t,"decodeXML",{enumerable:!0,get:function(){return o.decodeXML}})
Object.defineProperty(t,"decodeHTML",{enumerable:!0,get:function(){return o.decodeHTML}})
Object.defineProperty(t,"decodeHTMLStrict",{enumerable:!0,get:function(){return o.decodeHTMLStrict}})
Object.defineProperty(t,"decodeHTML4",{enumerable:!0,get:function(){return o.decodeHTML}})
Object.defineProperty(t,"decodeHTML5",{enumerable:!0,get:function(){return o.decodeHTML}})
Object.defineProperty(t,"decodeHTML4Strict",{enumerable:!0,get:function(){return o.decodeHTMLStrict}})
Object.defineProperty(t,"decodeHTML5Strict",{enumerable:!0,get:function(){return o.decodeHTMLStrict}})
Object.defineProperty(t,"decodeXMLStrict",{enumerable:!0,get:function(){return o.decodeXML}})},1289:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.compile=void 0
var n=r(7544)
t.compile=function(e){var t=e[0]
var r=e[1]-1
if(r<0&&t<=0)return n.falseFunc
if(-1===t)return function(e){return e<=r}
if(0===t)return function(e){return e===r}
if(1===t)return r<0?n.trueFunc:function(e){return e>=r}
var a=Math.abs(t)
var i=(r%a+a)%a
return t>1?function(e){return e>=r&&e%a===i}:function(e){return e<=r&&e%a===i}}},1316:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.compile=t.parse=void 0
var n=r(9922)
Object.defineProperty(t,"parse",{enumerable:!0,get:function(){return n.parse}})
var a=r(1289)
Object.defineProperty(t,"compile",{enumerable:!0,get:function(){return a.compile}})
t.default=function(e){return a.compile(n.parse(e))}},9922:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
t.parse=void 0
var r=/^([+-]?\d*n)?\s*(?:([+-]?)\s*(\d+))?$/
t.parse=function(e){if("even"===(e=e.trim().toLowerCase()))return[2,0]
if("odd"===e)return[2,1]
var t=e.match(r)
if(!t)throw new Error("n-th rule couldn't be parsed ('"+e+"')")
var n
if(t[1]){n=parseInt(t[1],10)
isNaN(n)&&(n=t[1].startsWith("-")?-1:1)}else n=0
return[n,("-"===t[2]?-1:1)*(t[3]?parseInt(t[3],10):0)]}},4289:(e,t,r)=>{!function(e){e.parser=function(e,t){return new n(e,t)}
e.SAXParser=n
e.SAXStream=o
e.createStream=function(e,t){return new o(e,t)}
e.MAX_BUFFER_LENGTH=65536
var t=["comment","sgmlDecl","textNode","tagName","doctype","procInstName","procInstBody","entity","attribName","attribValue","cdata","script"]
e.EVENTS=["text","processinginstruction","sgmldeclaration","doctype","comment","opentagstart","attribute","opentag","closetag","opencdata","cdata","closecdata","error","end","ready","script","opennamespace","closenamespace"]
function n(r,a){if(!(this instanceof n))return new n(r,a)
var i=this
!function(e){for(var r=0,n=t.length;r<n;r++)e[t[r]]=""}(i)
i.q=i.c=""
i.bufferCheckPosition=e.MAX_BUFFER_LENGTH
i.opt=a||{}
i.opt.lowercase=i.opt.lowercase||i.opt.lowercasetags
i.looseCase=i.opt.lowercase?"toLowerCase":"toUpperCase"
i.tags=[]
i.closed=i.closedRoot=i.sawRoot=!1
i.tag=i.error=null
i.strict=!!r
i.noscript=!(!r&&!i.opt.noscript)
i.state=b.BEGIN
i.strictEntities=i.opt.strictEntities
i.ENTITIES=i.strictEntities?Object.create(e.XML_ENTITIES):Object.create(e.ENTITIES)
i.attribList=[]
i.opt.xmlns&&(i.ns=Object.create(c))
i.trackPosition=!1!==i.opt.position
i.trackPosition&&(i.position=i.line=i.column=0)
x(i,"onready")}Object.create||(Object.create=function(e){function t(){}t.prototype=e
return new t})
Object.keys||(Object.keys=function(e){var t=[]
for(var r in e)e.hasOwnProperty(r)&&t.push(r)
return t})
n.prototype={end:function(){A(this)},write:function(r){var n=this
if(this.error)throw this.error
if(n.closed)return T(n,"Cannot write after close. Assign an onready handler.")
if(null===r)return A(n)
"object"==typeof r&&(r=r.toString())
var a=0
var i=""
for(;;){i=B(r,a++)
n.c=i
if(!i)break
if(n.trackPosition){n.position++
if("\n"===i){n.line++
n.column=0}else n.column++}switch(n.state){case b.BEGIN:n.state=b.BEGIN_WHITESPACE
if("\ufeff"===i)continue
W(n,i)
continue
case b.BEGIN_WHITESPACE:W(n,i)
continue
case b.TEXT:if(n.sawRoot&&!n.closedRoot){var o=a-1
for(;i&&"<"!==i&&"&"!==i;)if((i=B(r,a++))&&n.trackPosition){n.position++
if("\n"===i){n.line++
n.column=0}else n.column++}n.textNode+=r.substring(o,a-1)}if("<"!==i||n.sawRoot&&n.closedRoot&&!n.strict){f(i)||n.sawRoot&&!n.closedRoot||E(n,"Text data outside of root node.")
"&"===i?n.state=b.TEXT_ENTITY:n.textNode+=i}else{n.state=b.OPEN_WAKA
n.startTagPosition=n.position}continue
case b.SCRIPT:"<"===i?n.state=b.SCRIPT_ENDING:n.script+=i
continue
case b.SCRIPT_ENDING:if("/"===i)n.state=b.CLOSE_TAG
else{n.script+="<"+i
n.state=b.SCRIPT}continue
case b.OPEN_WAKA:if("!"===i){n.state=b.SGML_DECL
n.sgmlDecl=""}else if(f(i));else if(v(d,i)){n.state=b.OPEN_TAG
n.tagName=i}else if("/"===i){n.state=b.CLOSE_TAG
n.tagName=""}else if("?"===i){n.state=b.PROC_INST
n.procInstName=n.procInstBody=""}else{E(n,"Unencoded <")
if(n.startTagPosition+1<n.position){var s=n.position-n.startTagPosition
i=new Array(s).join(" ")+i}n.textNode+="<"+i
n.state=b.TEXT}continue
case b.SGML_DECL:if("[CDATA["===(n.sgmlDecl+i).toUpperCase()){k(n,"onopencdata")
n.state=b.CDATA
n.sgmlDecl=""
n.cdata=""}else if(n.sgmlDecl+i==="--"){n.state=b.COMMENT
n.comment=""
n.sgmlDecl=""}else if("DOCTYPE"===(n.sgmlDecl+i).toUpperCase()){n.state=b.DOCTYPE;(n.doctype||n.sawRoot)&&E(n,"Inappropriately located doctype declaration")
n.doctype=""
n.sgmlDecl=""}else if(">"===i){k(n,"onsgmldeclaration",n.sgmlDecl)
n.sgmlDecl=""
n.state=b.TEXT}else if(h(i)){n.state=b.SGML_DECL_QUOTED
n.sgmlDecl+=i}else n.sgmlDecl+=i
continue
case b.SGML_DECL_QUOTED:if(i===n.q){n.state=b.SGML_DECL
n.q=""}n.sgmlDecl+=i
continue
case b.DOCTYPE:if(">"===i){n.state=b.TEXT
k(n,"ondoctype",n.doctype)
n.doctype=!0}else{n.doctype+=i
if("["===i)n.state=b.DOCTYPE_DTD
else if(h(i)){n.state=b.DOCTYPE_QUOTED
n.q=i}}continue
case b.DOCTYPE_QUOTED:n.doctype+=i
if(i===n.q){n.q=""
n.state=b.DOCTYPE}continue
case b.DOCTYPE_DTD:n.doctype+=i
if("]"===i)n.state=b.DOCTYPE
else if(h(i)){n.state=b.DOCTYPE_DTD_QUOTED
n.q=i}continue
case b.DOCTYPE_DTD_QUOTED:n.doctype+=i
if(i===n.q){n.state=b.DOCTYPE_DTD
n.q=""}continue
case b.COMMENT:"-"===i?n.state=b.COMMENT_ENDING:n.comment+=i
continue
case b.COMMENT_ENDING:if("-"===i){n.state=b.COMMENT_ENDED
n.comment=C(n.opt,n.comment)
n.comment&&k(n,"oncomment",n.comment)
n.comment=""}else{n.comment+="-"+i
n.state=b.COMMENT}continue
case b.COMMENT_ENDED:if(">"!==i){E(n,"Malformed comment")
n.comment+="--"+i
n.state=b.COMMENT}else n.state=b.TEXT
continue
case b.CDATA:"]"===i?n.state=b.CDATA_ENDING:n.cdata+=i
continue
case b.CDATA_ENDING:if("]"===i)n.state=b.CDATA_ENDING_2
else{n.cdata+="]"+i
n.state=b.CDATA}continue
case b.CDATA_ENDING_2:if(">"===i){n.cdata&&k(n,"oncdata",n.cdata)
k(n,"onclosecdata")
n.cdata=""
n.state=b.TEXT}else if("]"===i)n.cdata+="]"
else{n.cdata+="]]"+i
n.state=b.CDATA}continue
case b.PROC_INST:"?"===i?n.state=b.PROC_INST_ENDING:f(i)?n.state=b.PROC_INST_BODY:n.procInstName+=i
continue
case b.PROC_INST_BODY:if(!n.procInstBody&&f(i))continue
"?"===i?n.state=b.PROC_INST_ENDING:n.procInstBody+=i
continue
case b.PROC_INST_ENDING:if(">"===i){k(n,"onprocessinginstruction",{name:n.procInstName,body:n.procInstBody})
n.procInstName=n.procInstBody=""
n.state=b.TEXT}else{n.procInstBody+="?"+i
n.state=b.PROC_INST_BODY}continue
case b.OPEN_TAG:if(v(u,i))n.tagName+=i
else{O(n)
if(">"===i)P(n)
else if("/"===i)n.state=b.OPEN_TAG_SLASH
else{f(i)||E(n,"Invalid character in tag name")
n.state=b.ATTRIB}}continue
case b.OPEN_TAG_SLASH:if(">"===i){P(n,!0)
q(n)}else{E(n,"Forward-slash in opening tag not followed by >")
n.state=b.ATTRIB}continue
case b.ATTRIB:if(f(i))continue
if(">"===i)P(n)
else if("/"===i)n.state=b.OPEN_TAG_SLASH
else if(v(d,i)){n.attribName=i
n.attribValue=""
n.state=b.ATTRIB_NAME}else E(n,"Invalid attribute name")
continue
case b.ATTRIB_NAME:if("="===i)n.state=b.ATTRIB_VALUE
else if(">"===i){E(n,"Attribute without value")
n.attribValue=n.attribName
_(n)
P(n)}else f(i)?n.state=b.ATTRIB_NAME_SAW_WHITE:v(u,i)?n.attribName+=i:E(n,"Invalid attribute name")
continue
case b.ATTRIB_NAME_SAW_WHITE:if("="===i)n.state=b.ATTRIB_VALUE
else{if(f(i))continue
E(n,"Attribute without value")
n.tag.attributes[n.attribName]=""
n.attribValue=""
k(n,"onattribute",{name:n.attribName,value:""})
n.attribName=""
if(">"===i)P(n)
else if(v(d,i)){n.attribName=i
n.state=b.ATTRIB_NAME}else{E(n,"Invalid attribute name")
n.state=b.ATTRIB}}continue
case b.ATTRIB_VALUE:if(f(i))continue
if(h(i)){n.q=i
n.state=b.ATTRIB_VALUE_QUOTED}else{E(n,"Unquoted attribute value")
n.state=b.ATTRIB_VALUE_UNQUOTED
n.attribValue=i}continue
case b.ATTRIB_VALUE_QUOTED:if(i!==n.q){"&"===i?n.state=b.ATTRIB_VALUE_ENTITY_Q:n.attribValue+=i
continue}_(n)
n.q=""
n.state=b.ATTRIB_VALUE_CLOSED
continue
case b.ATTRIB_VALUE_CLOSED:if(f(i))n.state=b.ATTRIB
else if(">"===i)P(n)
else if("/"===i)n.state=b.OPEN_TAG_SLASH
else if(v(d,i)){E(n,"No whitespace between attributes")
n.attribName=i
n.attribValue=""
n.state=b.ATTRIB_NAME}else E(n,"Invalid attribute name")
continue
case b.ATTRIB_VALUE_UNQUOTED:if(!g(i)){"&"===i?n.state=b.ATTRIB_VALUE_ENTITY_U:n.attribValue+=i
continue}_(n)
">"===i?P(n):n.state=b.ATTRIB
continue
case b.CLOSE_TAG:if(n.tagName)if(">"===i)q(n)
else if(v(u,i))n.tagName+=i
else if(n.script){n.script+="</"+n.tagName
n.tagName=""
n.state=b.SCRIPT}else{f(i)||E(n,"Invalid tagname in closing tag")
n.state=b.CLOSE_TAG_SAW_WHITE}else{if(f(i))continue
if(y(d,i))if(n.script){n.script+="</"+i
n.state=b.SCRIPT}else E(n,"Invalid tagname in closing tag.")
else n.tagName=i}continue
case b.CLOSE_TAG_SAW_WHITE:if(f(i))continue
">"===i?q(n):E(n,"Invalid characters in closing tag")
continue
case b.TEXT_ENTITY:case b.ATTRIB_VALUE_ENTITY_Q:case b.ATTRIB_VALUE_ENTITY_U:var l
var c
switch(n.state){case b.TEXT_ENTITY:l=b.TEXT
c="textNode"
break
case b.ATTRIB_VALUE_ENTITY_Q:l=b.ATTRIB_VALUE_QUOTED
c="attribValue"
break
case b.ATTRIB_VALUE_ENTITY_U:l=b.ATTRIB_VALUE_UNQUOTED
c="attribValue"}if(";"===i){n[c]+=L(n)
n.entity=""
n.state=l}else if(v(n.entity.length?m:p,i))n.entity+=i
else{E(n,"Invalid character in entity name")
n[c]+="&"+n.entity+i
n.entity=""
n.state=l}continue
default:throw new Error(n,"Unknown state: "+n.state)}}n.position>=n.bufferCheckPosition&&function(r){var n=Math.max(e.MAX_BUFFER_LENGTH,10)
var a=0
for(var i=0,o=t.length;i<o;i++){var s=r[t[i]].length
if(s>n)switch(t[i]){case"textNode":w(r)
break
case"cdata":k(r,"oncdata",r.cdata)
r.cdata=""
break
case"script":k(r,"onscript",r.script)
r.script=""
break
default:T(r,"Max buffer length exceeded: "+t[i])}a=Math.max(a,s)}var l=e.MAX_BUFFER_LENGTH-a
r.bufferCheckPosition=l+r.position}(n)
return n}
/*! http://mths.be/fromcodepoint v0.1.0 by @mathias */,resume:function(){this.error=null
return this},close:function(){return this.write(null)},flush:function(){!function(e){w(e)
if(""!==e.cdata){k(e,"oncdata",e.cdata)
e.cdata=""}if(""!==e.script){k(e,"onscript",e.script)
e.script=""}}(this)}}
var a
try{a=r(2413).Stream}catch(e){a=function(){}}var i=e.EVENTS.filter((function(e){return"error"!==e&&"end"!==e}))
function o(e,t){if(!(this instanceof o))return new o(e,t)
a.apply(this)
this._parser=new n(e,t)
this.writable=!0
this.readable=!0
var r=this
this._parser.onend=function(){r.emit("end")}
this._parser.onerror=function(e){r.emit("error",e)
r._parser.error=null}
this._decoder=null
i.forEach((function(e){Object.defineProperty(r,"on"+e,{get:function(){return r._parser["on"+e]},set:function(t){if(!t){r.removeAllListeners(e)
r._parser["on"+e]=t
return t}r.on(e,t)},enumerable:!0,configurable:!1})}))}o.prototype=Object.create(a.prototype,{constructor:{value:o}})
o.prototype.write=function(e){if("function"==typeof Buffer&&"function"==typeof Buffer.isBuffer&&Buffer.isBuffer(e)){if(!this._decoder){var t=r(4304).StringDecoder
this._decoder=new t("utf8")}e=this._decoder.write(e)}this._parser.write(e.toString())
this.emit("data",e)
return!0}
o.prototype.end=function(e){e&&e.length&&this.write(e)
this._parser.end()
return!0}
o.prototype.on=function(e,t){var r=this
r._parser["on"+e]||-1===i.indexOf(e)||(r._parser["on"+e]=function(){var t=1===arguments.length?[arguments[0]]:Array.apply(null,arguments)
t.splice(0,0,e)
r.emit.apply(r,t)})
return a.prototype.on.call(r,e,t)}
var s="http://www.w3.org/XML/1998/namespace"
var l="http://www.w3.org/2000/xmlns/"
var c={xml:s,xmlns:l}
var d=/[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/
var u=/[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/
var p=/[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/
var m=/[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/
function f(e){return" "===e||"\n"===e||"\r"===e||"\t"===e}function h(e){return'"'===e||"'"===e}function g(e){return">"===e||f(e)}function v(e,t){return e.test(t)}function y(e,t){return!v(e,t)}var b=0
e.STATE={BEGIN:b++,BEGIN_WHITESPACE:b++,TEXT:b++,TEXT_ENTITY:b++,OPEN_WAKA:b++,SGML_DECL:b++,SGML_DECL_QUOTED:b++,DOCTYPE:b++,DOCTYPE_QUOTED:b++,DOCTYPE_DTD:b++,DOCTYPE_DTD_QUOTED:b++,COMMENT_STARTING:b++,COMMENT:b++,COMMENT_ENDING:b++,COMMENT_ENDED:b++,CDATA:b++,CDATA_ENDING:b++,CDATA_ENDING_2:b++,PROC_INST:b++,PROC_INST_BODY:b++,PROC_INST_ENDING:b++,OPEN_TAG:b++,OPEN_TAG_SLASH:b++,ATTRIB:b++,ATTRIB_NAME:b++,ATTRIB_NAME_SAW_WHITE:b++,ATTRIB_VALUE:b++,ATTRIB_VALUE_QUOTED:b++,ATTRIB_VALUE_CLOSED:b++,ATTRIB_VALUE_UNQUOTED:b++,ATTRIB_VALUE_ENTITY_Q:b++,ATTRIB_VALUE_ENTITY_U:b++,CLOSE_TAG:b++,CLOSE_TAG_SAW_WHITE:b++,SCRIPT:b++,SCRIPT_ENDING:b++}
e.XML_ENTITIES={amp:"&",gt:">",lt:"<",quot:'"',apos:"'"}
e.ENTITIES={amp:"&",gt:">",lt:"<",quot:'"',apos:"'",AElig:198,Aacute:193,Acirc:194,Agrave:192,Aring:197,Atilde:195,Auml:196,Ccedil:199,ETH:208,Eacute:201,Ecirc:202,Egrave:200,Euml:203,Iacute:205,Icirc:206,Igrave:204,Iuml:207,Ntilde:209,Oacute:211,Ocirc:212,Ograve:210,Oslash:216,Otilde:213,Ouml:214,THORN:222,Uacute:218,Ucirc:219,Ugrave:217,Uuml:220,Yacute:221,aacute:225,acirc:226,aelig:230,agrave:224,aring:229,atilde:227,auml:228,ccedil:231,eacute:233,ecirc:234,egrave:232,eth:240,euml:235,iacute:237,icirc:238,igrave:236,iuml:239,ntilde:241,oacute:243,ocirc:244,ograve:242,oslash:248,otilde:245,ouml:246,szlig:223,thorn:254,uacute:250,ucirc:251,ugrave:249,uuml:252,yacute:253,yuml:255,copy:169,reg:174,nbsp:160,iexcl:161,cent:162,pound:163,curren:164,yen:165,brvbar:166,sect:167,uml:168,ordf:170,laquo:171,not:172,shy:173,macr:175,deg:176,plusmn:177,sup1:185,sup2:178,sup3:179,acute:180,micro:181,para:182,middot:183,cedil:184,ordm:186,raquo:187,frac14:188,frac12:189,frac34:190,iquest:191,times:215,divide:247,OElig:338,oelig:339,Scaron:352,scaron:353,Yuml:376,fnof:402,circ:710,tilde:732,Alpha:913,Beta:914,Gamma:915,Delta:916,Epsilon:917,Zeta:918,Eta:919,Theta:920,Iota:921,Kappa:922,Lambda:923,Mu:924,Nu:925,Xi:926,Omicron:927,Pi:928,Rho:929,Sigma:931,Tau:932,Upsilon:933,Phi:934,Chi:935,Psi:936,Omega:937,alpha:945,beta:946,gamma:947,delta:948,epsilon:949,zeta:950,eta:951,theta:952,iota:953,kappa:954,lambda:955,mu:956,nu:957,xi:958,omicron:959,pi:960,rho:961,sigmaf:962,sigma:963,tau:964,upsilon:965,phi:966,chi:967,psi:968,omega:969,thetasym:977,upsih:978,piv:982,ensp:8194,emsp:8195,thinsp:8201,zwnj:8204,zwj:8205,lrm:8206,rlm:8207,ndash:8211,mdash:8212,lsquo:8216,rsquo:8217,sbquo:8218,ldquo:8220,rdquo:8221,bdquo:8222,dagger:8224,Dagger:8225,bull:8226,hellip:8230,permil:8240,prime:8242,Prime:8243,lsaquo:8249,rsaquo:8250,oline:8254,frasl:8260,euro:8364,image:8465,weierp:8472,real:8476,trade:8482,alefsym:8501,larr:8592,uarr:8593,rarr:8594,darr:8595,harr:8596,crarr:8629,lArr:8656,uArr:8657,rArr:8658,dArr:8659,hArr:8660,forall:8704,part:8706,exist:8707,empty:8709,nabla:8711,isin:8712,notin:8713,ni:8715,prod:8719,sum:8721,minus:8722,lowast:8727,radic:8730,prop:8733,infin:8734,ang:8736,and:8743,or:8744,cap:8745,cup:8746,int:8747,there4:8756,sim:8764,cong:8773,asymp:8776,ne:8800,equiv:8801,le:8804,ge:8805,sub:8834,sup:8835,nsub:8836,sube:8838,supe:8839,oplus:8853,otimes:8855,perp:8869,sdot:8901,lceil:8968,rceil:8969,lfloor:8970,rfloor:8971,lang:9001,rang:9002,loz:9674,spades:9824,clubs:9827,hearts:9829,diams:9830}
Object.keys(e.ENTITIES).forEach((function(t){var r=e.ENTITIES[t]
var n="number"==typeof r?String.fromCharCode(r):r
e.ENTITIES[t]=n}))
for(var S in e.STATE)e.STATE[e.STATE[S]]=S
b=e.STATE
function x(e,t,r){e[t]&&e[t](r)}function k(e,t,r){e.textNode&&w(e)
x(e,t,r)}function w(e){e.textNode=C(e.opt,e.textNode)
e.textNode&&x(e,"ontext",e.textNode)
e.textNode=""}function C(e,t){e.trim&&(t=t.trim())
e.normalize&&(t=t.replace(/\s+/g," "))
return t}function T(e,t){w(e)
e.trackPosition&&(t+="\nLine: "+e.line+"\nColumn: "+e.column+"\nChar: "+e.c)
t=new Error(t)
e.error=t
x(e,"onerror",t)
return e}function A(e){e.sawRoot&&!e.closedRoot&&E(e,"Unclosed root tag")
e.state!==b.BEGIN&&e.state!==b.BEGIN_WHITESPACE&&e.state!==b.TEXT&&T(e,"Unexpected end")
w(e)
e.c=""
e.closed=!0
x(e,"onend")
n.call(e,e.strict,e.opt)
return e}function E(e,t){if("object"!=typeof e||!(e instanceof n))throw new Error("bad call to strictFail")
e.strict&&T(e,t)}function O(e){e.strict||(e.tagName=e.tagName[e.looseCase]())
var t=e.tags[e.tags.length-1]||e
var r=e.tag={name:e.tagName,attributes:{}}
e.opt.xmlns&&(r.ns=t.ns)
e.attribList.length=0
k(e,"onopentagstart",r)}function z(e,t){var r=e.indexOf(":")<0?["",e]:e.split(":")
var n=r[0]
var a=r[1]
if(t&&"xmlns"===e){n="xmlns"
a=""}return{prefix:n,local:a}}function _(e){e.strict||(e.attribName=e.attribName[e.looseCase]())
if(-1!==e.attribList.indexOf(e.attribName)||e.tag.attributes.hasOwnProperty(e.attribName))e.attribName=e.attribValue=""
else{if(e.opt.xmlns){var t=z(e.attribName,!0)
var r=t.prefix
var n=t.local
if("xmlns"===r)if("xml"===n&&e.attribValue!==s)E(e,"xml: prefix must be bound to "+s+"\nActual: "+e.attribValue)
else if("xmlns"===n&&e.attribValue!==l)E(e,"xmlns: prefix must be bound to "+l+"\nActual: "+e.attribValue)
else{var a=e.tag
var i=e.tags[e.tags.length-1]||e
a.ns===i.ns&&(a.ns=Object.create(i.ns))
a.ns[n]=e.attribValue}e.attribList.push([e.attribName,e.attribValue])}else{e.tag.attributes[e.attribName]=e.attribValue
k(e,"onattribute",{name:e.attribName,value:e.attribValue})}e.attribName=e.attribValue=""}}function P(e,t){if(e.opt.xmlns){var r=e.tag
var n=z(e.tagName)
r.prefix=n.prefix
r.local=n.local
r.uri=r.ns[n.prefix]||""
if(r.prefix&&!r.uri){E(e,"Unbound namespace prefix: "+JSON.stringify(e.tagName))
r.uri=n.prefix}var a=e.tags[e.tags.length-1]||e
r.ns&&a.ns!==r.ns&&Object.keys(r.ns).forEach((function(t){k(e,"onopennamespace",{prefix:t,uri:r.ns[t]})}))
for(var i=0,o=e.attribList.length;i<o;i++){var s=e.attribList[i]
var l=s[0]
var c=s[1]
var d=z(l,!0)
var u=d.prefix
var p=d.local
var m=""===u?"":r.ns[u]||""
var f={name:l,value:c,prefix:u,local:p,uri:m}
if(u&&"xmlns"!==u&&!m){E(e,"Unbound namespace prefix: "+JSON.stringify(u))
f.uri=u}e.tag.attributes[l]=f
k(e,"onattribute",f)}e.attribList.length=0}e.tag.isSelfClosing=!!t
e.sawRoot=!0
e.tags.push(e.tag)
k(e,"onopentag",e.tag)
if(!t){e.noscript||"script"!==e.tagName.toLowerCase()?e.state=b.TEXT:e.state=b.SCRIPT
e.tag=null
e.tagName=""}e.attribName=e.attribValue=""
e.attribList.length=0}function q(e){if(e.tagName){if(e.script){if("script"!==e.tagName){e.script+="</"+e.tagName+">"
e.tagName=""
e.state=b.SCRIPT
return}k(e,"onscript",e.script)
e.script=""}var t=e.tags.length
var r=e.tagName
e.strict||(r=r[e.looseCase]())
var n=r
for(;t--&&e.tags[t].name!==n;)E(e,"Unexpected close tag")
if(t<0){E(e,"Unmatched closing tag: "+e.tagName)
e.textNode+="</"+e.tagName+">"
e.state=b.TEXT}else{e.tagName=r
var a=e.tags.length
for(;a-- >t;){var i=e.tag=e.tags.pop()
e.tagName=e.tag.name
k(e,"onclosetag",e.tagName)
var o={}
for(var s in i.ns)o[s]=i.ns[s]
var l=e.tags[e.tags.length-1]||e
e.opt.xmlns&&i.ns!==l.ns&&Object.keys(i.ns).forEach((function(t){var r=i.ns[t]
k(e,"onclosenamespace",{prefix:t,uri:r})}))}0===t&&(e.closedRoot=!0)
e.tagName=e.attribValue=e.attribName=""
e.attribList.length=0
e.state=b.TEXT}}else{E(e,"Weird empty close tag.")
e.textNode+="</>"
e.state=b.TEXT}}function L(e){var t=e.entity
var r=t.toLowerCase()
var n
var a=""
if(e.ENTITIES[t])return e.ENTITIES[t]
if(e.ENTITIES[r])return e.ENTITIES[r]
if("#"===(t=r).charAt(0))if("x"===t.charAt(1)){t=t.slice(2)
a=(n=parseInt(t,16)).toString(16)}else{t=t.slice(1)
a=(n=parseInt(t,10)).toString(10)}t=t.replace(/^0+/,"")
if(isNaN(n)||a.toLowerCase()!==t){E(e,"Invalid character entity")
return"&"+e.entity+";"}return String.fromCodePoint(n)}function W(e,t){if("<"===t){e.state=b.OPEN_WAKA
e.startTagPosition=e.position}else if(!f(t)){E(e,"Non-whitespace before first tag.")
e.textNode=t
e.state=b.TEXT}}function B(e,t){var r=""
t<e.length&&(r=e.charAt(t))
return r}String.fromCodePoint||(M=String.fromCharCode,R=Math.floor,I=function(){var e=16384
var t=[]
var r
var n
var a=-1
var i=arguments.length
if(!i)return""
var o=""
for(;++a<i;){var s=Number(arguments[a])
if(!isFinite(s)||s<0||s>1114111||R(s)!==s)throw RangeError("Invalid code point: "+s)
if(s<=65535)t.push(s)
else{r=55296+((s-=65536)>>10)
n=s%1024+56320
t.push(r,n)}if(a+1===i||t.length>e){o+=M.apply(null,t)
t.length=0}}return o},Object.defineProperty?Object.defineProperty(String,"fromCodePoint",{value:I,configurable:!0,writable:!0}):String.fromCodePoint=I)
var M,R,I}(t)},6715:(e,t,r)=>{var n=r(7837)
var a=Object.prototype.hasOwnProperty
var i="undefined"!=typeof Map
function o(){this._array=[]
this._set=i?new Map:Object.create(null)}o.fromArray=function(e,t){var r=new o
for(var n=0,a=e.length;n<a;n++)r.add(e[n],t)
return r}
o.prototype.size=function(){return i?this._set.size:Object.getOwnPropertyNames(this._set).length}
o.prototype.add=function(e,t){var r=i?e:n.toSetString(e)
var o=i?this.has(e):a.call(this._set,r)
var s=this._array.length
o&&!t||this._array.push(e)
o||(i?this._set.set(e,s):this._set[r]=s)}
o.prototype.has=function(e){if(i)return this._set.has(e)
var t=n.toSetString(e)
return a.call(this._set,t)}
o.prototype.indexOf=function(e){if(i){var t=this._set.get(e)
if(t>=0)return t}else{var r=n.toSetString(e)
if(a.call(this._set,r))return this._set[r]}throw new Error('"'+e+'" is not in the set.')}
o.prototype.at=function(e){if(e>=0&&e<this._array.length)return this._array[e]
throw new Error("No element indexed by "+e)}
o.prototype.toArray=function(){return this._array.slice()}
t.I=o},4886:(e,t,r)=>{var n=r(4122)
t.encode=function(e){var t=""
var r
var a=function(e){return e<0?1+(-e<<1):0+(e<<1)}(e)
do{r=31&a;(a>>>=5)>0&&(r|=32)
t+=n.encode(r)}while(a>0)
return t}
t.decode=function(e,t,r){var a=e.length
var i=0
var o=0
var s,l
do{if(t>=a)throw new Error("Expected more digits in base 64 VLQ value.")
if(-1===(l=n.decode(e.charCodeAt(t++))))throw new Error("Invalid base64 digit: "+e.charAt(t-1))
s=!!(32&l)
i+=(l&=31)<<o
o+=5}while(s)
r.value=(d=(c=i)>>1,1==(1&c)?-d:d)
var c,d
r.rest=t}},4122:(e,t)=>{var r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("")
t.encode=function(e){if(0<=e&&e<r.length)return r[e]
throw new TypeError("Must be between 0 and 63: "+e)}
t.decode=function(e){return 65<=e&&e<=90?e-65:97<=e&&e<=122?e-97+26:48<=e&&e<=57?e-48+52:43==e?62:47==e?63:-1}},1028:(e,t,r)=>{var n=r(7837)
function a(){this._array=[]
this._sorted=!0
this._last={generatedLine:-1,generatedColumn:0}}a.prototype.unsortedForEach=function(e,t){this._array.forEach(e,t)}
a.prototype.add=function(e){if(r=e,a=(t=this._last).generatedLine,i=r.generatedLine,o=t.generatedColumn,s=r.generatedColumn,i>a||i==a&&s>=o||n.compareByGeneratedPositionsInflated(t,r)<=0){this._last=e
this._array.push(e)}else{this._sorted=!1
this._array.push(e)}var t,r,a,i,o,s}
a.prototype.toArray=function(){if(!this._sorted){this._array.sort(n.compareByGeneratedPositionsInflated)
this._sorted=!0}return this._array}
t.H=a},2400:(e,t,r)=>{var n=r(4886)
var a=r(7837)
var i=r(6715).I
var o=r(1028).H
function s(e){e||(e={})
this._file=a.getArg(e,"file",null)
this._sourceRoot=a.getArg(e,"sourceRoot",null)
this._skipValidation=a.getArg(e,"skipValidation",!1)
this._sources=new i
this._names=new i
this._mappings=new o
this._sourcesContents=null}s.prototype._version=3
s.fromSourceMap=function(e){var t=e.sourceRoot
var r=new s({file:e.file,sourceRoot:t})
e.eachMapping((function(e){var n={generated:{line:e.generatedLine,column:e.generatedColumn}}
if(null!=e.source){n.source=e.source
null!=t&&(n.source=a.relative(t,n.source))
n.original={line:e.originalLine,column:e.originalColumn}
null!=e.name&&(n.name=e.name)}r.addMapping(n)}))
e.sources.forEach((function(n){var i=n
null!==t&&(i=a.relative(t,n))
r._sources.has(i)||r._sources.add(i)
var o=e.sourceContentFor(n)
null!=o&&r.setSourceContent(n,o)}))
return r}
s.prototype.addMapping=function(e){var t=a.getArg(e,"generated")
var r=a.getArg(e,"original",null)
var n=a.getArg(e,"source",null)
var i=a.getArg(e,"name",null)
this._skipValidation||this._validateMapping(t,r,n,i)
if(null!=n){n=String(n)
this._sources.has(n)||this._sources.add(n)}if(null!=i){i=String(i)
this._names.has(i)||this._names.add(i)}this._mappings.add({generatedLine:t.line,generatedColumn:t.column,originalLine:null!=r&&r.line,originalColumn:null!=r&&r.column,source:n,name:i})}
s.prototype.setSourceContent=function(e,t){var r=e
null!=this._sourceRoot&&(r=a.relative(this._sourceRoot,r))
if(null!=t){this._sourcesContents||(this._sourcesContents=Object.create(null))
this._sourcesContents[a.toSetString(r)]=t}else if(this._sourcesContents){delete this._sourcesContents[a.toSetString(r)]
0===Object.keys(this._sourcesContents).length&&(this._sourcesContents=null)}}
s.prototype.applySourceMap=function(e,t,r){var n=t
if(null==t){if(null==e.file)throw new Error('SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map\'s "file" property. Both were omitted.')
n=e.file}var o=this._sourceRoot
null!=o&&(n=a.relative(o,n))
var s=new i
var l=new i
this._mappings.unsortedForEach((function(t){if(t.source===n&&null!=t.originalLine){var i=e.originalPositionFor({line:t.originalLine,column:t.originalColumn})
if(null!=i.source){t.source=i.source
null!=r&&(t.source=a.join(r,t.source))
null!=o&&(t.source=a.relative(o,t.source))
t.originalLine=i.line
t.originalColumn=i.column
null!=i.name&&(t.name=i.name)}}var c=t.source
null==c||s.has(c)||s.add(c)
var d=t.name
null==d||l.has(d)||l.add(d)}),this)
this._sources=s
this._names=l
e.sources.forEach((function(t){var n=e.sourceContentFor(t)
if(null!=n){null!=r&&(t=a.join(r,t))
null!=o&&(t=a.relative(o,t))
this.setSourceContent(t,n)}}),this)}
s.prototype._validateMapping=function(e,t,r,n){if(t&&"number"!=typeof t.line&&"number"!=typeof t.column)throw new Error("original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values.")
if((!(e&&"line"in e&&"column"in e&&e.line>0&&e.column>=0)||t||r||n)&&!(e&&"line"in e&&"column"in e&&t&&"line"in t&&"column"in t&&e.line>0&&e.column>=0&&t.line>0&&t.column>=0&&r))throw new Error("Invalid mapping: "+JSON.stringify({generated:e,source:r,original:t,name:n}))}
s.prototype._serializeMappings=function(){var e=0
var t=1
var r=0
var i=0
var o=0
var s=0
var l=""
var c
var d
var u
var p
var m=this._mappings.toArray()
for(var f=0,h=m.length;f<h;f++){c=""
if((d=m[f]).generatedLine!==t){e=0
for(;d.generatedLine!==t;){c+=";"
t++}}else if(f>0){if(!a.compareByGeneratedPositionsInflated(d,m[f-1]))continue
c+=","}c+=n.encode(d.generatedColumn-e)
e=d.generatedColumn
if(null!=d.source){p=this._sources.indexOf(d.source)
c+=n.encode(p-s)
s=p
c+=n.encode(d.originalLine-1-i)
i=d.originalLine-1
c+=n.encode(d.originalColumn-r)
r=d.originalColumn
if(null!=d.name){u=this._names.indexOf(d.name)
c+=n.encode(u-o)
o=u}}l+=c}return l}
s.prototype._generateSourcesContent=function(e,t){return e.map((function(e){if(!this._sourcesContents)return null
null!=t&&(e=a.relative(t,e))
var r=a.toSetString(e)
return Object.prototype.hasOwnProperty.call(this._sourcesContents,r)?this._sourcesContents[r]:null}),this)}
s.prototype.toJSON=function(){var e={version:this._version,sources:this._sources.toArray(),names:this._names.toArray(),mappings:this._serializeMappings()}
null!=this._file&&(e.file=this._file)
null!=this._sourceRoot&&(e.sourceRoot=this._sourceRoot)
this._sourcesContents&&(e.sourcesContent=this._generateSourcesContent(e.sources,e.sourceRoot))
return e}
s.prototype.toString=function(){return JSON.stringify(this.toJSON())}
t.h=s},7837:(e,t)=>{t.getArg=function(e,t,r){if(t in e)return e[t]
if(3===arguments.length)return r
throw new Error('"'+t+'" is a required argument.')}
var r=/^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/
var n=/^data:.+\,.+$/
function a(e){var t=e.match(r)
return t?{scheme:t[1],auth:t[2],host:t[3],port:t[4],path:t[5]}:null}t.urlParse=a
function i(e){var t=""
e.scheme&&(t+=e.scheme+":")
t+="//"
e.auth&&(t+=e.auth+"@")
e.host&&(t+=e.host)
e.port&&(t+=":"+e.port)
e.path&&(t+=e.path)
return t}t.urlGenerate=i
function o(e){var r=e
var n=a(e)
if(n){if(!n.path)return e
r=n.path}var o=t.isAbsolute(r)
var s=r.split(/\/+/)
for(var l,c=0,d=s.length-1;d>=0;d--)if("."===(l=s[d]))s.splice(d,1)
else if(".."===l)c++
else if(c>0)if(""===l){s.splice(d+1,c)
c=0}else{s.splice(d,2)
c--}""===(r=s.join("/"))&&(r=o?"/":".")
if(n){n.path=r
return i(n)}return r}t.normalize=o
function s(e,t){""===e&&(e=".")
""===t&&(t=".")
var r=a(t)
var s=a(e)
s&&(e=s.path||"/")
if(r&&!r.scheme){s&&(r.scheme=s.scheme)
return i(r)}if(r||t.match(n))return t
if(s&&!s.host&&!s.path){s.host=t
return i(s)}var l="/"===t.charAt(0)?t:o(e.replace(/\/+$/,"")+"/"+t)
if(s){s.path=l
return i(s)}return l}t.join=s
t.isAbsolute=function(e){return"/"===e.charAt(0)||r.test(e)}
t.relative=function(e,t){""===e&&(e=".")
e=e.replace(/\/$/,"")
var r=0
for(;0!==t.indexOf(e+"/");){var n=e.lastIndexOf("/")
if(n<0)return t
if((e=e.slice(0,n)).match(/^([^\/]+:\/)?\/*$/))return t;++r}return Array(r+1).join("../")+t.substr(e.length+1)}
var l=!("__proto__"in Object.create(null))
function c(e){return e}t.toSetString=l?c:function(e){return d(e)?"$"+e:e}
t.fromSetString=l?c:function(e){return d(e)?e.slice(1):e}
function d(e){if(!e)return!1
var t=e.length
if(t<9)return!1
if(95!==e.charCodeAt(t-1)||95!==e.charCodeAt(t-2)||111!==e.charCodeAt(t-3)||116!==e.charCodeAt(t-4)||111!==e.charCodeAt(t-5)||114!==e.charCodeAt(t-6)||112!==e.charCodeAt(t-7)||95!==e.charCodeAt(t-8)||95!==e.charCodeAt(t-9))return!1
for(var r=t-10;r>=0;r--)if(36!==e.charCodeAt(r))return!1
return!0}t.compareByOriginalPositions=function(e,t,r){var n=u(e.source,t.source)
return 0!==n||0!=(n=e.originalLine-t.originalLine)||0!=(n=e.originalColumn-t.originalColumn)||r||0!=(n=e.generatedColumn-t.generatedColumn)||0!=(n=e.generatedLine-t.generatedLine)?n:u(e.name,t.name)}
t.compareByGeneratedPositionsDeflated=function(e,t,r){var n=e.generatedLine-t.generatedLine
return 0!==n||0!=(n=e.generatedColumn-t.generatedColumn)||r||0!==(n=u(e.source,t.source))||0!=(n=e.originalLine-t.originalLine)||0!=(n=e.originalColumn-t.originalColumn)?n:u(e.name,t.name)}
function u(e,t){return e===t?0:null===e?1:null===t?-1:e>t?1:-1}t.compareByGeneratedPositionsInflated=function(e,t){var r=e.generatedLine-t.generatedLine
return 0!==r||0!=(r=e.generatedColumn-t.generatedColumn)||0!==(r=u(e.source,t.source))||0!=(r=e.originalLine-t.originalLine)||0!=(r=e.originalColumn-t.originalColumn)?r:u(e.name,t.name)}
t.parseSourceMapInput=function(e){return JSON.parse(e.replace(/^\)]}'[^\n]*\n/,""))}
t.computeSourceURL=function(e,t,r){t=t||""
if(e){"/"!==e[e.length-1]&&"/"!==t[0]&&(e+="/")
t=e+t}if(r){var n=a(r)
if(!n)throw new Error("sourceMapURL could not be parsed")
if(n.path){var l=n.path.lastIndexOf("/")
l>=0&&(n.path=n.path.substring(0,l+1))}t=s(i(n),t)}return o(t)}},8819:function(e){
//! stable.js 0.1.8, https://github.com/Two-Screen/stable
//! © 2018 Angry Bytes and contributors. MIT licensed.
e.exports=function(){"use strict"
var e=function(e,r){return t(e.slice(),r)}
e.inplace=function(e,n){var a=t(e,n)
a!==e&&r(a,null,e.length,e)
return e}
function t(e,t){"function"!=typeof t&&(t=function(e,t){return String(e).localeCompare(t)})
var n=e.length
if(n<=1)return e
var a=new Array(n)
for(var i=1;i<n;i*=2){r(e,t,i,a)
var o=e
e=a
a=o}return e}var r=function(e,t,r,n){var a=e.length
var i=0
var o=2*r
var s,l,c
var d,u
for(s=0;s<a;s+=o){c=(l=s+r)+r
l>a&&(l=a)
c>a&&(c=a)
d=s
u=l
for(;;)if(d<l&&u<c)t(e[d],e[u])<=0?n[i++]=e[d++]:n[i++]=e[u++]
else if(d<l)n[i++]=e[d++]
else{if(!(u<c))break
n[i++]=e[u++]}}}
return e}()},5909:e=>{"use strict"
e.exports=JSON.parse('{"atrules":{"charset":{"prelude":"<string>"},"font-face":{"descriptors":{"unicode-range":{"comment":"replaces <unicode-range>, an old production name","syntax":"<urange>#"}}}},"properties":{"-moz-background-clip":{"comment":"deprecated syntax in old Firefox, https://developer.mozilla.org/en/docs/Web/CSS/background-clip","syntax":"padding | border"},"-moz-border-radius-bottomleft":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/border-bottom-left-radius","syntax":"<\'border-bottom-left-radius\'>"},"-moz-border-radius-bottomright":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/border-bottom-right-radius","syntax":"<\'border-bottom-right-radius\'>"},"-moz-border-radius-topleft":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/border-top-left-radius","syntax":"<\'border-top-left-radius\'>"},"-moz-border-radius-topright":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/border-bottom-right-radius","syntax":"<\'border-bottom-right-radius\'>"},"-moz-control-character-visibility":{"comment":"firefox specific keywords, https://bugzilla.mozilla.org/show_bug.cgi?id=947588","syntax":"visible | hidden"},"-moz-osx-font-smoothing":{"comment":"misssed old syntax https://developer.mozilla.org/en-US/docs/Web/CSS/font-smooth","syntax":"auto | grayscale"},"-moz-user-select":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/user-select","syntax":"none | text | all | -moz-none"},"-ms-flex-align":{"comment":"misssed old syntax implemented in IE, https://www.w3.org/TR/2012/WD-css3-flexbox-20120322/#flex-align","syntax":"start | end | center | baseline | stretch"},"-ms-flex-item-align":{"comment":"misssed old syntax implemented in IE, https://www.w3.org/TR/2012/WD-css3-flexbox-20120322/#flex-align","syntax":"auto | start | end | center | baseline | stretch"},"-ms-flex-line-pack":{"comment":"misssed old syntax implemented in IE, https://www.w3.org/TR/2012/WD-css3-flexbox-20120322/#flex-line-pack","syntax":"start | end | center | justify | distribute | stretch"},"-ms-flex-negative":{"comment":"misssed old syntax implemented in IE; TODO: find references for comfirmation","syntax":"<\'flex-shrink\'>"},"-ms-flex-pack":{"comment":"misssed old syntax implemented in IE, https://www.w3.org/TR/2012/WD-css3-flexbox-20120322/#flex-pack","syntax":"start | end | center | justify | distribute"},"-ms-flex-order":{"comment":"misssed old syntax implemented in IE; https://msdn.microsoft.com/en-us/library/jj127303(v=vs.85).aspx","syntax":"<integer>"},"-ms-flex-positive":{"comment":"misssed old syntax implemented in IE; TODO: find references for comfirmation","syntax":"<\'flex-grow\'>"},"-ms-flex-preferred-size":{"comment":"misssed old syntax implemented in IE; TODO: find references for comfirmation","syntax":"<\'flex-basis\'>"},"-ms-interpolation-mode":{"comment":"https://msdn.microsoft.com/en-us/library/ff521095(v=vs.85).aspx","syntax":"nearest-neighbor | bicubic"},"-ms-grid-column-align":{"comment":"add this property first since it uses as fallback for flexbox, https://msdn.microsoft.com/en-us/library/windows/apps/hh466338.aspx","syntax":"start | end | center | stretch"},"-ms-grid-row-align":{"comment":"add this property first since it uses as fallback for flexbox, https://msdn.microsoft.com/en-us/library/windows/apps/hh466348.aspx","syntax":"start | end | center | stretch"},"-ms-hyphenate-limit-last":{"comment":"misssed old syntax implemented in IE; https://www.w3.org/TR/css-text-4/#hyphenate-line-limits","syntax":"none | always | column | page | spread"},"-webkit-appearance":{"comment":"webkit specific keywords","references":["http://css-infos.net/property/-webkit-appearance"],"syntax":"none | button | button-bevel | caps-lock-indicator | caret | checkbox | default-button | inner-spin-button | listbox | listitem | media-controls-background | media-controls-fullscreen-background | media-current-time-display | media-enter-fullscreen-button | media-exit-fullscreen-button | media-fullscreen-button | media-mute-button | media-overlay-play-button | media-play-button | media-seek-back-button | media-seek-forward-button | media-slider | media-sliderthumb | media-time-remaining-display | media-toggle-closed-captions-button | media-volume-slider | media-volume-slider-container | media-volume-sliderthumb | menulist | menulist-button | menulist-text | menulist-textfield | meter | progress-bar | progress-bar-value | push-button | radio | scrollbarbutton-down | scrollbarbutton-left | scrollbarbutton-right | scrollbarbutton-up | scrollbargripper-horizontal | scrollbargripper-vertical | scrollbarthumb-horizontal | scrollbarthumb-vertical | scrollbartrack-horizontal | scrollbartrack-vertical | searchfield | searchfield-cancel-button | searchfield-decoration | searchfield-results-button | searchfield-results-decoration | slider-horizontal | slider-vertical | sliderthumb-horizontal | sliderthumb-vertical | square-button | textarea | textfield | -apple-pay-button"},"-webkit-background-clip":{"comment":"https://developer.mozilla.org/en/docs/Web/CSS/background-clip","syntax":"[ <box> | border | padding | content | text ]#"},"-webkit-column-break-after":{"comment":"added, http://help.dottoro.com/lcrthhhv.php","syntax":"always | auto | avoid"},"-webkit-column-break-before":{"comment":"added, http://help.dottoro.com/lcxquvkf.php","syntax":"always | auto | avoid"},"-webkit-column-break-inside":{"comment":"added, http://help.dottoro.com/lclhnthl.php","syntax":"always | auto | avoid"},"-webkit-font-smoothing":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/font-smooth","syntax":"auto | none | antialiased | subpixel-antialiased"},"-webkit-mask-box-image":{"comment":"missed; https://developer.mozilla.org/en-US/docs/Web/CSS/-webkit-mask-box-image","syntax":"[ <url> | <gradient> | none ] [ <length-percentage>{4} <-webkit-mask-box-repeat>{2} ]?"},"-webkit-print-color-adjust":{"comment":"missed","references":["https://developer.mozilla.org/en/docs/Web/CSS/-webkit-print-color-adjust"],"syntax":"economy | exact"},"-webkit-text-security":{"comment":"missed; http://help.dottoro.com/lcbkewgt.php","syntax":"none | circle | disc | square"},"-webkit-user-drag":{"comment":"missed; http://help.dottoro.com/lcbixvwm.php","syntax":"none | element | auto"},"-webkit-user-select":{"comment":"auto is supported by old webkit, https://developer.mozilla.org/en-US/docs/Web/CSS/user-select","syntax":"auto | none | text | all"},"alignment-baseline":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/text.html#AlignmentBaselineProperty"],"syntax":"auto | baseline | before-edge | text-before-edge | middle | central | after-edge | text-after-edge | ideographic | alphabetic | hanging | mathematical"},"baseline-shift":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/text.html#BaselineShiftProperty"],"syntax":"baseline | sub | super | <svg-length>"},"behavior":{"comment":"added old IE property https://msdn.microsoft.com/en-us/library/ms530723(v=vs.85).aspx","syntax":"<url>+"},"clip-rule":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/masking.html#ClipRuleProperty"],"syntax":"nonzero | evenodd"},"cue":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<\'cue-before\'> <\'cue-after\'>?"},"cue-after":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<url> <decibel>? | none"},"cue-before":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<url> <decibel>? | none"},"cursor":{"comment":"added legacy keywords: hand, -webkit-grab. -webkit-grabbing, -webkit-zoom-in, -webkit-zoom-out, -moz-grab, -moz-grabbing, -moz-zoom-in, -moz-zoom-out","references":["https://www.sitepoint.com/css3-cursor-styles/"],"syntax":"[ [ <url> [ <x> <y> ]? , ]* [ auto | default | none | context-menu | help | pointer | progress | wait | cell | crosshair | text | vertical-text | alias | copy | move | no-drop | not-allowed | e-resize | n-resize | ne-resize | nw-resize | s-resize | se-resize | sw-resize | w-resize | ew-resize | ns-resize | nesw-resize | nwse-resize | col-resize | row-resize | all-scroll | zoom-in | zoom-out | grab | grabbing | hand | -webkit-grab | -webkit-grabbing | -webkit-zoom-in | -webkit-zoom-out | -moz-grab | -moz-grabbing | -moz-zoom-in | -moz-zoom-out ] ]"},"display":{"comment":"extended with -ms-flexbox","syntax":"| <-non-standard-display>"},"position":{"comment":"extended with -webkit-sticky","syntax":"| -webkit-sticky"},"dominant-baseline":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/text.html#DominantBaselineProperty"],"syntax":"auto | use-script | no-change | reset-size | ideographic | alphabetic | hanging | mathematical | central | middle | text-after-edge | text-before-edge"},"image-rendering":{"comment":"extended with <-non-standard-image-rendering>, added SVG keywords optimizeSpeed and optimizeQuality","references":["https://developer.mozilla.org/en/docs/Web/CSS/image-rendering","https://www.w3.org/TR/SVG/painting.html#ImageRenderingProperty"],"syntax":"| optimizeSpeed | optimizeQuality | <-non-standard-image-rendering>"},"fill":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#FillProperty"],"syntax":"<paint>"},"fill-opacity":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#FillProperty"],"syntax":"<number-zero-one>"},"fill-rule":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#FillProperty"],"syntax":"nonzero | evenodd"},"filter":{"comment":"extend with IE legacy syntaxes","syntax":"| <-ms-filter-function-list>"},"glyph-orientation-horizontal":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/text.html#GlyphOrientationHorizontalProperty"],"syntax":"<angle>"},"glyph-orientation-vertical":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/text.html#GlyphOrientationVerticalProperty"],"syntax":"<angle>"},"kerning":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/text.html#KerningProperty"],"syntax":"auto | <svg-length>"},"letter-spacing":{"comment":"fix syntax <length> -> <length-percentage>","references":["https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/letter-spacing"],"syntax":"normal | <length-percentage>"},"marker":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#MarkerProperties"],"syntax":"none | <url>"},"marker-end":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#MarkerProperties"],"syntax":"none | <url>"},"marker-mid":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#MarkerProperties"],"syntax":"none | <url>"},"marker-start":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#MarkerProperties"],"syntax":"none | <url>"},"max-width":{"comment":"fix auto -> none (https://github.com/mdn/data/pull/431); extend by non-standard width keywords https://developer.mozilla.org/en-US/docs/Web/CSS/max-width","syntax":"none | <length-percentage> | min-content | max-content | fit-content(<length-percentage>) | <-non-standard-width>"},"min-width":{"comment":"extend by non-standard width keywords https://developer.mozilla.org/en-US/docs/Web/CSS/width","syntax":"auto | <length-percentage> | min-content | max-content | fit-content(<length-percentage>) | <-non-standard-width>"},"overflow":{"comment":"extend by vendor keywords https://developer.mozilla.org/en-US/docs/Web/CSS/overflow","syntax":"| <-non-standard-overflow>"},"pause":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<\'pause-before\'> <\'pause-after\'>?"},"pause-after":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<time> | none | x-weak | weak | medium | strong | x-strong"},"pause-before":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<time> | none | x-weak | weak | medium | strong | x-strong"},"rest":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<\'rest-before\'> <\'rest-after\'>?"},"rest-after":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<time> | none | x-weak | weak | medium | strong | x-strong"},"rest-before":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<time> | none | x-weak | weak | medium | strong | x-strong"},"shape-rendering":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#ShapeRenderingPropert"],"syntax":"auto | optimizeSpeed | crispEdges | geometricPrecision"},"src":{"comment":"added @font-face\'s src property https://developer.mozilla.org/en-US/docs/Web/CSS/@font-face/src","syntax":"[ <url> [ format( <string># ) ]? | local( <family-name> ) ]#"},"speak":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"auto | none | normal"},"speak-as":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"normal | spell-out || digits || [ literal-punctuation | no-punctuation ]"},"stroke":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#StrokeProperties"],"syntax":"<paint>"},"stroke-dasharray":{"comment":"added SVG property; a list of comma and/or white space separated <length>s and <percentage>s","references":["https://www.w3.org/TR/SVG/painting.html#StrokeProperties"],"syntax":"none | [ <svg-length>+ ]#"},"stroke-dashoffset":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#StrokeProperties"],"syntax":"<svg-length>"},"stroke-linecap":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#StrokeProperties"],"syntax":"butt | round | square"},"stroke-linejoin":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#StrokeProperties"],"syntax":"miter | round | bevel"},"stroke-miterlimit":{"comment":"added SVG property (<miterlimit> = <number-one-or-greater>) ","references":["https://www.w3.org/TR/SVG/painting.html#StrokeProperties"],"syntax":"<number-one-or-greater>"},"stroke-opacity":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#StrokeProperties"],"syntax":"<number-zero-one>"},"stroke-width":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/painting.html#StrokeProperties"],"syntax":"<svg-length>"},"text-anchor":{"comment":"added SVG property","references":["https://www.w3.org/TR/SVG/text.html#TextAlignmentProperties"],"syntax":"start | middle | end"},"unicode-bidi":{"comment":"added prefixed keywords https://developer.mozilla.org/en-US/docs/Web/CSS/unicode-bidi","syntax":"| -moz-isolate | -moz-isolate-override | -moz-plaintext | -webkit-isolate | -webkit-isolate-override | -webkit-plaintext"},"unicode-range":{"comment":"added missed property https://developer.mozilla.org/en-US/docs/Web/CSS/%40font-face/unicode-range","syntax":"<urange>#"},"voice-balance":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<number> | left | center | right | leftwards | rightwards"},"voice-duration":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"auto | <time>"},"voice-family":{"comment":"<name> -> <family-name>, https://www.w3.org/TR/css3-speech/#property-index","syntax":"[ [ <family-name> | <generic-voice> ] , ]* [ <family-name> | <generic-voice> ] | preserve"},"voice-pitch":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<frequency> && absolute | [ [ x-low | low | medium | high | x-high ] || [ <frequency> | <semitones> | <percentage> ] ]"},"voice-range":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"<frequency> && absolute | [ [ x-low | low | medium | high | x-high ] || [ <frequency> | <semitones> | <percentage> ] ]"},"voice-rate":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"[ normal | x-slow | slow | medium | fast | x-fast ] || <percentage>"},"voice-stress":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"normal | strong | moderate | none | reduced"},"voice-volume":{"comment":"https://www.w3.org/TR/css3-speech/#property-index","syntax":"silent | [ [ x-soft | soft | medium | loud | x-loud ] || <decibel> ]"},"writing-mode":{"comment":"extend with SVG keywords","syntax":"| <svg-writing-mode>"}},"syntaxes":{"-legacy-gradient":{"comment":"added collection of legacy gradient syntaxes","syntax":"<-webkit-gradient()> | <-legacy-linear-gradient> | <-legacy-repeating-linear-gradient> | <-legacy-radial-gradient> | <-legacy-repeating-radial-gradient>"},"-legacy-linear-gradient":{"comment":"like standard syntax but w/o `to` keyword https://developer.mozilla.org/en-US/docs/Web/CSS/linear-gradient","syntax":"-moz-linear-gradient( <-legacy-linear-gradient-arguments> ) | -webkit-linear-gradient( <-legacy-linear-gradient-arguments> ) | -o-linear-gradient( <-legacy-linear-gradient-arguments> )"},"-legacy-repeating-linear-gradient":{"comment":"like standard syntax but w/o `to` keyword https://developer.mozilla.org/en-US/docs/Web/CSS/linear-gradient","syntax":"-moz-repeating-linear-gradient( <-legacy-linear-gradient-arguments> ) | -webkit-repeating-linear-gradient( <-legacy-linear-gradient-arguments> ) | -o-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )"},"-legacy-linear-gradient-arguments":{"comment":"like standard syntax but w/o `to` keyword https://developer.mozilla.org/en-US/docs/Web/CSS/linear-gradient","syntax":"[ <angle> | <side-or-corner> ]? , <color-stop-list>"},"-legacy-radial-gradient":{"comment":"deprecated syntax that implemented by some browsers https://www.w3.org/TR/2011/WD-css3-images-20110908/#radial-gradients","syntax":"-moz-radial-gradient( <-legacy-radial-gradient-arguments> ) | -webkit-radial-gradient( <-legacy-radial-gradient-arguments> ) | -o-radial-gradient( <-legacy-radial-gradient-arguments> )"},"-legacy-repeating-radial-gradient":{"comment":"deprecated syntax that implemented by some browsers https://www.w3.org/TR/2011/WD-css3-images-20110908/#radial-gradients","syntax":"-moz-repeating-radial-gradient( <-legacy-radial-gradient-arguments> ) | -webkit-repeating-radial-gradient( <-legacy-radial-gradient-arguments> ) | -o-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )"},"-legacy-radial-gradient-arguments":{"comment":"deprecated syntax that implemented by some browsers https://www.w3.org/TR/2011/WD-css3-images-20110908/#radial-gradients","syntax":"[ <position> , ]? [ [ [ <-legacy-radial-gradient-shape> || <-legacy-radial-gradient-size> ] | [ <length> | <percentage> ]{2} ] , ]? <color-stop-list>"},"-legacy-radial-gradient-size":{"comment":"before a standard it contains 2 extra keywords (`contain` and `cover`) https://www.w3.org/TR/2011/WD-css3-images-20110908/#ltsize","syntax":"closest-side | closest-corner | farthest-side | farthest-corner | contain | cover"},"-legacy-radial-gradient-shape":{"comment":"define to double sure it doesn\'t extends in future https://www.w3.org/TR/2011/WD-css3-images-20110908/#ltshape","syntax":"circle | ellipse"},"-non-standard-font":{"comment":"non standard fonts","references":["https://webkit.org/blog/3709/using-the-system-font-in-web-content/"],"syntax":"-apple-system-body | -apple-system-headline | -apple-system-subheadline | -apple-system-caption1 | -apple-system-caption2 | -apple-system-footnote | -apple-system-short-body | -apple-system-short-headline | -apple-system-short-subheadline | -apple-system-short-caption1 | -apple-system-short-footnote | -apple-system-tall-body"},"-non-standard-color":{"comment":"non standard colors","references":["http://cssdot.ru/%D0%A1%D0%BF%D1%80%D0%B0%D0%B2%D0%BE%D1%87%D0%BD%D0%B8%D0%BA_CSS/color-i305.html","https://developer.mozilla.org/en-US/docs/Web/CSS/color_value#Mozilla_Color_Preference_Extensions"],"syntax":"-moz-ButtonDefault | -moz-ButtonHoverFace | -moz-ButtonHoverText | -moz-CellHighlight | -moz-CellHighlightText | -moz-Combobox | -moz-ComboboxText | -moz-Dialog | -moz-DialogText | -moz-dragtargetzone | -moz-EvenTreeRow | -moz-Field | -moz-FieldText | -moz-html-CellHighlight | -moz-html-CellHighlightText | -moz-mac-accentdarkestshadow | -moz-mac-accentdarkshadow | -moz-mac-accentface | -moz-mac-accentlightesthighlight | -moz-mac-accentlightshadow | -moz-mac-accentregularhighlight | -moz-mac-accentregularshadow | -moz-mac-chrome-active | -moz-mac-chrome-inactive | -moz-mac-focusring | -moz-mac-menuselect | -moz-mac-menushadow | -moz-mac-menutextselect | -moz-MenuHover | -moz-MenuHoverText | -moz-MenuBarText | -moz-MenuBarHoverText | -moz-nativehyperlinktext | -moz-OddTreeRow | -moz-win-communicationstext | -moz-win-mediatext | -moz-activehyperlinktext | -moz-default-background-color | -moz-default-color | -moz-hyperlinktext | -moz-visitedhyperlinktext | -webkit-activelink | -webkit-focus-ring-color | -webkit-link | -webkit-text"},"-non-standard-image-rendering":{"comment":"non-standard keywords http://phrogz.net/tmp/canvas_image_zoom.html","syntax":"optimize-contrast | -moz-crisp-edges | -o-crisp-edges | -webkit-optimize-contrast"},"-non-standard-overflow":{"comment":"non-standard keywords https://developer.mozilla.org/en-US/docs/Web/CSS/overflow","syntax":"-moz-scrollbars-none | -moz-scrollbars-horizontal | -moz-scrollbars-vertical | -moz-hidden-unscrollable"},"-non-standard-width":{"comment":"non-standard keywords https://developer.mozilla.org/en-US/docs/Web/CSS/width","syntax":"fill-available | min-intrinsic | intrinsic | -moz-available | -moz-fit-content | -moz-min-content | -moz-max-content | -webkit-min-content | -webkit-max-content"},"-webkit-gradient()":{"comment":"first Apple proposal gradient syntax https://webkit.org/blog/175/introducing-css-gradients/ - TODO: simplify when after match algorithm improvement ( [, point, radius | , point] -> [, radius]? , point )","syntax":"-webkit-gradient( <-webkit-gradient-type>, <-webkit-gradient-point> [, <-webkit-gradient-point> | , <-webkit-gradient-radius>, <-webkit-gradient-point> ] [, <-webkit-gradient-radius>]? [, <-webkit-gradient-color-stop>]* )"},"-webkit-gradient-color-stop":{"comment":"first Apple proposal gradient syntax https://webkit.org/blog/175/introducing-css-gradients/","syntax":"from( <color> ) | color-stop( [ <number-zero-one> | <percentage> ] , <color> ) | to( <color> )"},"-webkit-gradient-point":{"comment":"first Apple proposal gradient syntax https://webkit.org/blog/175/introducing-css-gradients/","syntax":"[ left | center | right | <length-percentage> ] [ top | center | bottom | <length-percentage> ]"},"-webkit-gradient-radius":{"comment":"first Apple proposal gradient syntax https://webkit.org/blog/175/introducing-css-gradients/","syntax":"<length> | <percentage>"},"-webkit-gradient-type":{"comment":"first Apple proposal gradient syntax https://webkit.org/blog/175/introducing-css-gradients/","syntax":"linear | radial"},"-webkit-mask-box-repeat":{"comment":"missed; https://developer.mozilla.org/en-US/docs/Web/CSS/-webkit-mask-box-image","syntax":"repeat | stretch | round"},"-webkit-mask-clip-style":{"comment":"missed; there is no enough information about `-webkit-mask-clip` property, but looks like all those keywords are working","syntax":"border | border-box | padding | padding-box | content | content-box | text"},"-ms-filter-function-list":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/-ms-filter","syntax":"<-ms-filter-function>+"},"-ms-filter-function":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/-ms-filter","syntax":"<-ms-filter-function-progid> | <-ms-filter-function-legacy>"},"-ms-filter-function-progid":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/-ms-filter","syntax":"\'progid:\' [ <ident-token> \'.\' ]* [ <ident-token> | <function-token> <any-value>? ) ]"},"-ms-filter-function-legacy":{"comment":"https://developer.mozilla.org/en-US/docs/Web/CSS/-ms-filter","syntax":"<ident-token> | <function-token> <any-value>? )"},"-ms-filter":{"syntax":"<string>"},"age":{"comment":"https://www.w3.org/TR/css3-speech/#voice-family","syntax":"child | young | old"},"attr-name":{"syntax":"<wq-name>"},"attr-fallback":{"syntax":"<any-value>"},"border-radius":{"comment":"missed, https://drafts.csswg.org/css-backgrounds-3/#the-border-radius","syntax":"<length-percentage>{1,2}"},"bottom":{"comment":"missed; not sure we should add it, but no others except `shape` is using it so it\'s ok for now; https://drafts.fxtf.org/css-masking-1/#funcdef-clip-rect","syntax":"<length> | auto"},"content-list":{"comment":"missed -> https://drafts.csswg.org/css-content/#typedef-content-list (document-url, <target> and leader() is omitted util stabilization)","syntax":"[ <string> | contents | <image> | <quote> | <target> | <leader()> | <attr()> | counter( <ident>, <\'list-style-type\'>? ) ]+"},"element()":{"comment":"https://drafts.csswg.org/css-gcpm/#element-syntax & https://drafts.csswg.org/css-images-4/#element-notation","syntax":"element( <custom-ident> , [ first | start | last | first-except ]? ) | element( <id-selector> )"},"generic-voice":{"comment":"https://www.w3.org/TR/css3-speech/#voice-family","syntax":"[ <age>? <gender> <integer>? ]"},"gender":{"comment":"https://www.w3.org/TR/css3-speech/#voice-family","syntax":"male | female | neutral"},"generic-family":{"comment":"added -apple-system","references":["https://webkit.org/blog/3709/using-the-system-font-in-web-content/"],"syntax":"| -apple-system"},"gradient":{"comment":"added legacy syntaxes support","syntax":"| <-legacy-gradient>"},"left":{"comment":"missed; not sure we should add it, but no others except `shape` is using it so it\'s ok for now; https://drafts.fxtf.org/css-masking-1/#funcdef-clip-rect","syntax":"<length> | auto"},"mask-image":{"comment":"missed; https://drafts.fxtf.org/css-masking-1/#the-mask-image","syntax":"<mask-reference>#"},"name-repeat":{"comment":"missed, and looks like obsolete, keep it as is since other property syntaxes should be changed too; https://www.w3.org/TR/2015/WD-css-grid-1-20150917/#typedef-name-repeat","syntax":"repeat( [ <positive-integer> | auto-fill ], <line-names>+)"},"named-color":{"comment":"added non standard color names","syntax":"| <-non-standard-color>"},"paint":{"comment":"used by SVG https://www.w3.org/TR/SVG/painting.html#SpecifyingPaint","syntax":"none | <color> | <url> [ none | <color> ]? | context-fill | context-stroke"},"page-size":{"comment":"https://www.w3.org/TR/css-page-3/#typedef-page-size-page-size","syntax":"A5 | A4 | A3 | B5 | B4 | JIS-B5 | JIS-B4 | letter | legal | ledger"},"ratio":{"comment":"missed, https://drafts.csswg.org/mediaqueries-4/#typedef-ratio","syntax":"<integer> / <integer>"},"right":{"comment":"missed; not sure we should add it, but no others except `shape` is using it so it\'s ok for now; https://drafts.fxtf.org/css-masking-1/#funcdef-clip-rect","syntax":"<length> | auto"},"shape":{"comment":"missed spaces in function body and add backwards compatible syntax","syntax":"rect( <top>, <right>, <bottom>, <left> ) | rect( <top> <right> <bottom> <left> )"},"svg-length":{"comment":"All coordinates and lengths in SVG can be specified with or without a unit identifier","references":["https://www.w3.org/TR/SVG11/coords.html#Units"],"syntax":"<percentage> | <length> | <number>"},"svg-writing-mode":{"comment":"SVG specific keywords (deprecated for CSS)","references":["https://developer.mozilla.org/en/docs/Web/CSS/writing-mode","https://www.w3.org/TR/SVG/text.html#WritingModeProperty"],"syntax":"lr-tb | rl-tb | tb-rl | lr | rl | tb"},"top":{"comment":"missed; not sure we should add it, but no others except `shape` is using it so it\'s ok for now; https://drafts.fxtf.org/css-masking-1/#funcdef-clip-rect","syntax":"<length> | auto"},"track-group":{"comment":"used by old grid-columns and grid-rows syntax v0","syntax":"\'(\' [ <string>* <track-minmax> <string>* ]+ \')\' [ \'[\' <positive-integer> \']\' ]? | <track-minmax>"},"track-list-v0":{"comment":"used by old grid-columns and grid-rows syntax v0","syntax":"[ <string>* <track-group> <string>* ]+ | none"},"track-minmax":{"comment":"used by old grid-columns and grid-rows syntax v0","syntax":"minmax( <track-breadth> , <track-breadth> ) | auto | <track-breadth> | fit-content"},"x":{"comment":"missed; not sure we should add it, but no others except `cursor` is using it so it\'s ok for now; https://drafts.csswg.org/css-ui-3/#cursor","syntax":"<number>"},"y":{"comment":"missed; not sure we should add it, but no others except `cursor` is using so it\'s ok for now; https://drafts.csswg.org/css-ui-3/#cursor","syntax":"<number>"},"declaration":{"comment":"missed, restored by https://drafts.csswg.org/css-syntax","syntax":"<ident-token> : <declaration-value>? [ \'!\' important ]?"},"declaration-list":{"comment":"missed, restored by https://drafts.csswg.org/css-syntax","syntax":"[ <declaration>? \';\' ]* <declaration>?"},"url":{"comment":"https://drafts.csswg.org/css-values-4/#urls","syntax":"url( <string> <url-modifier>* ) | <url-token>"},"url-modifier":{"comment":"https://drafts.csswg.org/css-values-4/#typedef-url-modifier","syntax":"<ident> | <function-token> <any-value> )"},"number-zero-one":{"syntax":"<number [0,1]>"},"number-one-or-greater":{"syntax":"<number [1,∞]>"},"positive-integer":{"syntax":"<integer [0,∞]>"},"-non-standard-display":{"syntax":"-ms-inline-flexbox | -ms-grid | -ms-inline-grid | -webkit-flex | -webkit-inline-flex | -webkit-box | -webkit-inline-box | -moz-inline-stack | -moz-box | -moz-inline-box"}}}')},4589:e=>{"use strict"
e.exports=JSON.parse('{"0":65533,"128":8364,"130":8218,"131":402,"132":8222,"133":8230,"134":8224,"135":8225,"136":710,"137":8240,"138":352,"139":8249,"140":338,"142":381,"145":8216,"146":8217,"147":8220,"148":8221,"149":8226,"150":8211,"151":8212,"152":732,"153":8482,"154":353,"155":8250,"156":339,"158":382,"159":376}')},4007:e=>{"use strict"
e.exports=JSON.parse('{"Aacute":"Á","aacute":"á","Abreve":"Ă","abreve":"ă","ac":"∾","acd":"∿","acE":"∾̳","Acirc":"Â","acirc":"â","acute":"´","Acy":"А","acy":"а","AElig":"Æ","aelig":"æ","af":"⁡","Afr":"𝔄","afr":"𝔞","Agrave":"À","agrave":"à","alefsym":"ℵ","aleph":"ℵ","Alpha":"Α","alpha":"α","Amacr":"Ā","amacr":"ā","amalg":"⨿","amp":"&","AMP":"&","andand":"⩕","And":"⩓","and":"∧","andd":"⩜","andslope":"⩘","andv":"⩚","ang":"∠","ange":"⦤","angle":"∠","angmsdaa":"⦨","angmsdab":"⦩","angmsdac":"⦪","angmsdad":"⦫","angmsdae":"⦬","angmsdaf":"⦭","angmsdag":"⦮","angmsdah":"⦯","angmsd":"∡","angrt":"∟","angrtvb":"⊾","angrtvbd":"⦝","angsph":"∢","angst":"Å","angzarr":"⍼","Aogon":"Ą","aogon":"ą","Aopf":"𝔸","aopf":"𝕒","apacir":"⩯","ap":"≈","apE":"⩰","ape":"≊","apid":"≋","apos":"\'","ApplyFunction":"⁡","approx":"≈","approxeq":"≊","Aring":"Å","aring":"å","Ascr":"𝒜","ascr":"𝒶","Assign":"≔","ast":"*","asymp":"≈","asympeq":"≍","Atilde":"Ã","atilde":"ã","Auml":"Ä","auml":"ä","awconint":"∳","awint":"⨑","backcong":"≌","backepsilon":"϶","backprime":"‵","backsim":"∽","backsimeq":"⋍","Backslash":"∖","Barv":"⫧","barvee":"⊽","barwed":"⌅","Barwed":"⌆","barwedge":"⌅","bbrk":"⎵","bbrktbrk":"⎶","bcong":"≌","Bcy":"Б","bcy":"б","bdquo":"„","becaus":"∵","because":"∵","Because":"∵","bemptyv":"⦰","bepsi":"϶","bernou":"ℬ","Bernoullis":"ℬ","Beta":"Β","beta":"β","beth":"ℶ","between":"≬","Bfr":"𝔅","bfr":"𝔟","bigcap":"⋂","bigcirc":"◯","bigcup":"⋃","bigodot":"⨀","bigoplus":"⨁","bigotimes":"⨂","bigsqcup":"⨆","bigstar":"★","bigtriangledown":"▽","bigtriangleup":"△","biguplus":"⨄","bigvee":"⋁","bigwedge":"⋀","bkarow":"⤍","blacklozenge":"⧫","blacksquare":"▪","blacktriangle":"▴","blacktriangledown":"▾","blacktriangleleft":"◂","blacktriangleright":"▸","blank":"␣","blk12":"▒","blk14":"░","blk34":"▓","block":"█","bne":"=⃥","bnequiv":"≡⃥","bNot":"⫭","bnot":"⌐","Bopf":"𝔹","bopf":"𝕓","bot":"⊥","bottom":"⊥","bowtie":"⋈","boxbox":"⧉","boxdl":"┐","boxdL":"╕","boxDl":"╖","boxDL":"╗","boxdr":"┌","boxdR":"╒","boxDr":"╓","boxDR":"╔","boxh":"─","boxH":"═","boxhd":"┬","boxHd":"╤","boxhD":"╥","boxHD":"╦","boxhu":"┴","boxHu":"╧","boxhU":"╨","boxHU":"╩","boxminus":"⊟","boxplus":"⊞","boxtimes":"⊠","boxul":"┘","boxuL":"╛","boxUl":"╜","boxUL":"╝","boxur":"└","boxuR":"╘","boxUr":"╙","boxUR":"╚","boxv":"│","boxV":"║","boxvh":"┼","boxvH":"╪","boxVh":"╫","boxVH":"╬","boxvl":"┤","boxvL":"╡","boxVl":"╢","boxVL":"╣","boxvr":"├","boxvR":"╞","boxVr":"╟","boxVR":"╠","bprime":"‵","breve":"˘","Breve":"˘","brvbar":"¦","bscr":"𝒷","Bscr":"ℬ","bsemi":"⁏","bsim":"∽","bsime":"⋍","bsolb":"⧅","bsol":"\\\\","bsolhsub":"⟈","bull":"•","bullet":"•","bump":"≎","bumpE":"⪮","bumpe":"≏","Bumpeq":"≎","bumpeq":"≏","Cacute":"Ć","cacute":"ć","capand":"⩄","capbrcup":"⩉","capcap":"⩋","cap":"∩","Cap":"⋒","capcup":"⩇","capdot":"⩀","CapitalDifferentialD":"ⅅ","caps":"∩︀","caret":"⁁","caron":"ˇ","Cayleys":"ℭ","ccaps":"⩍","Ccaron":"Č","ccaron":"č","Ccedil":"Ç","ccedil":"ç","Ccirc":"Ĉ","ccirc":"ĉ","Cconint":"∰","ccups":"⩌","ccupssm":"⩐","Cdot":"Ċ","cdot":"ċ","cedil":"¸","Cedilla":"¸","cemptyv":"⦲","cent":"¢","centerdot":"·","CenterDot":"·","cfr":"𝔠","Cfr":"ℭ","CHcy":"Ч","chcy":"ч","check":"✓","checkmark":"✓","Chi":"Χ","chi":"χ","circ":"ˆ","circeq":"≗","circlearrowleft":"↺","circlearrowright":"↻","circledast":"⊛","circledcirc":"⊚","circleddash":"⊝","CircleDot":"⊙","circledR":"®","circledS":"Ⓢ","CircleMinus":"⊖","CirclePlus":"⊕","CircleTimes":"⊗","cir":"○","cirE":"⧃","cire":"≗","cirfnint":"⨐","cirmid":"⫯","cirscir":"⧂","ClockwiseContourIntegral":"∲","CloseCurlyDoubleQuote":"”","CloseCurlyQuote":"’","clubs":"♣","clubsuit":"♣","colon":":","Colon":"∷","Colone":"⩴","colone":"≔","coloneq":"≔","comma":",","commat":"@","comp":"∁","compfn":"∘","complement":"∁","complexes":"ℂ","cong":"≅","congdot":"⩭","Congruent":"≡","conint":"∮","Conint":"∯","ContourIntegral":"∮","copf":"𝕔","Copf":"ℂ","coprod":"∐","Coproduct":"∐","copy":"©","COPY":"©","copysr":"℗","CounterClockwiseContourIntegral":"∳","crarr":"↵","cross":"✗","Cross":"⨯","Cscr":"𝒞","cscr":"𝒸","csub":"⫏","csube":"⫑","csup":"⫐","csupe":"⫒","ctdot":"⋯","cudarrl":"⤸","cudarrr":"⤵","cuepr":"⋞","cuesc":"⋟","cularr":"↶","cularrp":"⤽","cupbrcap":"⩈","cupcap":"⩆","CupCap":"≍","cup":"∪","Cup":"⋓","cupcup":"⩊","cupdot":"⊍","cupor":"⩅","cups":"∪︀","curarr":"↷","curarrm":"⤼","curlyeqprec":"⋞","curlyeqsucc":"⋟","curlyvee":"⋎","curlywedge":"⋏","curren":"¤","curvearrowleft":"↶","curvearrowright":"↷","cuvee":"⋎","cuwed":"⋏","cwconint":"∲","cwint":"∱","cylcty":"⌭","dagger":"†","Dagger":"‡","daleth":"ℸ","darr":"↓","Darr":"↡","dArr":"⇓","dash":"‐","Dashv":"⫤","dashv":"⊣","dbkarow":"⤏","dblac":"˝","Dcaron":"Ď","dcaron":"ď","Dcy":"Д","dcy":"д","ddagger":"‡","ddarr":"⇊","DD":"ⅅ","dd":"ⅆ","DDotrahd":"⤑","ddotseq":"⩷","deg":"°","Del":"∇","Delta":"Δ","delta":"δ","demptyv":"⦱","dfisht":"⥿","Dfr":"𝔇","dfr":"𝔡","dHar":"⥥","dharl":"⇃","dharr":"⇂","DiacriticalAcute":"´","DiacriticalDot":"˙","DiacriticalDoubleAcute":"˝","DiacriticalGrave":"`","DiacriticalTilde":"˜","diam":"⋄","diamond":"⋄","Diamond":"⋄","diamondsuit":"♦","diams":"♦","die":"¨","DifferentialD":"ⅆ","digamma":"ϝ","disin":"⋲","div":"÷","divide":"÷","divideontimes":"⋇","divonx":"⋇","DJcy":"Ђ","djcy":"ђ","dlcorn":"⌞","dlcrop":"⌍","dollar":"$","Dopf":"𝔻","dopf":"𝕕","Dot":"¨","dot":"˙","DotDot":"⃜","doteq":"≐","doteqdot":"≑","DotEqual":"≐","dotminus":"∸","dotplus":"∔","dotsquare":"⊡","doublebarwedge":"⌆","DoubleContourIntegral":"∯","DoubleDot":"¨","DoubleDownArrow":"⇓","DoubleLeftArrow":"⇐","DoubleLeftRightArrow":"⇔","DoubleLeftTee":"⫤","DoubleLongLeftArrow":"⟸","DoubleLongLeftRightArrow":"⟺","DoubleLongRightArrow":"⟹","DoubleRightArrow":"⇒","DoubleRightTee":"⊨","DoubleUpArrow":"⇑","DoubleUpDownArrow":"⇕","DoubleVerticalBar":"∥","DownArrowBar":"⤓","downarrow":"↓","DownArrow":"↓","Downarrow":"⇓","DownArrowUpArrow":"⇵","DownBreve":"̑","downdownarrows":"⇊","downharpoonleft":"⇃","downharpoonright":"⇂","DownLeftRightVector":"⥐","DownLeftTeeVector":"⥞","DownLeftVectorBar":"⥖","DownLeftVector":"↽","DownRightTeeVector":"⥟","DownRightVectorBar":"⥗","DownRightVector":"⇁","DownTeeArrow":"↧","DownTee":"⊤","drbkarow":"⤐","drcorn":"⌟","drcrop":"⌌","Dscr":"𝒟","dscr":"𝒹","DScy":"Ѕ","dscy":"ѕ","dsol":"⧶","Dstrok":"Đ","dstrok":"đ","dtdot":"⋱","dtri":"▿","dtrif":"▾","duarr":"⇵","duhar":"⥯","dwangle":"⦦","DZcy":"Џ","dzcy":"џ","dzigrarr":"⟿","Eacute":"É","eacute":"é","easter":"⩮","Ecaron":"Ě","ecaron":"ě","Ecirc":"Ê","ecirc":"ê","ecir":"≖","ecolon":"≕","Ecy":"Э","ecy":"э","eDDot":"⩷","Edot":"Ė","edot":"ė","eDot":"≑","ee":"ⅇ","efDot":"≒","Efr":"𝔈","efr":"𝔢","eg":"⪚","Egrave":"È","egrave":"è","egs":"⪖","egsdot":"⪘","el":"⪙","Element":"∈","elinters":"⏧","ell":"ℓ","els":"⪕","elsdot":"⪗","Emacr":"Ē","emacr":"ē","empty":"∅","emptyset":"∅","EmptySmallSquare":"◻","emptyv":"∅","EmptyVerySmallSquare":"▫","emsp13":" ","emsp14":" ","emsp":" ","ENG":"Ŋ","eng":"ŋ","ensp":" ","Eogon":"Ę","eogon":"ę","Eopf":"𝔼","eopf":"𝕖","epar":"⋕","eparsl":"⧣","eplus":"⩱","epsi":"ε","Epsilon":"Ε","epsilon":"ε","epsiv":"ϵ","eqcirc":"≖","eqcolon":"≕","eqsim":"≂","eqslantgtr":"⪖","eqslantless":"⪕","Equal":"⩵","equals":"=","EqualTilde":"≂","equest":"≟","Equilibrium":"⇌","equiv":"≡","equivDD":"⩸","eqvparsl":"⧥","erarr":"⥱","erDot":"≓","escr":"ℯ","Escr":"ℰ","esdot":"≐","Esim":"⩳","esim":"≂","Eta":"Η","eta":"η","ETH":"Ð","eth":"ð","Euml":"Ë","euml":"ë","euro":"€","excl":"!","exist":"∃","Exists":"∃","expectation":"ℰ","exponentiale":"ⅇ","ExponentialE":"ⅇ","fallingdotseq":"≒","Fcy":"Ф","fcy":"ф","female":"♀","ffilig":"ﬃ","fflig":"ﬀ","ffllig":"ﬄ","Ffr":"𝔉","ffr":"𝔣","filig":"ﬁ","FilledSmallSquare":"◼","FilledVerySmallSquare":"▪","fjlig":"fj","flat":"♭","fllig":"ﬂ","fltns":"▱","fnof":"ƒ","Fopf":"𝔽","fopf":"𝕗","forall":"∀","ForAll":"∀","fork":"⋔","forkv":"⫙","Fouriertrf":"ℱ","fpartint":"⨍","frac12":"½","frac13":"⅓","frac14":"¼","frac15":"⅕","frac16":"⅙","frac18":"⅛","frac23":"⅔","frac25":"⅖","frac34":"¾","frac35":"⅗","frac38":"⅜","frac45":"⅘","frac56":"⅚","frac58":"⅝","frac78":"⅞","frasl":"⁄","frown":"⌢","fscr":"𝒻","Fscr":"ℱ","gacute":"ǵ","Gamma":"Γ","gamma":"γ","Gammad":"Ϝ","gammad":"ϝ","gap":"⪆","Gbreve":"Ğ","gbreve":"ğ","Gcedil":"Ģ","Gcirc":"Ĝ","gcirc":"ĝ","Gcy":"Г","gcy":"г","Gdot":"Ġ","gdot":"ġ","ge":"≥","gE":"≧","gEl":"⪌","gel":"⋛","geq":"≥","geqq":"≧","geqslant":"⩾","gescc":"⪩","ges":"⩾","gesdot":"⪀","gesdoto":"⪂","gesdotol":"⪄","gesl":"⋛︀","gesles":"⪔","Gfr":"𝔊","gfr":"𝔤","gg":"≫","Gg":"⋙","ggg":"⋙","gimel":"ℷ","GJcy":"Ѓ","gjcy":"ѓ","gla":"⪥","gl":"≷","glE":"⪒","glj":"⪤","gnap":"⪊","gnapprox":"⪊","gne":"⪈","gnE":"≩","gneq":"⪈","gneqq":"≩","gnsim":"⋧","Gopf":"𝔾","gopf":"𝕘","grave":"`","GreaterEqual":"≥","GreaterEqualLess":"⋛","GreaterFullEqual":"≧","GreaterGreater":"⪢","GreaterLess":"≷","GreaterSlantEqual":"⩾","GreaterTilde":"≳","Gscr":"𝒢","gscr":"ℊ","gsim":"≳","gsime":"⪎","gsiml":"⪐","gtcc":"⪧","gtcir":"⩺","gt":">","GT":">","Gt":"≫","gtdot":"⋗","gtlPar":"⦕","gtquest":"⩼","gtrapprox":"⪆","gtrarr":"⥸","gtrdot":"⋗","gtreqless":"⋛","gtreqqless":"⪌","gtrless":"≷","gtrsim":"≳","gvertneqq":"≩︀","gvnE":"≩︀","Hacek":"ˇ","hairsp":" ","half":"½","hamilt":"ℋ","HARDcy":"Ъ","hardcy":"ъ","harrcir":"⥈","harr":"↔","hArr":"⇔","harrw":"↭","Hat":"^","hbar":"ℏ","Hcirc":"Ĥ","hcirc":"ĥ","hearts":"♥","heartsuit":"♥","hellip":"…","hercon":"⊹","hfr":"𝔥","Hfr":"ℌ","HilbertSpace":"ℋ","hksearow":"⤥","hkswarow":"⤦","hoarr":"⇿","homtht":"∻","hookleftarrow":"↩","hookrightarrow":"↪","hopf":"𝕙","Hopf":"ℍ","horbar":"―","HorizontalLine":"─","hscr":"𝒽","Hscr":"ℋ","hslash":"ℏ","Hstrok":"Ħ","hstrok":"ħ","HumpDownHump":"≎","HumpEqual":"≏","hybull":"⁃","hyphen":"‐","Iacute":"Í","iacute":"í","ic":"⁣","Icirc":"Î","icirc":"î","Icy":"И","icy":"и","Idot":"İ","IEcy":"Е","iecy":"е","iexcl":"¡","iff":"⇔","ifr":"𝔦","Ifr":"ℑ","Igrave":"Ì","igrave":"ì","ii":"ⅈ","iiiint":"⨌","iiint":"∭","iinfin":"⧜","iiota":"℩","IJlig":"Ĳ","ijlig":"ĳ","Imacr":"Ī","imacr":"ī","image":"ℑ","ImaginaryI":"ⅈ","imagline":"ℐ","imagpart":"ℑ","imath":"ı","Im":"ℑ","imof":"⊷","imped":"Ƶ","Implies":"⇒","incare":"℅","in":"∈","infin":"∞","infintie":"⧝","inodot":"ı","intcal":"⊺","int":"∫","Int":"∬","integers":"ℤ","Integral":"∫","intercal":"⊺","Intersection":"⋂","intlarhk":"⨗","intprod":"⨼","InvisibleComma":"⁣","InvisibleTimes":"⁢","IOcy":"Ё","iocy":"ё","Iogon":"Į","iogon":"į","Iopf":"𝕀","iopf":"𝕚","Iota":"Ι","iota":"ι","iprod":"⨼","iquest":"¿","iscr":"𝒾","Iscr":"ℐ","isin":"∈","isindot":"⋵","isinE":"⋹","isins":"⋴","isinsv":"⋳","isinv":"∈","it":"⁢","Itilde":"Ĩ","itilde":"ĩ","Iukcy":"І","iukcy":"і","Iuml":"Ï","iuml":"ï","Jcirc":"Ĵ","jcirc":"ĵ","Jcy":"Й","jcy":"й","Jfr":"𝔍","jfr":"𝔧","jmath":"ȷ","Jopf":"𝕁","jopf":"𝕛","Jscr":"𝒥","jscr":"𝒿","Jsercy":"Ј","jsercy":"ј","Jukcy":"Є","jukcy":"є","Kappa":"Κ","kappa":"κ","kappav":"ϰ","Kcedil":"Ķ","kcedil":"ķ","Kcy":"К","kcy":"к","Kfr":"𝔎","kfr":"𝔨","kgreen":"ĸ","KHcy":"Х","khcy":"х","KJcy":"Ќ","kjcy":"ќ","Kopf":"𝕂","kopf":"𝕜","Kscr":"𝒦","kscr":"𝓀","lAarr":"⇚","Lacute":"Ĺ","lacute":"ĺ","laemptyv":"⦴","lagran":"ℒ","Lambda":"Λ","lambda":"λ","lang":"⟨","Lang":"⟪","langd":"⦑","langle":"⟨","lap":"⪅","Laplacetrf":"ℒ","laquo":"«","larrb":"⇤","larrbfs":"⤟","larr":"←","Larr":"↞","lArr":"⇐","larrfs":"⤝","larrhk":"↩","larrlp":"↫","larrpl":"⤹","larrsim":"⥳","larrtl":"↢","latail":"⤙","lAtail":"⤛","lat":"⪫","late":"⪭","lates":"⪭︀","lbarr":"⤌","lBarr":"⤎","lbbrk":"❲","lbrace":"{","lbrack":"[","lbrke":"⦋","lbrksld":"⦏","lbrkslu":"⦍","Lcaron":"Ľ","lcaron":"ľ","Lcedil":"Ļ","lcedil":"ļ","lceil":"⌈","lcub":"{","Lcy":"Л","lcy":"л","ldca":"⤶","ldquo":"“","ldquor":"„","ldrdhar":"⥧","ldrushar":"⥋","ldsh":"↲","le":"≤","lE":"≦","LeftAngleBracket":"⟨","LeftArrowBar":"⇤","leftarrow":"←","LeftArrow":"←","Leftarrow":"⇐","LeftArrowRightArrow":"⇆","leftarrowtail":"↢","LeftCeiling":"⌈","LeftDoubleBracket":"⟦","LeftDownTeeVector":"⥡","LeftDownVectorBar":"⥙","LeftDownVector":"⇃","LeftFloor":"⌊","leftharpoondown":"↽","leftharpoonup":"↼","leftleftarrows":"⇇","leftrightarrow":"↔","LeftRightArrow":"↔","Leftrightarrow":"⇔","leftrightarrows":"⇆","leftrightharpoons":"⇋","leftrightsquigarrow":"↭","LeftRightVector":"⥎","LeftTeeArrow":"↤","LeftTee":"⊣","LeftTeeVector":"⥚","leftthreetimes":"⋋","LeftTriangleBar":"⧏","LeftTriangle":"⊲","LeftTriangleEqual":"⊴","LeftUpDownVector":"⥑","LeftUpTeeVector":"⥠","LeftUpVectorBar":"⥘","LeftUpVector":"↿","LeftVectorBar":"⥒","LeftVector":"↼","lEg":"⪋","leg":"⋚","leq":"≤","leqq":"≦","leqslant":"⩽","lescc":"⪨","les":"⩽","lesdot":"⩿","lesdoto":"⪁","lesdotor":"⪃","lesg":"⋚︀","lesges":"⪓","lessapprox":"⪅","lessdot":"⋖","lesseqgtr":"⋚","lesseqqgtr":"⪋","LessEqualGreater":"⋚","LessFullEqual":"≦","LessGreater":"≶","lessgtr":"≶","LessLess":"⪡","lesssim":"≲","LessSlantEqual":"⩽","LessTilde":"≲","lfisht":"⥼","lfloor":"⌊","Lfr":"𝔏","lfr":"𝔩","lg":"≶","lgE":"⪑","lHar":"⥢","lhard":"↽","lharu":"↼","lharul":"⥪","lhblk":"▄","LJcy":"Љ","ljcy":"љ","llarr":"⇇","ll":"≪","Ll":"⋘","llcorner":"⌞","Lleftarrow":"⇚","llhard":"⥫","lltri":"◺","Lmidot":"Ŀ","lmidot":"ŀ","lmoustache":"⎰","lmoust":"⎰","lnap":"⪉","lnapprox":"⪉","lne":"⪇","lnE":"≨","lneq":"⪇","lneqq":"≨","lnsim":"⋦","loang":"⟬","loarr":"⇽","lobrk":"⟦","longleftarrow":"⟵","LongLeftArrow":"⟵","Longleftarrow":"⟸","longleftrightarrow":"⟷","LongLeftRightArrow":"⟷","Longleftrightarrow":"⟺","longmapsto":"⟼","longrightarrow":"⟶","LongRightArrow":"⟶","Longrightarrow":"⟹","looparrowleft":"↫","looparrowright":"↬","lopar":"⦅","Lopf":"𝕃","lopf":"𝕝","loplus":"⨭","lotimes":"⨴","lowast":"∗","lowbar":"_","LowerLeftArrow":"↙","LowerRightArrow":"↘","loz":"◊","lozenge":"◊","lozf":"⧫","lpar":"(","lparlt":"⦓","lrarr":"⇆","lrcorner":"⌟","lrhar":"⇋","lrhard":"⥭","lrm":"‎","lrtri":"⊿","lsaquo":"‹","lscr":"𝓁","Lscr":"ℒ","lsh":"↰","Lsh":"↰","lsim":"≲","lsime":"⪍","lsimg":"⪏","lsqb":"[","lsquo":"‘","lsquor":"‚","Lstrok":"Ł","lstrok":"ł","ltcc":"⪦","ltcir":"⩹","lt":"<","LT":"<","Lt":"≪","ltdot":"⋖","lthree":"⋋","ltimes":"⋉","ltlarr":"⥶","ltquest":"⩻","ltri":"◃","ltrie":"⊴","ltrif":"◂","ltrPar":"⦖","lurdshar":"⥊","luruhar":"⥦","lvertneqq":"≨︀","lvnE":"≨︀","macr":"¯","male":"♂","malt":"✠","maltese":"✠","Map":"⤅","map":"↦","mapsto":"↦","mapstodown":"↧","mapstoleft":"↤","mapstoup":"↥","marker":"▮","mcomma":"⨩","Mcy":"М","mcy":"м","mdash":"—","mDDot":"∺","measuredangle":"∡","MediumSpace":" ","Mellintrf":"ℳ","Mfr":"𝔐","mfr":"𝔪","mho":"℧","micro":"µ","midast":"*","midcir":"⫰","mid":"∣","middot":"·","minusb":"⊟","minus":"−","minusd":"∸","minusdu":"⨪","MinusPlus":"∓","mlcp":"⫛","mldr":"…","mnplus":"∓","models":"⊧","Mopf":"𝕄","mopf":"𝕞","mp":"∓","mscr":"𝓂","Mscr":"ℳ","mstpos":"∾","Mu":"Μ","mu":"μ","multimap":"⊸","mumap":"⊸","nabla":"∇","Nacute":"Ń","nacute":"ń","nang":"∠⃒","nap":"≉","napE":"⩰̸","napid":"≋̸","napos":"ŉ","napprox":"≉","natural":"♮","naturals":"ℕ","natur":"♮","nbsp":" ","nbump":"≎̸","nbumpe":"≏̸","ncap":"⩃","Ncaron":"Ň","ncaron":"ň","Ncedil":"Ņ","ncedil":"ņ","ncong":"≇","ncongdot":"⩭̸","ncup":"⩂","Ncy":"Н","ncy":"н","ndash":"–","nearhk":"⤤","nearr":"↗","neArr":"⇗","nearrow":"↗","ne":"≠","nedot":"≐̸","NegativeMediumSpace":"​","NegativeThickSpace":"​","NegativeThinSpace":"​","NegativeVeryThinSpace":"​","nequiv":"≢","nesear":"⤨","nesim":"≂̸","NestedGreaterGreater":"≫","NestedLessLess":"≪","NewLine":"\\n","nexist":"∄","nexists":"∄","Nfr":"𝔑","nfr":"𝔫","ngE":"≧̸","nge":"≱","ngeq":"≱","ngeqq":"≧̸","ngeqslant":"⩾̸","nges":"⩾̸","nGg":"⋙̸","ngsim":"≵","nGt":"≫⃒","ngt":"≯","ngtr":"≯","nGtv":"≫̸","nharr":"↮","nhArr":"⇎","nhpar":"⫲","ni":"∋","nis":"⋼","nisd":"⋺","niv":"∋","NJcy":"Њ","njcy":"њ","nlarr":"↚","nlArr":"⇍","nldr":"‥","nlE":"≦̸","nle":"≰","nleftarrow":"↚","nLeftarrow":"⇍","nleftrightarrow":"↮","nLeftrightarrow":"⇎","nleq":"≰","nleqq":"≦̸","nleqslant":"⩽̸","nles":"⩽̸","nless":"≮","nLl":"⋘̸","nlsim":"≴","nLt":"≪⃒","nlt":"≮","nltri":"⋪","nltrie":"⋬","nLtv":"≪̸","nmid":"∤","NoBreak":"⁠","NonBreakingSpace":" ","nopf":"𝕟","Nopf":"ℕ","Not":"⫬","not":"¬","NotCongruent":"≢","NotCupCap":"≭","NotDoubleVerticalBar":"∦","NotElement":"∉","NotEqual":"≠","NotEqualTilde":"≂̸","NotExists":"∄","NotGreater":"≯","NotGreaterEqual":"≱","NotGreaterFullEqual":"≧̸","NotGreaterGreater":"≫̸","NotGreaterLess":"≹","NotGreaterSlantEqual":"⩾̸","NotGreaterTilde":"≵","NotHumpDownHump":"≎̸","NotHumpEqual":"≏̸","notin":"∉","notindot":"⋵̸","notinE":"⋹̸","notinva":"∉","notinvb":"⋷","notinvc":"⋶","NotLeftTriangleBar":"⧏̸","NotLeftTriangle":"⋪","NotLeftTriangleEqual":"⋬","NotLess":"≮","NotLessEqual":"≰","NotLessGreater":"≸","NotLessLess":"≪̸","NotLessSlantEqual":"⩽̸","NotLessTilde":"≴","NotNestedGreaterGreater":"⪢̸","NotNestedLessLess":"⪡̸","notni":"∌","notniva":"∌","notnivb":"⋾","notnivc":"⋽","NotPrecedes":"⊀","NotPrecedesEqual":"⪯̸","NotPrecedesSlantEqual":"⋠","NotReverseElement":"∌","NotRightTriangleBar":"⧐̸","NotRightTriangle":"⋫","NotRightTriangleEqual":"⋭","NotSquareSubset":"⊏̸","NotSquareSubsetEqual":"⋢","NotSquareSuperset":"⊐̸","NotSquareSupersetEqual":"⋣","NotSubset":"⊂⃒","NotSubsetEqual":"⊈","NotSucceeds":"⊁","NotSucceedsEqual":"⪰̸","NotSucceedsSlantEqual":"⋡","NotSucceedsTilde":"≿̸","NotSuperset":"⊃⃒","NotSupersetEqual":"⊉","NotTilde":"≁","NotTildeEqual":"≄","NotTildeFullEqual":"≇","NotTildeTilde":"≉","NotVerticalBar":"∤","nparallel":"∦","npar":"∦","nparsl":"⫽⃥","npart":"∂̸","npolint":"⨔","npr":"⊀","nprcue":"⋠","nprec":"⊀","npreceq":"⪯̸","npre":"⪯̸","nrarrc":"⤳̸","nrarr":"↛","nrArr":"⇏","nrarrw":"↝̸","nrightarrow":"↛","nRightarrow":"⇏","nrtri":"⋫","nrtrie":"⋭","nsc":"⊁","nsccue":"⋡","nsce":"⪰̸","Nscr":"𝒩","nscr":"𝓃","nshortmid":"∤","nshortparallel":"∦","nsim":"≁","nsime":"≄","nsimeq":"≄","nsmid":"∤","nspar":"∦","nsqsube":"⋢","nsqsupe":"⋣","nsub":"⊄","nsubE":"⫅̸","nsube":"⊈","nsubset":"⊂⃒","nsubseteq":"⊈","nsubseteqq":"⫅̸","nsucc":"⊁","nsucceq":"⪰̸","nsup":"⊅","nsupE":"⫆̸","nsupe":"⊉","nsupset":"⊃⃒","nsupseteq":"⊉","nsupseteqq":"⫆̸","ntgl":"≹","Ntilde":"Ñ","ntilde":"ñ","ntlg":"≸","ntriangleleft":"⋪","ntrianglelefteq":"⋬","ntriangleright":"⋫","ntrianglerighteq":"⋭","Nu":"Ν","nu":"ν","num":"#","numero":"№","numsp":" ","nvap":"≍⃒","nvdash":"⊬","nvDash":"⊭","nVdash":"⊮","nVDash":"⊯","nvge":"≥⃒","nvgt":">⃒","nvHarr":"⤄","nvinfin":"⧞","nvlArr":"⤂","nvle":"≤⃒","nvlt":"<⃒","nvltrie":"⊴⃒","nvrArr":"⤃","nvrtrie":"⊵⃒","nvsim":"∼⃒","nwarhk":"⤣","nwarr":"↖","nwArr":"⇖","nwarrow":"↖","nwnear":"⤧","Oacute":"Ó","oacute":"ó","oast":"⊛","Ocirc":"Ô","ocirc":"ô","ocir":"⊚","Ocy":"О","ocy":"о","odash":"⊝","Odblac":"Ő","odblac":"ő","odiv":"⨸","odot":"⊙","odsold":"⦼","OElig":"Œ","oelig":"œ","ofcir":"⦿","Ofr":"𝔒","ofr":"𝔬","ogon":"˛","Ograve":"Ò","ograve":"ò","ogt":"⧁","ohbar":"⦵","ohm":"Ω","oint":"∮","olarr":"↺","olcir":"⦾","olcross":"⦻","oline":"‾","olt":"⧀","Omacr":"Ō","omacr":"ō","Omega":"Ω","omega":"ω","Omicron":"Ο","omicron":"ο","omid":"⦶","ominus":"⊖","Oopf":"𝕆","oopf":"𝕠","opar":"⦷","OpenCurlyDoubleQuote":"“","OpenCurlyQuote":"‘","operp":"⦹","oplus":"⊕","orarr":"↻","Or":"⩔","or":"∨","ord":"⩝","order":"ℴ","orderof":"ℴ","ordf":"ª","ordm":"º","origof":"⊶","oror":"⩖","orslope":"⩗","orv":"⩛","oS":"Ⓢ","Oscr":"𝒪","oscr":"ℴ","Oslash":"Ø","oslash":"ø","osol":"⊘","Otilde":"Õ","otilde":"õ","otimesas":"⨶","Otimes":"⨷","otimes":"⊗","Ouml":"Ö","ouml":"ö","ovbar":"⌽","OverBar":"‾","OverBrace":"⏞","OverBracket":"⎴","OverParenthesis":"⏜","para":"¶","parallel":"∥","par":"∥","parsim":"⫳","parsl":"⫽","part":"∂","PartialD":"∂","Pcy":"П","pcy":"п","percnt":"%","period":".","permil":"‰","perp":"⊥","pertenk":"‱","Pfr":"𝔓","pfr":"𝔭","Phi":"Φ","phi":"φ","phiv":"ϕ","phmmat":"ℳ","phone":"☎","Pi":"Π","pi":"π","pitchfork":"⋔","piv":"ϖ","planck":"ℏ","planckh":"ℎ","plankv":"ℏ","plusacir":"⨣","plusb":"⊞","pluscir":"⨢","plus":"+","plusdo":"∔","plusdu":"⨥","pluse":"⩲","PlusMinus":"±","plusmn":"±","plussim":"⨦","plustwo":"⨧","pm":"±","Poincareplane":"ℌ","pointint":"⨕","popf":"𝕡","Popf":"ℙ","pound":"£","prap":"⪷","Pr":"⪻","pr":"≺","prcue":"≼","precapprox":"⪷","prec":"≺","preccurlyeq":"≼","Precedes":"≺","PrecedesEqual":"⪯","PrecedesSlantEqual":"≼","PrecedesTilde":"≾","preceq":"⪯","precnapprox":"⪹","precneqq":"⪵","precnsim":"⋨","pre":"⪯","prE":"⪳","precsim":"≾","prime":"′","Prime":"″","primes":"ℙ","prnap":"⪹","prnE":"⪵","prnsim":"⋨","prod":"∏","Product":"∏","profalar":"⌮","profline":"⌒","profsurf":"⌓","prop":"∝","Proportional":"∝","Proportion":"∷","propto":"∝","prsim":"≾","prurel":"⊰","Pscr":"𝒫","pscr":"𝓅","Psi":"Ψ","psi":"ψ","puncsp":" ","Qfr":"𝔔","qfr":"𝔮","qint":"⨌","qopf":"𝕢","Qopf":"ℚ","qprime":"⁗","Qscr":"𝒬","qscr":"𝓆","quaternions":"ℍ","quatint":"⨖","quest":"?","questeq":"≟","quot":"\\"","QUOT":"\\"","rAarr":"⇛","race":"∽̱","Racute":"Ŕ","racute":"ŕ","radic":"√","raemptyv":"⦳","rang":"⟩","Rang":"⟫","rangd":"⦒","range":"⦥","rangle":"⟩","raquo":"»","rarrap":"⥵","rarrb":"⇥","rarrbfs":"⤠","rarrc":"⤳","rarr":"→","Rarr":"↠","rArr":"⇒","rarrfs":"⤞","rarrhk":"↪","rarrlp":"↬","rarrpl":"⥅","rarrsim":"⥴","Rarrtl":"⤖","rarrtl":"↣","rarrw":"↝","ratail":"⤚","rAtail":"⤜","ratio":"∶","rationals":"ℚ","rbarr":"⤍","rBarr":"⤏","RBarr":"⤐","rbbrk":"❳","rbrace":"}","rbrack":"]","rbrke":"⦌","rbrksld":"⦎","rbrkslu":"⦐","Rcaron":"Ř","rcaron":"ř","Rcedil":"Ŗ","rcedil":"ŗ","rceil":"⌉","rcub":"}","Rcy":"Р","rcy":"р","rdca":"⤷","rdldhar":"⥩","rdquo":"”","rdquor":"”","rdsh":"↳","real":"ℜ","realine":"ℛ","realpart":"ℜ","reals":"ℝ","Re":"ℜ","rect":"▭","reg":"®","REG":"®","ReverseElement":"∋","ReverseEquilibrium":"⇋","ReverseUpEquilibrium":"⥯","rfisht":"⥽","rfloor":"⌋","rfr":"𝔯","Rfr":"ℜ","rHar":"⥤","rhard":"⇁","rharu":"⇀","rharul":"⥬","Rho":"Ρ","rho":"ρ","rhov":"ϱ","RightAngleBracket":"⟩","RightArrowBar":"⇥","rightarrow":"→","RightArrow":"→","Rightarrow":"⇒","RightArrowLeftArrow":"⇄","rightarrowtail":"↣","RightCeiling":"⌉","RightDoubleBracket":"⟧","RightDownTeeVector":"⥝","RightDownVectorBar":"⥕","RightDownVector":"⇂","RightFloor":"⌋","rightharpoondown":"⇁","rightharpoonup":"⇀","rightleftarrows":"⇄","rightleftharpoons":"⇌","rightrightarrows":"⇉","rightsquigarrow":"↝","RightTeeArrow":"↦","RightTee":"⊢","RightTeeVector":"⥛","rightthreetimes":"⋌","RightTriangleBar":"⧐","RightTriangle":"⊳","RightTriangleEqual":"⊵","RightUpDownVector":"⥏","RightUpTeeVector":"⥜","RightUpVectorBar":"⥔","RightUpVector":"↾","RightVectorBar":"⥓","RightVector":"⇀","ring":"˚","risingdotseq":"≓","rlarr":"⇄","rlhar":"⇌","rlm":"‏","rmoustache":"⎱","rmoust":"⎱","rnmid":"⫮","roang":"⟭","roarr":"⇾","robrk":"⟧","ropar":"⦆","ropf":"𝕣","Ropf":"ℝ","roplus":"⨮","rotimes":"⨵","RoundImplies":"⥰","rpar":")","rpargt":"⦔","rppolint":"⨒","rrarr":"⇉","Rrightarrow":"⇛","rsaquo":"›","rscr":"𝓇","Rscr":"ℛ","rsh":"↱","Rsh":"↱","rsqb":"]","rsquo":"’","rsquor":"’","rthree":"⋌","rtimes":"⋊","rtri":"▹","rtrie":"⊵","rtrif":"▸","rtriltri":"⧎","RuleDelayed":"⧴","ruluhar":"⥨","rx":"℞","Sacute":"Ś","sacute":"ś","sbquo":"‚","scap":"⪸","Scaron":"Š","scaron":"š","Sc":"⪼","sc":"≻","sccue":"≽","sce":"⪰","scE":"⪴","Scedil":"Ş","scedil":"ş","Scirc":"Ŝ","scirc":"ŝ","scnap":"⪺","scnE":"⪶","scnsim":"⋩","scpolint":"⨓","scsim":"≿","Scy":"С","scy":"с","sdotb":"⊡","sdot":"⋅","sdote":"⩦","searhk":"⤥","searr":"↘","seArr":"⇘","searrow":"↘","sect":"§","semi":";","seswar":"⤩","setminus":"∖","setmn":"∖","sext":"✶","Sfr":"𝔖","sfr":"𝔰","sfrown":"⌢","sharp":"♯","SHCHcy":"Щ","shchcy":"щ","SHcy":"Ш","shcy":"ш","ShortDownArrow":"↓","ShortLeftArrow":"←","shortmid":"∣","shortparallel":"∥","ShortRightArrow":"→","ShortUpArrow":"↑","shy":"­","Sigma":"Σ","sigma":"σ","sigmaf":"ς","sigmav":"ς","sim":"∼","simdot":"⩪","sime":"≃","simeq":"≃","simg":"⪞","simgE":"⪠","siml":"⪝","simlE":"⪟","simne":"≆","simplus":"⨤","simrarr":"⥲","slarr":"←","SmallCircle":"∘","smallsetminus":"∖","smashp":"⨳","smeparsl":"⧤","smid":"∣","smile":"⌣","smt":"⪪","smte":"⪬","smtes":"⪬︀","SOFTcy":"Ь","softcy":"ь","solbar":"⌿","solb":"⧄","sol":"/","Sopf":"𝕊","sopf":"𝕤","spades":"♠","spadesuit":"♠","spar":"∥","sqcap":"⊓","sqcaps":"⊓︀","sqcup":"⊔","sqcups":"⊔︀","Sqrt":"√","sqsub":"⊏","sqsube":"⊑","sqsubset":"⊏","sqsubseteq":"⊑","sqsup":"⊐","sqsupe":"⊒","sqsupset":"⊐","sqsupseteq":"⊒","square":"□","Square":"□","SquareIntersection":"⊓","SquareSubset":"⊏","SquareSubsetEqual":"⊑","SquareSuperset":"⊐","SquareSupersetEqual":"⊒","SquareUnion":"⊔","squarf":"▪","squ":"□","squf":"▪","srarr":"→","Sscr":"𝒮","sscr":"𝓈","ssetmn":"∖","ssmile":"⌣","sstarf":"⋆","Star":"⋆","star":"☆","starf":"★","straightepsilon":"ϵ","straightphi":"ϕ","strns":"¯","sub":"⊂","Sub":"⋐","subdot":"⪽","subE":"⫅","sube":"⊆","subedot":"⫃","submult":"⫁","subnE":"⫋","subne":"⊊","subplus":"⪿","subrarr":"⥹","subset":"⊂","Subset":"⋐","subseteq":"⊆","subseteqq":"⫅","SubsetEqual":"⊆","subsetneq":"⊊","subsetneqq":"⫋","subsim":"⫇","subsub":"⫕","subsup":"⫓","succapprox":"⪸","succ":"≻","succcurlyeq":"≽","Succeeds":"≻","SucceedsEqual":"⪰","SucceedsSlantEqual":"≽","SucceedsTilde":"≿","succeq":"⪰","succnapprox":"⪺","succneqq":"⪶","succnsim":"⋩","succsim":"≿","SuchThat":"∋","sum":"∑","Sum":"∑","sung":"♪","sup1":"¹","sup2":"²","sup3":"³","sup":"⊃","Sup":"⋑","supdot":"⪾","supdsub":"⫘","supE":"⫆","supe":"⊇","supedot":"⫄","Superset":"⊃","SupersetEqual":"⊇","suphsol":"⟉","suphsub":"⫗","suplarr":"⥻","supmult":"⫂","supnE":"⫌","supne":"⊋","supplus":"⫀","supset":"⊃","Supset":"⋑","supseteq":"⊇","supseteqq":"⫆","supsetneq":"⊋","supsetneqq":"⫌","supsim":"⫈","supsub":"⫔","supsup":"⫖","swarhk":"⤦","swarr":"↙","swArr":"⇙","swarrow":"↙","swnwar":"⤪","szlig":"ß","Tab":"\\t","target":"⌖","Tau":"Τ","tau":"τ","tbrk":"⎴","Tcaron":"Ť","tcaron":"ť","Tcedil":"Ţ","tcedil":"ţ","Tcy":"Т","tcy":"т","tdot":"⃛","telrec":"⌕","Tfr":"𝔗","tfr":"𝔱","there4":"∴","therefore":"∴","Therefore":"∴","Theta":"Θ","theta":"θ","thetasym":"ϑ","thetav":"ϑ","thickapprox":"≈","thicksim":"∼","ThickSpace":"  ","ThinSpace":" ","thinsp":" ","thkap":"≈","thksim":"∼","THORN":"Þ","thorn":"þ","tilde":"˜","Tilde":"∼","TildeEqual":"≃","TildeFullEqual":"≅","TildeTilde":"≈","timesbar":"⨱","timesb":"⊠","times":"×","timesd":"⨰","tint":"∭","toea":"⤨","topbot":"⌶","topcir":"⫱","top":"⊤","Topf":"𝕋","topf":"𝕥","topfork":"⫚","tosa":"⤩","tprime":"‴","trade":"™","TRADE":"™","triangle":"▵","triangledown":"▿","triangleleft":"◃","trianglelefteq":"⊴","triangleq":"≜","triangleright":"▹","trianglerighteq":"⊵","tridot":"◬","trie":"≜","triminus":"⨺","TripleDot":"⃛","triplus":"⨹","trisb":"⧍","tritime":"⨻","trpezium":"⏢","Tscr":"𝒯","tscr":"𝓉","TScy":"Ц","tscy":"ц","TSHcy":"Ћ","tshcy":"ћ","Tstrok":"Ŧ","tstrok":"ŧ","twixt":"≬","twoheadleftarrow":"↞","twoheadrightarrow":"↠","Uacute":"Ú","uacute":"ú","uarr":"↑","Uarr":"↟","uArr":"⇑","Uarrocir":"⥉","Ubrcy":"Ў","ubrcy":"ў","Ubreve":"Ŭ","ubreve":"ŭ","Ucirc":"Û","ucirc":"û","Ucy":"У","ucy":"у","udarr":"⇅","Udblac":"Ű","udblac":"ű","udhar":"⥮","ufisht":"⥾","Ufr":"𝔘","ufr":"𝔲","Ugrave":"Ù","ugrave":"ù","uHar":"⥣","uharl":"↿","uharr":"↾","uhblk":"▀","ulcorn":"⌜","ulcorner":"⌜","ulcrop":"⌏","ultri":"◸","Umacr":"Ū","umacr":"ū","uml":"¨","UnderBar":"_","UnderBrace":"⏟","UnderBracket":"⎵","UnderParenthesis":"⏝","Union":"⋃","UnionPlus":"⊎","Uogon":"Ų","uogon":"ų","Uopf":"𝕌","uopf":"𝕦","UpArrowBar":"⤒","uparrow":"↑","UpArrow":"↑","Uparrow":"⇑","UpArrowDownArrow":"⇅","updownarrow":"↕","UpDownArrow":"↕","Updownarrow":"⇕","UpEquilibrium":"⥮","upharpoonleft":"↿","upharpoonright":"↾","uplus":"⊎","UpperLeftArrow":"↖","UpperRightArrow":"↗","upsi":"υ","Upsi":"ϒ","upsih":"ϒ","Upsilon":"Υ","upsilon":"υ","UpTeeArrow":"↥","UpTee":"⊥","upuparrows":"⇈","urcorn":"⌝","urcorner":"⌝","urcrop":"⌎","Uring":"Ů","uring":"ů","urtri":"◹","Uscr":"𝒰","uscr":"𝓊","utdot":"⋰","Utilde":"Ũ","utilde":"ũ","utri":"▵","utrif":"▴","uuarr":"⇈","Uuml":"Ü","uuml":"ü","uwangle":"⦧","vangrt":"⦜","varepsilon":"ϵ","varkappa":"ϰ","varnothing":"∅","varphi":"ϕ","varpi":"ϖ","varpropto":"∝","varr":"↕","vArr":"⇕","varrho":"ϱ","varsigma":"ς","varsubsetneq":"⊊︀","varsubsetneqq":"⫋︀","varsupsetneq":"⊋︀","varsupsetneqq":"⫌︀","vartheta":"ϑ","vartriangleleft":"⊲","vartriangleright":"⊳","vBar":"⫨","Vbar":"⫫","vBarv":"⫩","Vcy":"В","vcy":"в","vdash":"⊢","vDash":"⊨","Vdash":"⊩","VDash":"⊫","Vdashl":"⫦","veebar":"⊻","vee":"∨","Vee":"⋁","veeeq":"≚","vellip":"⋮","verbar":"|","Verbar":"‖","vert":"|","Vert":"‖","VerticalBar":"∣","VerticalLine":"|","VerticalSeparator":"❘","VerticalTilde":"≀","VeryThinSpace":" ","Vfr":"𝔙","vfr":"𝔳","vltri":"⊲","vnsub":"⊂⃒","vnsup":"⊃⃒","Vopf":"𝕍","vopf":"𝕧","vprop":"∝","vrtri":"⊳","Vscr":"𝒱","vscr":"𝓋","vsubnE":"⫋︀","vsubne":"⊊︀","vsupnE":"⫌︀","vsupne":"⊋︀","Vvdash":"⊪","vzigzag":"⦚","Wcirc":"Ŵ","wcirc":"ŵ","wedbar":"⩟","wedge":"∧","Wedge":"⋀","wedgeq":"≙","weierp":"℘","Wfr":"𝔚","wfr":"𝔴","Wopf":"𝕎","wopf":"𝕨","wp":"℘","wr":"≀","wreath":"≀","Wscr":"𝒲","wscr":"𝓌","xcap":"⋂","xcirc":"◯","xcup":"⋃","xdtri":"▽","Xfr":"𝔛","xfr":"𝔵","xharr":"⟷","xhArr":"⟺","Xi":"Ξ","xi":"ξ","xlarr":"⟵","xlArr":"⟸","xmap":"⟼","xnis":"⋻","xodot":"⨀","Xopf":"𝕏","xopf":"𝕩","xoplus":"⨁","xotime":"⨂","xrarr":"⟶","xrArr":"⟹","Xscr":"𝒳","xscr":"𝓍","xsqcup":"⨆","xuplus":"⨄","xutri":"△","xvee":"⋁","xwedge":"⋀","Yacute":"Ý","yacute":"ý","YAcy":"Я","yacy":"я","Ycirc":"Ŷ","ycirc":"ŷ","Ycy":"Ы","ycy":"ы","yen":"¥","Yfr":"𝔜","yfr":"𝔶","YIcy":"Ї","yicy":"ї","Yopf":"𝕐","yopf":"𝕪","Yscr":"𝒴","yscr":"𝓎","YUcy":"Ю","yucy":"ю","yuml":"ÿ","Yuml":"Ÿ","Zacute":"Ź","zacute":"ź","Zcaron":"Ž","zcaron":"ž","Zcy":"З","zcy":"з","Zdot":"Ż","zdot":"ż","zeetrf":"ℨ","ZeroWidthSpace":"​","Zeta":"Ζ","zeta":"ζ","zfr":"𝔷","Zfr":"ℨ","ZHcy":"Ж","zhcy":"ж","zigrarr":"⇝","zopf":"𝕫","Zopf":"ℤ","Zscr":"𝒵","zscr":"𝓏","zwj":"‍","zwnj":"‌"}')},7802:e=>{"use strict"
e.exports=JSON.parse('{"Aacute":"Á","aacute":"á","Acirc":"Â","acirc":"â","acute":"´","AElig":"Æ","aelig":"æ","Agrave":"À","agrave":"à","amp":"&","AMP":"&","Aring":"Å","aring":"å","Atilde":"Ã","atilde":"ã","Auml":"Ä","auml":"ä","brvbar":"¦","Ccedil":"Ç","ccedil":"ç","cedil":"¸","cent":"¢","copy":"©","COPY":"©","curren":"¤","deg":"°","divide":"÷","Eacute":"É","eacute":"é","Ecirc":"Ê","ecirc":"ê","Egrave":"È","egrave":"è","ETH":"Ð","eth":"ð","Euml":"Ë","euml":"ë","frac12":"½","frac14":"¼","frac34":"¾","gt":">","GT":">","Iacute":"Í","iacute":"í","Icirc":"Î","icirc":"î","iexcl":"¡","Igrave":"Ì","igrave":"ì","iquest":"¿","Iuml":"Ï","iuml":"ï","laquo":"«","lt":"<","LT":"<","macr":"¯","micro":"µ","middot":"·","nbsp":" ","not":"¬","Ntilde":"Ñ","ntilde":"ñ","Oacute":"Ó","oacute":"ó","Ocirc":"Ô","ocirc":"ô","Ograve":"Ò","ograve":"ò","ordf":"ª","ordm":"º","Oslash":"Ø","oslash":"ø","Otilde":"Õ","otilde":"õ","Ouml":"Ö","ouml":"ö","para":"¶","plusmn":"±","pound":"£","quot":"\\"","QUOT":"\\"","raquo":"»","reg":"®","REG":"®","sect":"§","shy":"­","sup1":"¹","sup2":"²","sup3":"³","szlig":"ß","THORN":"Þ","thorn":"þ","times":"×","Uacute":"Ú","uacute":"ú","Ucirc":"Û","ucirc":"û","Ugrave":"Ù","ugrave":"ù","uml":"¨","Uuml":"Ü","uuml":"ü","Yacute":"Ý","yacute":"ý","yen":"¥","yuml":"ÿ"}')},2228:e=>{"use strict"
e.exports=JSON.parse('{"amp":"&","apos":"\'","gt":">","lt":"<","quot":"\\""}')},3523:e=>{"use strict"
e.exports=JSON.parse('{"@charset":{"syntax":"@charset \\"<charset>\\";","groups":["CSS Charsets"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@charset"},"@counter-style":{"syntax":"@counter-style <counter-style-name> {\\n  [ system: <counter-system>; ] ||\\n  [ symbols: <counter-symbols>; ] ||\\n  [ additive-symbols: <additive-symbols>; ] ||\\n  [ negative: <negative-symbol>; ] ||\\n  [ prefix: <prefix>; ] ||\\n  [ suffix: <suffix>; ] ||\\n  [ range: <range>; ] ||\\n  [ pad: <padding>; ] ||\\n  [ speak-as: <speak-as>; ] ||\\n  [ fallback: <counter-style-name>; ]\\n}","interfaces":["CSSCounterStyleRule"],"groups":["CSS Counter Styles"],"descriptors":{"additive-symbols":{"syntax":"[ <integer> && <symbol> ]#","media":"all","initial":"n/a (required)","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"},"fallback":{"syntax":"<counter-style-name>","media":"all","initial":"decimal","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"negative":{"syntax":"<symbol> <symbol>?","media":"all","initial":"\\"-\\" hyphen-minus","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"},"pad":{"syntax":"<integer> && <symbol>","media":"all","initial":"0 \\"\\"","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"prefix":{"syntax":"<symbol>","media":"all","initial":"\\"\\"","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"range":{"syntax":"[ [ <integer> | infinite ]{2} ]# | auto","media":"all","initial":"auto","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"},"speak-as":{"syntax":"auto | bullets | numbers | words | spell-out | <counter-style-name>","media":"all","initial":"auto","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"suffix":{"syntax":"<symbol>","media":"all","initial":"\\". \\"","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"symbols":{"syntax":"<symbol>+","media":"all","initial":"n/a (required)","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"},"system":{"syntax":"cyclic | numeric | alphabetic | symbolic | additive | [ fixed <integer>? ] | [ extends <counter-style-name> ]","media":"all","initial":"symbolic","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"}},"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@counter-style"},"@document":{"syntax":"@document [ <url> | url-prefix(<string>) | domain(<string>) | media-document(<string>) | regexp(<string>) ]# {\\n  <group-rule-body>\\n}","interfaces":["CSSGroupingRule","CSSConditionRule"],"groups":["CSS Conditional Rules"],"status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@document"},"@font-face":{"syntax":"@font-face {\\n  [ font-family: <family-name>; ] ||\\n  [ src: <src>; ] ||\\n  [ unicode-range: <unicode-range>; ] ||\\n  [ font-variant: <font-variant>; ] ||\\n  [ font-feature-settings: <font-feature-settings>; ] ||\\n  [ font-variation-settings: <font-variation-settings>; ] ||\\n  [ font-stretch: <font-stretch>; ] ||\\n  [ font-weight: <font-weight>; ] ||\\n  [ font-style: <font-style>; ]\\n}","interfaces":["CSSFontFaceRule"],"groups":["CSS Fonts"],"descriptors":{"font-display":{"syntax":"[ auto | block | swap | fallback | optional ]","media":"visual","percentages":"no","initial":"auto","computed":"asSpecified","order":"uniqueOrder","status":"experimental"},"font-family":{"syntax":"<family-name>","media":"all","initial":"n/a (required)","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"font-feature-settings":{"syntax":"normal | <feature-tag-value>#","media":"all","initial":"normal","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"},"font-variation-settings":{"syntax":"normal | [ <string> <number> ]#","media":"all","initial":"normal","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"},"font-stretch":{"syntax":"<font-stretch-absolute>{1,2}","media":"all","initial":"normal","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"font-style":{"syntax":"normal | italic | oblique <angle>{0,2}","media":"all","initial":"normal","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"font-weight":{"syntax":"<font-weight-absolute>{1,2}","media":"all","initial":"normal","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"font-variant":{"syntax":"normal | none | [ <common-lig-values> || <discretionary-lig-values> || <historical-lig-values> || <contextual-alt-values> || stylistic(<feature-value-name>) || historical-forms || styleset(<feature-value-name>#) || character-variant(<feature-value-name>#) || swash(<feature-value-name>) || ornaments(<feature-value-name>) || annotation(<feature-value-name>) || [ small-caps | all-small-caps | petite-caps | all-petite-caps | unicase | titling-caps ] || <numeric-figure-values> || <numeric-spacing-values> || <numeric-fraction-values> || ordinal || slashed-zero || <east-asian-variant-values> || <east-asian-width-values> || ruby ]","media":"all","initial":"normal","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"},"src":{"syntax":"[ <url> [ format( <string># ) ]? | local( <family-name> ) ]#","media":"all","initial":"n/a (required)","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"},"unicode-range":{"syntax":"<unicode-range>#","media":"all","initial":"U+0-10FFFF","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"}},"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@font-face"},"@font-feature-values":{"syntax":"@font-feature-values <family-name># {\\n  <feature-value-block-list>\\n}","interfaces":["CSSFontFeatureValuesRule"],"groups":["CSS Fonts"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@font-feature-values"},"@import":{"syntax":"@import [ <string> | <url> ] [ <media-query-list> ]?;","groups":["Media Queries"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@import"},"@keyframes":{"syntax":"@keyframes <keyframes-name> {\\n  <keyframe-block-list>\\n}","interfaces":["CSSKeyframeRule","CSSKeyframesRule"],"groups":["CSS Animations"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@keyframes"},"@media":{"syntax":"@media <media-query-list> {\\n  <group-rule-body>\\n}","interfaces":["CSSGroupingRule","CSSConditionRule","CSSMediaRule","CSSCustomMediaRule"],"groups":["CSS Conditional Rules","Media Queries"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@media"},"@namespace":{"syntax":"@namespace <namespace-prefix>? [ <string> | <url> ];","groups":["CSS Namespaces"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@namespace"},"@page":{"syntax":"@page <page-selector-list> {\\n  <page-body>\\n}","interfaces":["CSSPageRule"],"groups":["CSS Pages"],"descriptors":{"bleed":{"syntax":"auto | <length>","media":["visual","paged"],"initial":"auto","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"marks":{"syntax":"none | [ crop || cross ]","media":["visual","paged"],"initial":"none","percentages":"no","computed":"asSpecified","order":"orderOfAppearance","status":"standard"},"size":{"syntax":"<length>{1,2} | auto | [ <page-size> || [ portrait | landscape ] ]","media":["visual","paged"],"initial":"auto","percentages":"no","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"orderOfAppearance","status":"standard"}},"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@page"},"@property":{"syntax":"@property <custom-property-name> {\\n  <declaration-list>\\n}","interfaces":["CSS","CSSPropertyRule"],"groups":["CSS Houdini"],"descriptors":{"syntax":{"syntax":"<string>","media":"all","percentages":"no","initial":"n/a (required)","computed":"asSpecified","order":"uniqueOrder","status":"experimental"},"inherits":{"syntax":"true | false","media":"all","percentages":"no","initial":"auto","computed":"asSpecified","order":"uniqueOrder","status":"experimental"},"initial-value":{"syntax":"<string>","media":"all","initial":"n/a (required)","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"experimental"}},"status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@property"},"@supports":{"syntax":"@supports <supports-condition> {\\n  <group-rule-body>\\n}","interfaces":["CSSGroupingRule","CSSConditionRule","CSSSupportsRule"],"groups":["CSS Conditional Rules"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@supports"},"@viewport":{"syntax":"@viewport {\\n  <group-rule-body>\\n}","interfaces":["CSSViewportRule"],"groups":["CSS Device Adaptation"],"descriptors":{"height":{"syntax":"<viewport-length>{1,2}","media":["visual","continuous"],"initial":["min-height","max-height"],"percentages":["min-height","max-height"],"computed":["min-height","max-height"],"order":"orderOfAppearance","status":"standard"},"max-height":{"syntax":"<viewport-length>","media":["visual","continuous"],"initial":"auto","percentages":"referToHeightOfInitialViewport","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard"},"max-width":{"syntax":"<viewport-length>","media":["visual","continuous"],"initial":"auto","percentages":"referToWidthOfInitialViewport","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard"},"max-zoom":{"syntax":"auto | <number> | <percentage>","media":["visual","continuous"],"initial":"auto","percentages":"the zoom factor itself","computed":"autoNonNegativeOrPercentage","order":"uniqueOrder","status":"standard"},"min-height":{"syntax":"<viewport-length>","media":["visual","continuous"],"initial":"auto","percentages":"referToHeightOfInitialViewport","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard"},"min-width":{"syntax":"<viewport-length>","media":["visual","continuous"],"initial":"auto","percentages":"referToWidthOfInitialViewport","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard"},"min-zoom":{"syntax":"auto | <number> | <percentage>","media":["visual","continuous"],"initial":"auto","percentages":"the zoom factor itself","computed":"autoNonNegativeOrPercentage","order":"uniqueOrder","status":"standard"},"orientation":{"syntax":"auto | portrait | landscape","media":["visual","continuous"],"initial":"auto","percentages":"referToSizeOfBoundingBox","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"user-zoom":{"syntax":"zoom | fixed","media":["visual","continuous"],"initial":"zoom","percentages":"referToSizeOfBoundingBox","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"viewport-fit":{"syntax":"auto | contain | cover","media":["visual","continuous"],"initial":"auto","percentages":"no","computed":"asSpecified","order":"uniqueOrder","status":"standard"},"width":{"syntax":"<viewport-length>{1,2}","media":["visual","continuous"],"initial":["min-width","max-width"],"percentages":["min-width","max-width"],"computed":["min-width","max-width"],"order":"orderOfAppearance","status":"standard"},"zoom":{"syntax":"auto | <number> | <percentage>","media":["visual","continuous"],"initial":"auto","percentages":"the zoom factor itself","computed":"autoNonNegativeOrPercentage","order":"uniqueOrder","status":"standard"}},"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/@viewport"}}')},5863:e=>{"use strict"
e.exports=JSON.parse('{"--*":{"syntax":"<declaration-value>","media":"all","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Variables"],"initial":"seeProse","appliesto":"allElements","computed":"asSpecifiedWithVarsSubstituted","order":"perGrammar","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/--*"},"-ms-accelerator":{"syntax":"false | true","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"false","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-accelerator"},"-ms-block-progression":{"syntax":"tb | rl | bt | lr","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"tb","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-block-progression"},"-ms-content-zoom-chaining":{"syntax":"none | chained","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"none","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-content-zoom-chaining"},"-ms-content-zooming":{"syntax":"none | zoom","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"zoomForTheTopLevelNoneForTheRest","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-content-zooming"},"-ms-content-zoom-limit":{"syntax":"<\'-ms-content-zoom-limit-min\'> <\'-ms-content-zoom-limit-max\'>","media":"interactive","inherited":false,"animationType":"discrete","percentages":["-ms-content-zoom-limit-max","-ms-content-zoom-limit-min"],"groups":["Microsoft Extensions"],"initial":["-ms-content-zoom-limit-max","-ms-content-zoom-limit-min"],"appliesto":"nonReplacedBlockAndInlineBlockElements","computed":["-ms-content-zoom-limit-max","-ms-content-zoom-limit-min"],"order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-content-zoom-limit"},"-ms-content-zoom-limit-max":{"syntax":"<percentage>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"maxZoomFactor","groups":["Microsoft Extensions"],"initial":"400%","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-content-zoom-limit-max"},"-ms-content-zoom-limit-min":{"syntax":"<percentage>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"minZoomFactor","groups":["Microsoft Extensions"],"initial":"100%","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-content-zoom-limit-min"},"-ms-content-zoom-snap":{"syntax":"<\'-ms-content-zoom-snap-type\'> || <\'-ms-content-zoom-snap-points\'>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":["-ms-content-zoom-snap-type","-ms-content-zoom-snap-points"],"appliesto":"nonReplacedBlockAndInlineBlockElements","computed":["-ms-content-zoom-snap-type","-ms-content-zoom-snap-points"],"order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-content-zoom-snap"},"-ms-content-zoom-snap-points":{"syntax":"snapInterval( <percentage>, <percentage> ) | snapList( <percentage># )","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"snapInterval(0%, 100%)","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-content-zoom-snap-points"},"-ms-content-zoom-snap-type":{"syntax":"none | proximity | mandatory","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"none","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-content-zoom-snap-type"},"-ms-filter":{"syntax":"<string>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"\\"\\"","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-filter"},"-ms-flow-from":{"syntax":"[ none | <custom-ident> ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"none","appliesto":"nonReplacedElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-flow-from"},"-ms-flow-into":{"syntax":"[ none | <custom-ident> ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"none","appliesto":"iframeElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-flow-into"},"-ms-grid-columns":{"syntax":"none | <track-list> | <auto-track-list>","media":"visual","inherited":false,"animationType":"simpleListOfLpcDifferenceLpc","percentages":"referToDimensionOfContentArea","groups":["CSS Grid Layout"],"initial":"none","appliesto":"gridContainers","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-grid-columns"},"-ms-grid-rows":{"syntax":"none | <track-list> | <auto-track-list>","media":"visual","inherited":false,"animationType":"simpleListOfLpcDifferenceLpc","percentages":"referToDimensionOfContentArea","groups":["CSS Grid Layout"],"initial":"none","appliesto":"gridContainers","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-grid-rows"},"-ms-high-contrast-adjust":{"syntax":"auto | none","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-high-contrast-adjust"},"-ms-hyphenate-limit-chars":{"syntax":"auto | <integer>{1,3}","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-hyphenate-limit-chars"},"-ms-hyphenate-limit-lines":{"syntax":"no-limit | <integer>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"no-limit","appliesto":"blockContainerElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-hyphenate-limit-lines"},"-ms-hyphenate-limit-zone":{"syntax":"<percentage> | <length>","media":"visual","inherited":true,"animationType":"discrete","percentages":"referToLineBoxWidth","groups":["Microsoft Extensions"],"initial":"0","appliesto":"blockContainerElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-hyphenate-limit-zone"},"-ms-ime-align":{"syntax":"auto | after","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-ime-align"},"-ms-overflow-style":{"syntax":"auto | none | scrollbar | -ms-autohiding-scrollbar","media":"interactive","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"auto","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-overflow-style"},"-ms-scrollbar-3dlight-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"dependsOnUserAgent","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scrollbar-3dlight-color"},"-ms-scrollbar-arrow-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"ButtonText","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scrollbar-arrow-color"},"-ms-scrollbar-base-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"dependsOnUserAgent","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scrollbar-base-color"},"-ms-scrollbar-darkshadow-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"ThreeDDarkShadow","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scrollbar-darkshadow-color"},"-ms-scrollbar-face-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"ThreeDFace","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scrollbar-face-color"},"-ms-scrollbar-highlight-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"ThreeDHighlight","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scrollbar-highlight-color"},"-ms-scrollbar-shadow-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"ThreeDDarkShadow","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scrollbar-shadow-color"},"-ms-scrollbar-track-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"Scrollbar","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scrollbar-track-color"},"-ms-scroll-chaining":{"syntax":"chained | none","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"chained","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-chaining"},"-ms-scroll-limit":{"syntax":"<\'-ms-scroll-limit-x-min\'> <\'-ms-scroll-limit-y-min\'> <\'-ms-scroll-limit-x-max\'> <\'-ms-scroll-limit-y-max\'>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":["-ms-scroll-limit-x-min","-ms-scroll-limit-y-min","-ms-scroll-limit-x-max","-ms-scroll-limit-y-max"],"appliesto":"nonReplacedBlockAndInlineBlockElements","computed":["-ms-scroll-limit-x-min","-ms-scroll-limit-y-min","-ms-scroll-limit-x-max","-ms-scroll-limit-y-max"],"order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-limit"},"-ms-scroll-limit-x-max":{"syntax":"auto | <length>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"auto","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-limit-x-max"},"-ms-scroll-limit-x-min":{"syntax":"<length>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"0","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-limit-x-min"},"-ms-scroll-limit-y-max":{"syntax":"auto | <length>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"auto","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-limit-y-max"},"-ms-scroll-limit-y-min":{"syntax":"<length>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"0","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-limit-y-min"},"-ms-scroll-rails":{"syntax":"none | railed","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"railed","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-rails"},"-ms-scroll-snap-points-x":{"syntax":"snapInterval( <length-percentage>, <length-percentage> ) | snapList( <length-percentage># )","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"snapInterval(0px, 100%)","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-snap-points-x"},"-ms-scroll-snap-points-y":{"syntax":"snapInterval( <length-percentage>, <length-percentage> ) | snapList( <length-percentage># )","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"snapInterval(0px, 100%)","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-snap-points-y"},"-ms-scroll-snap-type":{"syntax":"none | proximity | mandatory","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"none","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-snap-type"},"-ms-scroll-snap-x":{"syntax":"<\'-ms-scroll-snap-type\'> <\'-ms-scroll-snap-points-x\'>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":["-ms-scroll-snap-type","-ms-scroll-snap-points-x"],"appliesto":"nonReplacedBlockAndInlineBlockElements","computed":["-ms-scroll-snap-type","-ms-scroll-snap-points-x"],"order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-snap-x"},"-ms-scroll-snap-y":{"syntax":"<\'-ms-scroll-snap-type\'> <\'-ms-scroll-snap-points-y\'>","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":["-ms-scroll-snap-type","-ms-scroll-snap-points-y"],"appliesto":"nonReplacedBlockAndInlineBlockElements","computed":["-ms-scroll-snap-type","-ms-scroll-snap-points-y"],"order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-snap-y"},"-ms-scroll-translation":{"syntax":"none | vertical-to-horizontal","media":"interactive","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-scroll-translation"},"-ms-text-autospace":{"syntax":"none | ideograph-alpha | ideograph-numeric | ideograph-parenthesis | ideograph-space","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-text-autospace"},"-ms-touch-select":{"syntax":"grippers | none","media":"interactive","inherited":true,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"grippers","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-touch-select"},"-ms-user-select":{"syntax":"none | element | text","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"text","appliesto":"nonReplacedElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-user-select"},"-ms-wrap-flow":{"syntax":"auto | both | start | end | maximum | clear","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"auto","appliesto":"blockLevelElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-wrap-flow"},"-ms-wrap-margin":{"syntax":"<length>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"0","appliesto":"exclusionElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-wrap-margin"},"-ms-wrap-through":{"syntax":"wrap | none","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Microsoft Extensions"],"initial":"wrap","appliesto":"blockLevelElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-ms-wrap-through"},"-moz-appearance":{"syntax":"none | button | button-arrow-down | button-arrow-next | button-arrow-previous | button-arrow-up | button-bevel | button-focus | caret | checkbox | checkbox-container | checkbox-label | checkmenuitem | dualbutton | groupbox | listbox | listitem | menuarrow | menubar | menucheckbox | menuimage | menuitem | menuitemtext | menulist | menulist-button | menulist-text | menulist-textfield | menupopup | menuradio | menuseparator | meterbar | meterchunk | progressbar | progressbar-vertical | progresschunk | progresschunk-vertical | radio | radio-container | radio-label | radiomenuitem | range | range-thumb | resizer | resizerpanel | scale-horizontal | scalethumbend | scalethumb-horizontal | scalethumbstart | scalethumbtick | scalethumb-vertical | scale-vertical | scrollbarbutton-down | scrollbarbutton-left | scrollbarbutton-right | scrollbarbutton-up | scrollbarthumb-horizontal | scrollbarthumb-vertical | scrollbartrack-horizontal | scrollbartrack-vertical | searchfield | separator | sheet | spinner | spinner-downbutton | spinner-textfield | spinner-upbutton | splitter | statusbar | statusbarpanel | tab | tabpanel | tabpanels | tab-scroll-arrow-back | tab-scroll-arrow-forward | textfield | textfield-multiline | toolbar | toolbarbutton | toolbarbutton-dropdown | toolbargripper | toolbox | tooltip | treeheader | treeheadercell | treeheadersortarrow | treeitem | treeline | treetwisty | treetwistyopen | treeview | -moz-mac-unified-toolbar | -moz-win-borderless-glass | -moz-win-browsertabbar-toolbox | -moz-win-communicationstext | -moz-win-communications-toolbox | -moz-win-exclude-glass | -moz-win-glass | -moz-win-mediatext | -moz-win-media-toolbox | -moz-window-button-box | -moz-window-button-box-maximized | -moz-window-button-close | -moz-window-button-maximize | -moz-window-button-minimize | -moz-window-button-restore | -moz-window-frame-bottom | -moz-window-frame-left | -moz-window-frame-right | -moz-window-titlebar | -moz-window-titlebar-maximized","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions","WebKit Extensions"],"initial":"noneButOverriddenInUserAgentCSS","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/appearance"},"-moz-binding":{"syntax":"<url> | none","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"none","appliesto":"allElementsExceptGeneratedContentOrPseudoElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-binding"},"-moz-border-bottom-colors":{"syntax":"<color>+ | none","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-border-bottom-colors"},"-moz-border-left-colors":{"syntax":"<color>+ | none","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-border-left-colors"},"-moz-border-right-colors":{"syntax":"<color>+ | none","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-border-right-colors"},"-moz-border-top-colors":{"syntax":"<color>+ | none","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-border-top-colors"},"-moz-context-properties":{"syntax":"none | [ fill | fill-opacity | stroke | stroke-opacity ]#","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"none","appliesto":"allElementsThatCanReferenceImages","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-context-properties"},"-moz-float-edge":{"syntax":"border-box | content-box | margin-box | padding-box","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"content-box","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-float-edge"},"-moz-force-broken-image-icon":{"syntax":"<integer [0,1]>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"0","appliesto":"images","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-force-broken-image-icon"},"-moz-image-region":{"syntax":"<shape> | auto","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"auto","appliesto":"xulImageElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-image-region"},"-moz-orient":{"syntax":"inline | block | horizontal | vertical","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"inline","appliesto":"anyElementEffectOnProgressAndMeter","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-orient"},"-moz-outline-radius":{"syntax":"<outline-radius>{1,4} [ / <outline-radius>{1,4} ]?","media":"visual","inherited":false,"animationType":["-moz-outline-radius-topleft","-moz-outline-radius-topright","-moz-outline-radius-bottomright","-moz-outline-radius-bottomleft"],"percentages":["-moz-outline-radius-topleft","-moz-outline-radius-topright","-moz-outline-radius-bottomright","-moz-outline-radius-bottomleft"],"groups":["Mozilla Extensions"],"initial":["-moz-outline-radius-topleft","-moz-outline-radius-topright","-moz-outline-radius-bottomright","-moz-outline-radius-bottomleft"],"appliesto":"allElements","computed":["-moz-outline-radius-topleft","-moz-outline-radius-topright","-moz-outline-radius-bottomright","-moz-outline-radius-bottomleft"],"order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-outline-radius"},"-moz-outline-radius-bottomleft":{"syntax":"<outline-radius>","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["Mozilla Extensions"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-outline-radius-bottomleft"},"-moz-outline-radius-bottomright":{"syntax":"<outline-radius>","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["Mozilla Extensions"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-outline-radius-bottomright"},"-moz-outline-radius-topleft":{"syntax":"<outline-radius>","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["Mozilla Extensions"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-outline-radius-topleft"},"-moz-outline-radius-topright":{"syntax":"<outline-radius>","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["Mozilla Extensions"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-outline-radius-topright"},"-moz-stack-sizing":{"syntax":"ignore | stretch-to-fit","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"stretch-to-fit","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-stack-sizing"},"-moz-text-blink":{"syntax":"none | blink","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-text-blink"},"-moz-user-focus":{"syntax":"ignore | normal | select-after | select-before | select-menu | select-same | select-all | none","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-user-focus"},"-moz-user-input":{"syntax":"auto | none | enabled | disabled","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-user-input"},"-moz-user-modify":{"syntax":"read-only | read-write | write-only","media":"interactive","inherited":true,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"read-only","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-user-modify"},"-moz-window-dragging":{"syntax":"drag | no-drag","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"drag","appliesto":"allElementsCreatingNativeWindows","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-window-dragging"},"-moz-window-shadow":{"syntax":"default | menu | tooltip | sheet | none","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"default","appliesto":"allElementsCreatingNativeWindows","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-moz-window-shadow"},"-webkit-appearance":{"syntax":"none | button | button-bevel | caret | checkbox | default-button | inner-spin-button | listbox | listitem | media-controls-background | media-controls-fullscreen-background | media-current-time-display | media-enter-fullscreen-button | media-exit-fullscreen-button | media-fullscreen-button | media-mute-button | media-overlay-play-button | media-play-button | media-seek-back-button | media-seek-forward-button | media-slider | media-sliderthumb | media-time-remaining-display | media-toggle-closed-captions-button | media-volume-slider | media-volume-slider-container | media-volume-sliderthumb | menulist | menulist-button | menulist-text | menulist-textfield | meter | progress-bar | progress-bar-value | push-button | radio | searchfield | searchfield-cancel-button | searchfield-decoration | searchfield-results-button | searchfield-results-decoration | slider-horizontal | slider-vertical | sliderthumb-horizontal | sliderthumb-vertical | square-button | textarea | textfield | -apple-pay-button","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"noneButOverriddenInUserAgentCSS","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/appearance"},"-webkit-border-before":{"syntax":"<\'border-width\'> || <\'border-style\'> || <\'color\'>","media":"visual","inherited":true,"animationType":"discrete","percentages":["-webkit-border-before-width"],"groups":["WebKit Extensions"],"initial":["border-width","border-style","color"],"appliesto":"allElements","computed":["border-width","border-style","color"],"order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-border-before"},"-webkit-border-before-color":{"syntax":"<\'color\'>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"nonstandard"},"-webkit-border-before-style":{"syntax":"<\'border-style\'>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard"},"-webkit-border-before-width":{"syntax":"<\'border-width\'>","media":"visual","inherited":true,"animationType":"discrete","percentages":"logicalWidthOfContainingBlock","groups":["WebKit Extensions"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthZeroIfBorderStyleNoneOrHidden","order":"uniqueOrder","status":"nonstandard"},"-webkit-box-reflect":{"syntax":"[ above | below | right | left ]? <length>? <image>?","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-box-reflect"},"-webkit-line-clamp":{"syntax":"none | <integer>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["WebKit Extensions","CSS Overflow"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-line-clamp"},"-webkit-mask":{"syntax":"[ <mask-reference> || <position> [ / <bg-size> ]? || <repeat-style> || [ <box> | border | padding | content | text ] || [ <box> | border | padding | content ] ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":["-webkit-mask-image","-webkit-mask-repeat","-webkit-mask-attachment","-webkit-mask-position","-webkit-mask-origin","-webkit-mask-clip"],"appliesto":"allElements","computed":["-webkit-mask-image","-webkit-mask-repeat","-webkit-mask-attachment","-webkit-mask-position","-webkit-mask-origin","-webkit-mask-clip"],"order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask"},"-webkit-mask-attachment":{"syntax":"<attachment>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"scroll","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-mask-attachment"},"-webkit-mask-clip":{"syntax":"[ <box> | border | padding | content | text ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"border","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-clip"},"-webkit-mask-composite":{"syntax":"<composite-style>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"source-over","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-mask-composite"},"-webkit-mask-image":{"syntax":"<mask-reference>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"none","appliesto":"allElements","computed":"absoluteURIOrNone","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-image"},"-webkit-mask-origin":{"syntax":"[ <box> | border | padding | content ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"padding","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-origin"},"-webkit-mask-position":{"syntax":"<position>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"referToSizeOfElement","groups":["WebKit Extensions"],"initial":"0% 0%","appliesto":"allElements","computed":"absoluteLengthOrPercentage","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-position"},"-webkit-mask-position-x":{"syntax":"[ <length-percentage> | left | center | right ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"referToSizeOfElement","groups":["WebKit Extensions"],"initial":"0%","appliesto":"allElements","computed":"absoluteLengthOrPercentage","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-mask-position-x"},"-webkit-mask-position-y":{"syntax":"[ <length-percentage> | top | center | bottom ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"referToSizeOfElement","groups":["WebKit Extensions"],"initial":"0%","appliesto":"allElements","computed":"absoluteLengthOrPercentage","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-mask-position-y"},"-webkit-mask-repeat":{"syntax":"<repeat-style>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"repeat","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-repeat"},"-webkit-mask-repeat-x":{"syntax":"repeat | no-repeat | space | round","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"repeat","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-mask-repeat-x"},"-webkit-mask-repeat-y":{"syntax":"repeat | no-repeat | space | round","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"repeat","appliesto":"allElements","computed":"absoluteLengthOrPercentage","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-mask-repeat-y"},"-webkit-mask-size":{"syntax":"<bg-size>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"relativeToBackgroundPositioningArea","groups":["WebKit Extensions"],"initial":"auto auto","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-size"},"-webkit-overflow-scrolling":{"syntax":"auto | touch","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"auto","appliesto":"scrollingBoxes","computed":"asSpecified","order":"orderOfAppearance","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-overflow-scrolling"},"-webkit-tap-highlight-color":{"syntax":"<color>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"black","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-tap-highlight-color"},"-webkit-text-fill-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"color","percentages":"no","groups":["WebKit Extensions"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-text-fill-color"},"-webkit-text-stroke":{"syntax":"<length> || <color>","media":"visual","inherited":true,"animationType":["-webkit-text-stroke-width","-webkit-text-stroke-color"],"percentages":"no","groups":["WebKit Extensions"],"initial":["-webkit-text-stroke-width","-webkit-text-stroke-color"],"appliesto":"allElements","computed":["-webkit-text-stroke-width","-webkit-text-stroke-color"],"order":"canonicalOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-text-stroke"},"-webkit-text-stroke-color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"color","percentages":"no","groups":["WebKit Extensions"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-text-stroke-color"},"-webkit-text-stroke-width":{"syntax":"<length>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"0","appliesto":"allElements","computed":"absoluteLength","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-text-stroke-width"},"-webkit-touch-callout":{"syntax":"default | none","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"default","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/-webkit-touch-callout"},"-webkit-user-modify":{"syntax":"read-only | read-write | read-write-plaintext-only","media":"interactive","inherited":true,"animationType":"discrete","percentages":"no","groups":["WebKit Extensions"],"initial":"read-only","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard"},"align-content":{"syntax":"normal | <baseline-position> | <content-distribution> | <overflow-position>? <content-position>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Alignment"],"initial":"normal","appliesto":"multilineFlexContainers","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/align-content"},"align-items":{"syntax":"normal | stretch | <baseline-position> | [ <overflow-position>? <self-position> ]","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Alignment"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/align-items"},"align-self":{"syntax":"auto | normal | stretch | <baseline-position> | <overflow-position>? <self-position>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Alignment"],"initial":"auto","appliesto":"flexItemsGridItemsAndAbsolutelyPositionedBoxes","computed":"autoOnAbsolutelyPositionedElementsValueOfAlignItemsOnParent","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/align-self"},"align-tracks":{"syntax":"[ normal | <baseline-position> | <content-distribution> | <overflow-position>? <content-position> ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":"normal","appliesto":"gridContainersWithMasonryLayoutInTheirBlockAxis","computed":"asSpecified","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/align-tracks"},"all":{"syntax":"initial | inherit | unset | revert","media":"noPracticalMedia","inherited":false,"animationType":"eachOfShorthandPropertiesExceptUnicodeBiDiAndDirection","percentages":"no","groups":["CSS Miscellaneous"],"initial":"noPracticalInitialValue","appliesto":"allElements","computed":"asSpecifiedAppliesToEachProperty","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/all"},"animation":{"syntax":"<single-animation>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Animations"],"initial":["animation-name","animation-duration","animation-timing-function","animation-delay","animation-iteration-count","animation-direction","animation-fill-mode","animation-play-state"],"appliesto":"allElementsAndPseudos","computed":["animation-name","animation-duration","animation-timing-function","animation-delay","animation-direction","animation-iteration-count","animation-fill-mode","animation-play-state"],"order":"orderOfAppearance","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/animation"},"animation-delay":{"syntax":"<time>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Animations"],"initial":"0s","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/animation-delay"},"animation-direction":{"syntax":"<single-animation-direction>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Animations"],"initial":"normal","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/animation-direction"},"animation-duration":{"syntax":"<time>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Animations"],"initial":"0s","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/animation-duration"},"animation-fill-mode":{"syntax":"<single-animation-fill-mode>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Animations"],"initial":"none","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/animation-fill-mode"},"animation-iteration-count":{"syntax":"<single-animation-iteration-count>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Animations"],"initial":"1","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/animation-iteration-count"},"animation-name":{"syntax":"[ none | <keyframes-name> ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Animations"],"initial":"none","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/animation-name"},"animation-play-state":{"syntax":"<single-animation-play-state>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Animations"],"initial":"running","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/animation-play-state"},"animation-timing-function":{"syntax":"<timing-function>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Animations"],"initial":"ease","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/animation-timing-function"},"appearance":{"syntax":"none | auto | textfield | menulist-button | <compat-auto>","media":"all","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Basic User Interface"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/appearance"},"aspect-ratio":{"syntax":"auto | <ratio>","media":"all","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Basic User Interface"],"initial":"auto","appliesto":"allElementsExceptInlineBoxesAndInternalRubyOrTableBoxes","computed":"asSpecified","order":"perGrammar","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/aspect-ratio"},"azimuth":{"syntax":"<angle> | [ [ left-side | far-left | left | center-left | center | center-right | right | far-right | right-side ] || behind ] | leftwards | rightwards","media":"aural","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Speech"],"initial":"center","appliesto":"allElements","computed":"normalizedAngle","order":"orderOfAppearance","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/azimuth"},"backdrop-filter":{"syntax":"none | <filter-function-list>","media":"visual","inherited":false,"animationType":"filterList","percentages":"no","groups":["Filter Effects"],"initial":"none","appliesto":"allElementsSVGContainerElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/backdrop-filter"},"backface-visibility":{"syntax":"visible | hidden","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Transforms"],"initial":"visible","appliesto":"transformableElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/backface-visibility"},"background":{"syntax":"[ <bg-layer> , ]* <final-bg-layer>","media":"visual","inherited":false,"animationType":["background-color","background-image","background-clip","background-position","background-size","background-repeat","background-attachment"],"percentages":["background-position","background-size"],"groups":["CSS Backgrounds and Borders"],"initial":["background-image","background-position","background-size","background-repeat","background-origin","background-clip","background-attachment","background-color"],"appliesto":"allElements","computed":["background-image","background-position","background-size","background-repeat","background-origin","background-clip","background-attachment","background-color"],"order":"orderOfAppearance","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background"},"background-attachment":{"syntax":"<attachment>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"scroll","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-attachment"},"background-blend-mode":{"syntax":"<blend-mode>#","media":"none","inherited":false,"animationType":"discrete","percentages":"no","groups":["Compositing and Blending"],"initial":"normal","appliesto":"allElementsSVGContainerGraphicsAndGraphicsReferencingElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-blend-mode"},"background-clip":{"syntax":"<box>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"border-box","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-clip"},"background-color":{"syntax":"<color>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"transparent","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-color"},"background-image":{"syntax":"<bg-image>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"none","appliesto":"allElements","computed":"asSpecifiedURLsAbsolute","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-image"},"background-origin":{"syntax":"<box>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"padding-box","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-origin"},"background-position":{"syntax":"<bg-position>#","media":"visual","inherited":false,"animationType":"repeatableListOfSimpleListOfLpc","percentages":"referToSizeOfBackgroundPositioningAreaMinusBackgroundImageSize","groups":["CSS Backgrounds and Borders"],"initial":"0% 0%","appliesto":"allElements","computed":"listEachItemTwoKeywordsOriginOffsets","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-position"},"background-position-x":{"syntax":"[ center | [ [ left | right | x-start | x-end ]? <length-percentage>? ]! ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"referToWidthOfBackgroundPositioningAreaMinusBackgroundImageHeight","groups":["CSS Backgrounds and Borders"],"initial":"left","appliesto":"allElements","computed":"listEachItemConsistingOfAbsoluteLengthPercentageAndOrigin","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-position-x"},"background-position-y":{"syntax":"[ center | [ [ top | bottom | y-start | y-end ]? <length-percentage>? ]! ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"referToHeightOfBackgroundPositioningAreaMinusBackgroundImageHeight","groups":["CSS Backgrounds and Borders"],"initial":"top","appliesto":"allElements","computed":"listEachItemConsistingOfAbsoluteLengthPercentageAndOrigin","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-position-y"},"background-repeat":{"syntax":"<repeat-style>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"repeat","appliesto":"allElements","computed":"listEachItemHasTwoKeywordsOnePerDimension","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-repeat"},"background-size":{"syntax":"<bg-size>#","media":"visual","inherited":false,"animationType":"repeatableListOfSimpleListOfLpc","percentages":"relativeToBackgroundPositioningArea","groups":["CSS Backgrounds and Borders"],"initial":"auto auto","appliesto":"allElements","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/background-size"},"block-overflow":{"syntax":"clip | ellipsis | <string>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Overflow"],"initial":"clip","appliesto":"blockContainers","computed":"asSpecified","order":"perGrammar","status":"experimental"},"block-size":{"syntax":"<\'width\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"blockSizeOfContainingBlock","groups":["CSS Logical Properties"],"initial":"auto","appliesto":"sameAsWidthAndHeight","computed":"sameAsWidthAndHeight","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/block-size"},"border":{"syntax":"<line-width> || <line-style> || <color>","media":"visual","inherited":false,"animationType":["border-color","border-style","border-width"],"percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":["border-width","border-style","border-color"],"appliesto":"allElements","computed":["border-width","border-style","border-color"],"order":"orderOfAppearance","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border"},"border-block":{"syntax":"<\'border-top-width\'> || <\'border-top-style\'> || <\'color\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":["border-top-width","border-top-style","border-top-color"],"appliesto":"allElements","computed":["border-top-width","border-top-style","border-top-color"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block"},"border-block-color":{"syntax":"<\'border-top-color\'>{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-color"},"border-block-style":{"syntax":"<\'border-top-style\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-style"},"border-block-width":{"syntax":"<\'border-top-width\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthZeroIfBorderStyleNoneOrHidden","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-width"},"border-block-end":{"syntax":"<\'border-top-width\'> || <\'border-top-style\'> || <\'color\'>","media":"visual","inherited":false,"animationType":["border-block-end-color","border-block-end-style","border-block-end-width"],"percentages":"no","groups":["CSS Logical Properties"],"initial":["border-top-width","border-top-style","border-top-color"],"appliesto":"allElements","computed":["border-top-width","border-top-style","border-top-color"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-end"},"border-block-end-color":{"syntax":"<\'border-top-color\'>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Logical Properties"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-end-color"},"border-block-end-style":{"syntax":"<\'border-top-style\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-end-style"},"border-block-end-width":{"syntax":"<\'border-top-width\'>","media":"visual","inherited":false,"animationType":"length","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthZeroIfBorderStyleNoneOrHidden","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-end-width"},"border-block-start":{"syntax":"<\'border-top-width\'> || <\'border-top-style\'> || <\'color\'>","media":"visual","inherited":false,"animationType":["border-block-start-color","border-block-start-style","border-block-start-width"],"percentages":"no","groups":["CSS Logical Properties"],"initial":["border-width","border-style","color"],"appliesto":"allElements","computed":["border-width","border-style","border-block-start-color"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-start"},"border-block-start-color":{"syntax":"<\'border-top-color\'>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Logical Properties"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-start-color"},"border-block-start-style":{"syntax":"<\'border-top-style\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-start-style"},"border-block-start-width":{"syntax":"<\'border-top-width\'>","media":"visual","inherited":false,"animationType":"length","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthZeroIfBorderStyleNoneOrHidden","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-block-start-width"},"border-bottom":{"syntax":"<line-width> || <line-style> || <color>","media":"visual","inherited":false,"animationType":["border-bottom-color","border-bottom-style","border-bottom-width"],"percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":["border-bottom-width","border-bottom-style","border-bottom-color"],"appliesto":"allElements","computed":["border-bottom-width","border-bottom-style","border-bottom-color"],"order":"orderOfAppearance","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-bottom"},"border-bottom-color":{"syntax":"<\'border-top-color\'>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-bottom-color"},"border-bottom-left-radius":{"syntax":"<length-percentage>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["CSS Backgrounds and Borders"],"initial":"0","appliesto":"allElementsUAsNotRequiredWhenCollapse","computed":"twoAbsoluteLengthOrPercentages","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-bottom-left-radius"},"border-bottom-right-radius":{"syntax":"<length-percentage>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["CSS Backgrounds and Borders"],"initial":"0","appliesto":"allElementsUAsNotRequiredWhenCollapse","computed":"twoAbsoluteLengthOrPercentages","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-bottom-right-radius"},"border-bottom-style":{"syntax":"<line-style>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-bottom-style"},"border-bottom-width":{"syntax":"<line-width>","media":"visual","inherited":false,"animationType":"length","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthOr0IfBorderBottomStyleNoneOrHidden","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-bottom-width"},"border-collapse":{"syntax":"collapse | separate","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Table"],"initial":"separate","appliesto":"tableElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-collapse"},"border-color":{"syntax":"<color>{1,4}","media":"visual","inherited":false,"animationType":["border-bottom-color","border-left-color","border-right-color","border-top-color"],"percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":["border-top-color","border-right-color","border-bottom-color","border-left-color"],"appliesto":"allElements","computed":["border-bottom-color","border-left-color","border-right-color","border-top-color"],"order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-color"},"border-end-end-radius":{"syntax":"<length-percentage>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElementsUAsNotRequiredWhenCollapse","computed":"twoAbsoluteLengthOrPercentages","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-end-end-radius"},"border-end-start-radius":{"syntax":"<length-percentage>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElementsUAsNotRequiredWhenCollapse","computed":"twoAbsoluteLengthOrPercentages","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-end-start-radius"},"border-image":{"syntax":"<\'border-image-source\'> || <\'border-image-slice\'> [ / <\'border-image-width\'> | / <\'border-image-width\'>? / <\'border-image-outset\'> ]? || <\'border-image-repeat\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":["border-image-slice","border-image-width"],"groups":["CSS Backgrounds and Borders"],"initial":["border-image-source","border-image-slice","border-image-width","border-image-outset","border-image-repeat"],"appliesto":"allElementsExceptTableElementsWhenCollapse","computed":["border-image-outset","border-image-repeat","border-image-slice","border-image-source","border-image-width"],"order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-image"},"border-image-outset":{"syntax":"[ <length> | <number> ]{1,4}","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"0","appliesto":"allElementsExceptTableElementsWhenCollapse","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-image-outset"},"border-image-repeat":{"syntax":"[ stretch | repeat | round | space ]{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"stretch","appliesto":"allElementsExceptTableElementsWhenCollapse","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-image-repeat"},"border-image-slice":{"syntax":"<number-percentage>{1,4} && fill?","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"referToSizeOfBorderImage","groups":["CSS Backgrounds and Borders"],"initial":"100%","appliesto":"allElementsExceptTableElementsWhenCollapse","computed":"oneToFourPercentagesOrAbsoluteLengthsPlusFill","order":"percentagesOrLengthsFollowedByFill","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-image-slice"},"border-image-source":{"syntax":"none | <image>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"none","appliesto":"allElementsExceptTableElementsWhenCollapse","computed":"noneOrImageWithAbsoluteURI","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-image-source"},"border-image-width":{"syntax":"[ <length-percentage> | <number> | auto ]{1,4}","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"referToWidthOrHeightOfBorderImageArea","groups":["CSS Backgrounds and Borders"],"initial":"1","appliesto":"allElementsExceptTableElementsWhenCollapse","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-image-width"},"border-inline":{"syntax":"<\'border-top-width\'> || <\'border-top-style\'> || <\'color\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":["border-top-width","border-top-style","border-top-color"],"appliesto":"allElements","computed":["border-top-width","border-top-style","border-top-color"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline"},"border-inline-end":{"syntax":"<\'border-top-width\'> || <\'border-top-style\'> || <\'color\'>","media":"visual","inherited":false,"animationType":["border-inline-end-color","border-inline-end-style","border-inline-end-width"],"percentages":"no","groups":["CSS Logical Properties"],"initial":["border-width","border-style","color"],"appliesto":"allElements","computed":["border-width","border-style","border-inline-end-color"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-end"},"border-inline-color":{"syntax":"<\'border-top-color\'>{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-color"},"border-inline-style":{"syntax":"<\'border-top-style\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-style"},"border-inline-width":{"syntax":"<\'border-top-width\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthZeroIfBorderStyleNoneOrHidden","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-width"},"border-inline-end-color":{"syntax":"<\'border-top-color\'>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Logical Properties"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-end-color"},"border-inline-end-style":{"syntax":"<\'border-top-style\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-end-style"},"border-inline-end-width":{"syntax":"<\'border-top-width\'>","media":"visual","inherited":false,"animationType":"length","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthZeroIfBorderStyleNoneOrHidden","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-end-width"},"border-inline-start":{"syntax":"<\'border-top-width\'> || <\'border-top-style\'> || <\'color\'>","media":"visual","inherited":false,"animationType":["border-inline-start-color","border-inline-start-style","border-inline-start-width"],"percentages":"no","groups":["CSS Logical Properties"],"initial":["border-width","border-style","color"],"appliesto":"allElements","computed":["border-width","border-style","border-inline-start-color"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-start"},"border-inline-start-color":{"syntax":"<\'border-top-color\'>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Logical Properties"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-start-color"},"border-inline-start-style":{"syntax":"<\'border-top-style\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Logical Properties"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-start-style"},"border-inline-start-width":{"syntax":"<\'border-top-width\'>","media":"visual","inherited":false,"animationType":"length","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthZeroIfBorderStyleNoneOrHidden","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-inline-start-width"},"border-left":{"syntax":"<line-width> || <line-style> || <color>","media":"visual","inherited":false,"animationType":["border-left-color","border-left-style","border-left-width"],"percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":["border-left-width","border-left-style","border-left-color"],"appliesto":"allElements","computed":["border-left-width","border-left-style","border-left-color"],"order":"orderOfAppearance","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-left"},"border-left-color":{"syntax":"<color>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-left-color"},"border-left-style":{"syntax":"<line-style>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-left-style"},"border-left-width":{"syntax":"<line-width>","media":"visual","inherited":false,"animationType":"length","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthOr0IfBorderLeftStyleNoneOrHidden","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-left-width"},"border-radius":{"syntax":"<length-percentage>{1,4} [ / <length-percentage>{1,4} ]?","media":"visual","inherited":false,"animationType":["border-top-left-radius","border-top-right-radius","border-bottom-right-radius","border-bottom-left-radius"],"percentages":"referToDimensionOfBorderBox","groups":["CSS Backgrounds and Borders"],"initial":["border-top-left-radius","border-top-right-radius","border-bottom-right-radius","border-bottom-left-radius"],"appliesto":"allElementsUAsNotRequiredWhenCollapse","computed":["border-bottom-left-radius","border-bottom-right-radius","border-top-left-radius","border-top-right-radius"],"order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-radius"},"border-right":{"syntax":"<line-width> || <line-style> || <color>","media":"visual","inherited":false,"animationType":["border-right-color","border-right-style","border-right-width"],"percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":["border-right-width","border-right-style","border-right-color"],"appliesto":"allElements","computed":["border-right-width","border-right-style","border-right-color"],"order":"orderOfAppearance","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-right"},"border-right-color":{"syntax":"<color>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-right-color"},"border-right-style":{"syntax":"<line-style>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-right-style"},"border-right-width":{"syntax":"<line-width>","media":"visual","inherited":false,"animationType":"length","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthOr0IfBorderRightStyleNoneOrHidden","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-right-width"},"border-spacing":{"syntax":"<length> <length>?","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Table"],"initial":"0","appliesto":"tableElements","computed":"twoAbsoluteLengths","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-spacing"},"border-start-end-radius":{"syntax":"<length-percentage>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElementsUAsNotRequiredWhenCollapse","computed":"twoAbsoluteLengthOrPercentages","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-start-end-radius"},"border-start-start-radius":{"syntax":"<length-percentage>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElementsUAsNotRequiredWhenCollapse","computed":"twoAbsoluteLengthOrPercentages","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-start-start-radius"},"border-style":{"syntax":"<line-style>{1,4}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":["border-top-style","border-right-style","border-bottom-style","border-left-style"],"appliesto":"allElements","computed":["border-bottom-style","border-left-style","border-right-style","border-top-style"],"order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-style"},"border-top":{"syntax":"<line-width> || <line-style> || <color>","media":"visual","inherited":false,"animationType":["border-top-color","border-top-style","border-top-width"],"percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":["border-top-width","border-top-style","border-top-color"],"appliesto":"allElements","computed":["border-top-width","border-top-style","border-top-color"],"order":"orderOfAppearance","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-top"},"border-top-color":{"syntax":"<color>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-top-color"},"border-top-left-radius":{"syntax":"<length-percentage>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["CSS Backgrounds and Borders"],"initial":"0","appliesto":"allElementsUAsNotRequiredWhenCollapse","computed":"twoAbsoluteLengthOrPercentages","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-top-left-radius"},"border-top-right-radius":{"syntax":"<length-percentage>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfBorderBox","groups":["CSS Backgrounds and Borders"],"initial":"0","appliesto":"allElementsUAsNotRequiredWhenCollapse","computed":"twoAbsoluteLengthOrPercentages","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-top-right-radius"},"border-top-style":{"syntax":"<line-style>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-top-style"},"border-top-width":{"syntax":"<line-width>","media":"visual","inherited":false,"animationType":"length","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"medium","appliesto":"allElements","computed":"absoluteLengthOr0IfBorderTopStyleNoneOrHidden","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-top-width"},"border-width":{"syntax":"<line-width>{1,4}","media":"visual","inherited":false,"animationType":["border-bottom-width","border-left-width","border-right-width","border-top-width"],"percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":["border-top-width","border-right-width","border-bottom-width","border-left-width"],"appliesto":"allElements","computed":["border-bottom-width","border-left-width","border-right-width","border-top-width"],"order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/border-width"},"bottom":{"syntax":"<length> | <percentage> | auto","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToContainingBlockHeight","groups":["CSS Positioning"],"initial":"auto","appliesto":"positionedElements","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/bottom"},"box-align":{"syntax":"start | center | end | baseline | stretch","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions","WebKit Extensions"],"initial":"stretch","appliesto":"elementsWithDisplayBoxOrInlineBox","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-align"},"box-decoration-break":{"syntax":"slice | clone","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Fragmentation"],"initial":"slice","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-decoration-break"},"box-direction":{"syntax":"normal | reverse | inherit","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions","WebKit Extensions"],"initial":"normal","appliesto":"elementsWithDisplayBoxOrInlineBox","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-direction"},"box-flex":{"syntax":"<number>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions","WebKit Extensions"],"initial":"0","appliesto":"directChildrenOfElementsWithDisplayMozBoxMozInlineBox","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-flex"},"box-flex-group":{"syntax":"<integer>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions","WebKit Extensions"],"initial":"1","appliesto":"inFlowChildrenOfBoxElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-flex-group"},"box-lines":{"syntax":"single | multiple","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions","WebKit Extensions"],"initial":"single","appliesto":"boxElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-lines"},"box-ordinal-group":{"syntax":"<integer>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions","WebKit Extensions"],"initial":"1","appliesto":"childrenOfBoxElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-ordinal-group"},"box-orient":{"syntax":"horizontal | vertical | inline-axis | block-axis | inherit","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions","WebKit Extensions"],"initial":"inlineAxisHorizontalInXUL","appliesto":"elementsWithDisplayBoxOrInlineBox","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-orient"},"box-pack":{"syntax":"start | center | end | justify","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions","WebKit Extensions"],"initial":"start","appliesto":"elementsWithDisplayMozBoxMozInlineBox","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-pack"},"box-shadow":{"syntax":"none | <shadow>#","media":"visual","inherited":false,"animationType":"shadowList","percentages":"no","groups":["CSS Backgrounds and Borders"],"initial":"none","appliesto":"allElements","computed":"absoluteLengthsSpecifiedColorAsSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-shadow"},"box-sizing":{"syntax":"content-box | border-box","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Basic User Interface"],"initial":"content-box","appliesto":"allElementsAcceptingWidthOrHeight","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/box-sizing"},"break-after":{"syntax":"auto | avoid | always | all | avoid-page | page | left | right | recto | verso | avoid-column | column | avoid-region | region","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Fragmentation"],"initial":"auto","appliesto":"blockLevelElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/break-after"},"break-before":{"syntax":"auto | avoid | always | all | avoid-page | page | left | right | recto | verso | avoid-column | column | avoid-region | region","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Fragmentation"],"initial":"auto","appliesto":"blockLevelElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/break-before"},"break-inside":{"syntax":"auto | avoid | avoid-page | avoid-column | avoid-region","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Fragmentation"],"initial":"auto","appliesto":"blockLevelElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/break-inside"},"caption-side":{"syntax":"top | bottom | block-start | block-end | inline-start | inline-end","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Table"],"initial":"top","appliesto":"tableCaptionElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/caption-side"},"caret-color":{"syntax":"auto | <color>","media":"interactive","inherited":true,"animationType":"color","percentages":"no","groups":["CSS Basic User Interface"],"initial":"auto","appliesto":"allElements","computed":"asAutoOrColor","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/caret-color"},"clear":{"syntax":"none | left | right | both | inline-start | inline-end","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Positioning"],"initial":"none","appliesto":"blockLevelElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/clear"},"clip":{"syntax":"<shape> | auto","media":"visual","inherited":false,"animationType":"rectangle","percentages":"no","groups":["CSS Masking"],"initial":"auto","appliesto":"absolutelyPositionedElements","computed":"autoOrRectangle","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/clip"},"clip-path":{"syntax":"<clip-source> | [ <basic-shape> || <geometry-box> ] | none","media":"visual","inherited":false,"animationType":"basicShapeOtherwiseNo","percentages":"referToReferenceBoxWhenSpecifiedOtherwiseBorderBox","groups":["CSS Masking"],"initial":"none","appliesto":"allElementsSVGContainerElements","computed":"asSpecifiedURLsAbsolute","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/clip-path"},"color":{"syntax":"<color>","media":"visual","inherited":true,"animationType":"color","percentages":"no","groups":["CSS Color"],"initial":"variesFromBrowserToBrowser","appliesto":"allElements","computed":"translucentValuesRGBAOtherwiseRGB","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/color"},"color-adjust":{"syntax":"economy | exact","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Color"],"initial":"economy","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/color-adjust"},"column-count":{"syntax":"<integer> | auto","media":"visual","inherited":false,"animationType":"integer","percentages":"no","groups":["CSS Columns"],"initial":"auto","appliesto":"blockContainersExceptTableWrappers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-count"},"column-fill":{"syntax":"auto | balance | balance-all","media":"visualInContinuousMediaNoEffectInOverflowColumns","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Columns"],"initial":"balance","appliesto":"multicolElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-fill"},"column-gap":{"syntax":"normal | <length-percentage>","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfContentArea","groups":["CSS Box Alignment"],"initial":"normal","appliesto":"multiColumnElementsFlexContainersGridContainers","computed":"asSpecifiedWithLengthsAbsoluteAndNormalComputingToZeroExceptMultiColumn","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-gap"},"column-rule":{"syntax":"<\'column-rule-width\'> || <\'column-rule-style\'> || <\'column-rule-color\'>","media":"visual","inherited":false,"animationType":["column-rule-color","column-rule-style","column-rule-width"],"percentages":"no","groups":["CSS Columns"],"initial":["column-rule-width","column-rule-style","column-rule-color"],"appliesto":"multicolElements","computed":["column-rule-color","column-rule-style","column-rule-width"],"order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-rule"},"column-rule-color":{"syntax":"<color>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Columns"],"initial":"currentcolor","appliesto":"multicolElements","computed":"computedColor","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-rule-color"},"column-rule-style":{"syntax":"<\'border-style\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Columns"],"initial":"none","appliesto":"multicolElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-rule-style"},"column-rule-width":{"syntax":"<\'border-width\'>","media":"visual","inherited":false,"animationType":"length","percentages":"no","groups":["CSS Columns"],"initial":"medium","appliesto":"multicolElements","computed":"absoluteLength0IfColumnRuleStyleNoneOrHidden","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-rule-width"},"column-span":{"syntax":"none | all","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Columns"],"initial":"none","appliesto":"inFlowBlockLevelElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-span"},"column-width":{"syntax":"<length> | auto","media":"visual","inherited":false,"animationType":"length","percentages":"no","groups":["CSS Columns"],"initial":"auto","appliesto":"blockContainersExceptTableWrappers","computed":"absoluteLengthZeroOrLarger","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-width"},"columns":{"syntax":"<\'column-width\'> || <\'column-count\'>","media":"visual","inherited":false,"animationType":["column-width","column-count"],"percentages":"no","groups":["CSS Columns"],"initial":["column-width","column-count"],"appliesto":"blockContainersExceptTableWrappers","computed":["column-width","column-count"],"order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/columns"},"contain":{"syntax":"none | strict | content | [ size || layout || style || paint ]","media":"all","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Containment"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/contain"},"content":{"syntax":"normal | none | [ <content-replacement> | <content-list> ] [/ <string> ]?","media":"all","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Generated Content"],"initial":"normal","appliesto":"beforeAndAfterPseudos","computed":"normalOnElementsForPseudosNoneAbsoluteURIStringOrAsSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/content"},"counter-increment":{"syntax":"[ <custom-ident> <integer>? ]+ | none","media":"all","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Counter Styles"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/counter-increment"},"counter-reset":{"syntax":"[ <custom-ident> <integer>? ]+ | none","media":"all","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Counter Styles"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/counter-reset"},"counter-set":{"syntax":"[ <custom-ident> <integer>? ]+ | none","media":"all","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Counter Styles"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/counter-set"},"cursor":{"syntax":"[ [ <url> [ <x> <y> ]? , ]* [ auto | default | none | context-menu | help | pointer | progress | wait | cell | crosshair | text | vertical-text | alias | copy | move | no-drop | not-allowed | e-resize | n-resize | ne-resize | nw-resize | s-resize | se-resize | sw-resize | w-resize | ew-resize | ns-resize | nesw-resize | nwse-resize | col-resize | row-resize | all-scroll | zoom-in | zoom-out | grab | grabbing ] ]","media":["visual","interactive"],"inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Basic User Interface"],"initial":"auto","appliesto":"allElements","computed":"asSpecifiedURLsAbsolute","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/cursor"},"direction":{"syntax":"ltr | rtl","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Writing Modes"],"initial":"ltr","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/direction"},"display":{"syntax":"[ <display-outside> || <display-inside> ] | <display-listitem> | <display-internal> | <display-box> | <display-legacy>","media":"all","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Display"],"initial":"inline","appliesto":"allElements","computed":"asSpecifiedExceptPositionedFloatingAndRootElementsKeywordMaybeDifferent","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/display"},"empty-cells":{"syntax":"show | hide","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Table"],"initial":"show","appliesto":"tableCellElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/empty-cells"},"filter":{"syntax":"none | <filter-function-list>","media":"visual","inherited":false,"animationType":"filterList","percentages":"no","groups":["Filter Effects"],"initial":"none","appliesto":"allElementsSVGContainerElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/filter"},"flex":{"syntax":"none | [ <\'flex-grow\'> <\'flex-shrink\'>? || <\'flex-basis\'> ]","media":"visual","inherited":false,"animationType":["flex-grow","flex-shrink","flex-basis"],"percentages":"no","groups":["CSS Flexible Box Layout"],"initial":["flex-grow","flex-shrink","flex-basis"],"appliesto":"flexItemsAndInFlowPseudos","computed":["flex-grow","flex-shrink","flex-basis"],"order":"orderOfAppearance","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/flex"},"flex-basis":{"syntax":"content | <\'width\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToFlexContainersInnerMainSize","groups":["CSS Flexible Box Layout"],"initial":"auto","appliesto":"flexItemsAndInFlowPseudos","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"lengthOrPercentageBeforeKeywordIfBothPresent","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/flex-basis"},"flex-direction":{"syntax":"row | row-reverse | column | column-reverse","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Flexible Box Layout"],"initial":"row","appliesto":"flexContainers","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/flex-direction"},"flex-flow":{"syntax":"<\'flex-direction\'> || <\'flex-wrap\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Flexible Box Layout"],"initial":["flex-direction","flex-wrap"],"appliesto":"flexContainers","computed":["flex-direction","flex-wrap"],"order":"orderOfAppearance","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/flex-flow"},"flex-grow":{"syntax":"<number>","media":"visual","inherited":false,"animationType":"number","percentages":"no","groups":["CSS Flexible Box Layout"],"initial":"0","appliesto":"flexItemsAndInFlowPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/flex-grow"},"flex-shrink":{"syntax":"<number>","media":"visual","inherited":false,"animationType":"number","percentages":"no","groups":["CSS Flexible Box Layout"],"initial":"1","appliesto":"flexItemsAndInFlowPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/flex-shrink"},"flex-wrap":{"syntax":"nowrap | wrap | wrap-reverse","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Flexible Box Layout"],"initial":"nowrap","appliesto":"flexContainers","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/flex-wrap"},"float":{"syntax":"left | right | none | inline-start | inline-end","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Positioning"],"initial":"none","appliesto":"allElementsNoEffectIfDisplayNone","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/float"},"font":{"syntax":"[ [ <\'font-style\'> || <font-variant-css21> || <\'font-weight\'> || <\'font-stretch\'> ]? <\'font-size\'> [ / <\'line-height\'> ]? <\'font-family\'> ] | caption | icon | menu | message-box | small-caption | status-bar","media":"visual","inherited":true,"animationType":["font-style","font-variant","font-weight","font-stretch","font-size","line-height","font-family"],"percentages":["font-size","line-height"],"groups":["CSS Fonts"],"initial":["font-style","font-variant","font-weight","font-stretch","font-size","line-height","font-family"],"appliesto":"allElements","computed":["font-style","font-variant","font-weight","font-stretch","font-size","line-height","font-family"],"order":"orderOfAppearance","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font"},"font-family":{"syntax":"[ <family-name> | <generic-family> ]#","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"dependsOnUserAgent","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-family"},"font-feature-settings":{"syntax":"normal | <feature-tag-value>#","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-feature-settings"},"font-kerning":{"syntax":"auto | normal | none","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-kerning"},"font-language-override":{"syntax":"normal | <string>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-language-override"},"font-optical-sizing":{"syntax":"auto | none","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-optical-sizing"},"font-variation-settings":{"syntax":"normal | [ <string> <number> ]#","media":"visual","inherited":true,"animationType":"transform","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-variation-settings"},"font-size":{"syntax":"<absolute-size> | <relative-size> | <length-percentage>","media":"visual","inherited":true,"animationType":"length","percentages":"referToParentElementsFontSize","groups":["CSS Fonts"],"initial":"medium","appliesto":"allElements","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-size"},"font-size-adjust":{"syntax":"none | <number>","media":"visual","inherited":true,"animationType":"number","percentages":"no","groups":["CSS Fonts"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-size-adjust"},"font-smooth":{"syntax":"auto | never | always | <absolute-size> | <length>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-smooth"},"font-stretch":{"syntax":"<font-stretch-absolute>","media":"visual","inherited":true,"animationType":"fontStretch","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-stretch"},"font-style":{"syntax":"normal | italic | oblique <angle>?","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-style"},"font-synthesis":{"syntax":"none | [ weight || style ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"weight style","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-synthesis"},"font-variant":{"syntax":"normal | none | [ <common-lig-values> || <discretionary-lig-values> || <historical-lig-values> || <contextual-alt-values> || stylistic( <feature-value-name> ) || historical-forms || styleset( <feature-value-name># ) || character-variant( <feature-value-name># ) || swash( <feature-value-name> ) || ornaments( <feature-value-name> ) || annotation( <feature-value-name> ) || [ small-caps | all-small-caps | petite-caps | all-petite-caps | unicase | titling-caps ] || <numeric-figure-values> || <numeric-spacing-values> || <numeric-fraction-values> || ordinal || slashed-zero || <east-asian-variant-values> || <east-asian-width-values> || ruby ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-variant"},"font-variant-alternates":{"syntax":"normal | [ stylistic( <feature-value-name> ) || historical-forms || styleset( <feature-value-name># ) || character-variant( <feature-value-name># ) || swash( <feature-value-name> ) || ornaments( <feature-value-name> ) || annotation( <feature-value-name> ) ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-variant-alternates"},"font-variant-caps":{"syntax":"normal | small-caps | all-small-caps | petite-caps | all-petite-caps | unicase | titling-caps","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-variant-caps"},"font-variant-east-asian":{"syntax":"normal | [ <east-asian-variant-values> || <east-asian-width-values> || ruby ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-variant-east-asian"},"font-variant-ligatures":{"syntax":"normal | none | [ <common-lig-values> || <discretionary-lig-values> || <historical-lig-values> || <contextual-alt-values> ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-variant-ligatures"},"font-variant-numeric":{"syntax":"normal | [ <numeric-figure-values> || <numeric-spacing-values> || <numeric-fraction-values> || ordinal || slashed-zero ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-variant-numeric"},"font-variant-position":{"syntax":"normal | sub | super","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-variant-position"},"font-weight":{"syntax":"<font-weight-absolute> | bolder | lighter","media":"visual","inherited":true,"animationType":"fontWeight","percentages":"no","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"keywordOrNumericalValueBolderLighterTransformedToRealValue","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/font-weight"},"gap":{"syntax":"<\'row-gap\'> <\'column-gap\'>?","media":"visual","inherited":false,"animationType":["row-gap","column-gap"],"percentages":"no","groups":["CSS Box Alignment"],"initial":["row-gap","column-gap"],"appliesto":"multiColumnElementsFlexContainersGridContainers","computed":["row-gap","column-gap"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/gap"},"grid":{"syntax":"<\'grid-template\'> | <\'grid-template-rows\'> / [ auto-flow && dense? ] <\'grid-auto-columns\'>? | [ auto-flow && dense? ] <\'grid-auto-rows\'>? / <\'grid-template-columns\'>","media":"visual","inherited":false,"animationType":"discrete","percentages":["grid-template-rows","grid-template-columns","grid-auto-rows","grid-auto-columns"],"groups":["CSS Grid Layout"],"initial":["grid-template-rows","grid-template-columns","grid-template-areas","grid-auto-rows","grid-auto-columns","grid-auto-flow","grid-column-gap","grid-row-gap","column-gap","row-gap"],"appliesto":"gridContainers","computed":["grid-template-rows","grid-template-columns","grid-template-areas","grid-auto-rows","grid-auto-columns","grid-auto-flow","grid-column-gap","grid-row-gap","column-gap","row-gap"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid"},"grid-area":{"syntax":"<grid-line> [ / <grid-line> ]{0,3}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":["grid-row-start","grid-column-start","grid-row-end","grid-column-end"],"appliesto":"gridItemsAndBoxesWithinGridContainer","computed":["grid-row-start","grid-column-start","grid-row-end","grid-column-end"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-area"},"grid-auto-columns":{"syntax":"<track-size>+","media":"visual","inherited":false,"animationType":"discrete","percentages":"referToDimensionOfContentArea","groups":["CSS Grid Layout"],"initial":"auto","appliesto":"gridContainers","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-auto-columns"},"grid-auto-flow":{"syntax":"[ row | column ] || dense","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":"row","appliesto":"gridContainers","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-auto-flow"},"grid-auto-rows":{"syntax":"<track-size>+","media":"visual","inherited":false,"animationType":"discrete","percentages":"referToDimensionOfContentArea","groups":["CSS Grid Layout"],"initial":"auto","appliesto":"gridContainers","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-auto-rows"},"grid-column":{"syntax":"<grid-line> [ / <grid-line> ]?","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":["grid-column-start","grid-column-end"],"appliesto":"gridItemsAndBoxesWithinGridContainer","computed":["grid-column-start","grid-column-end"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-column"},"grid-column-end":{"syntax":"<grid-line>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":"auto","appliesto":"gridItemsAndBoxesWithinGridContainer","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-column-end"},"grid-column-gap":{"syntax":"<length-percentage>","media":"visual","inherited":false,"animationType":"length","percentages":"referToDimensionOfContentArea","groups":["CSS Grid Layout"],"initial":"0","appliesto":"gridContainers","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/column-gap"},"grid-column-start":{"syntax":"<grid-line>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":"auto","appliesto":"gridItemsAndBoxesWithinGridContainer","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-column-start"},"grid-gap":{"syntax":"<\'grid-row-gap\'> <\'grid-column-gap\'>?","media":"visual","inherited":false,"animationType":["grid-row-gap","grid-column-gap"],"percentages":"no","groups":["CSS Grid Layout"],"initial":["grid-row-gap","grid-column-gap"],"appliesto":"gridContainers","computed":["grid-row-gap","grid-column-gap"],"order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/gap"},"grid-row":{"syntax":"<grid-line> [ / <grid-line> ]?","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":["grid-row-start","grid-row-end"],"appliesto":"gridItemsAndBoxesWithinGridContainer","computed":["grid-row-start","grid-row-end"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-row"},"grid-row-end":{"syntax":"<grid-line>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":"auto","appliesto":"gridItemsAndBoxesWithinGridContainer","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-row-end"},"grid-row-gap":{"syntax":"<length-percentage>","media":"visual","inherited":false,"animationType":"length","percentages":"referToDimensionOfContentArea","groups":["CSS Grid Layout"],"initial":"0","appliesto":"gridContainers","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/row-gap"},"grid-row-start":{"syntax":"<grid-line>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":"auto","appliesto":"gridItemsAndBoxesWithinGridContainer","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-row-start"},"grid-template":{"syntax":"none | [ <\'grid-template-rows\'> / <\'grid-template-columns\'> ] | [ <line-names>? <string> <track-size>? <line-names>? ]+ [ / <explicit-track-list> ]?","media":"visual","inherited":false,"animationType":"discrete","percentages":["grid-template-columns","grid-template-rows"],"groups":["CSS Grid Layout"],"initial":["grid-template-columns","grid-template-rows","grid-template-areas"],"appliesto":"gridContainers","computed":["grid-template-columns","grid-template-rows","grid-template-areas"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-template"},"grid-template-areas":{"syntax":"none | <string>+","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":"none","appliesto":"gridContainers","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-template-areas"},"grid-template-columns":{"syntax":"none | <track-list> | <auto-track-list> | subgrid <line-name-list>?","media":"visual","inherited":false,"animationType":"simpleListOfLpcDifferenceLpc","percentages":"referToDimensionOfContentArea","groups":["CSS Grid Layout"],"initial":"none","appliesto":"gridContainers","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-template-columns"},"grid-template-rows":{"syntax":"none | <track-list> | <auto-track-list> | subgrid <line-name-list>?","media":"visual","inherited":false,"animationType":"simpleListOfLpcDifferenceLpc","percentages":"referToDimensionOfContentArea","groups":["CSS Grid Layout"],"initial":"none","appliesto":"gridContainers","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/grid-template-rows"},"hanging-punctuation":{"syntax":"none | [ first || [ force-end | allow-end ] || last ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/hanging-punctuation"},"height":{"syntax":"auto | <length> | <percentage> | min-content | max-content | fit-content(<length-percentage>)","media":"visual","inherited":false,"animationType":"lpc","percentages":"regardingHeightOfGeneratedBoxContainingBlockPercentagesRelativeToContainingBlock","groups":["CSS Box Model"],"initial":"auto","appliesto":"allElementsButNonReplacedAndTableColumns","computed":"percentageAutoOrAbsoluteLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/height"},"hyphens":{"syntax":"none | manual | auto","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"manual","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/hyphens"},"image-orientation":{"syntax":"from-image | <angle> | [ <angle>? flip ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Images"],"initial":"from-image","appliesto":"allElements","computed":"angleRoundedToNextQuarter","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/image-orientation"},"image-rendering":{"syntax":"auto | crisp-edges | pixelated","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Images"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/image-rendering"},"image-resolution":{"syntax":"[ from-image || <resolution> ] && snap?","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Images"],"initial":"1dppx","appliesto":"allElements","computed":"asSpecifiedWithExceptionOfResolution","order":"uniqueOrder","status":"experimental"},"ime-mode":{"syntax":"auto | normal | active | inactive | disabled","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Basic User Interface"],"initial":"auto","appliesto":"textFields","computed":"asSpecified","order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/ime-mode"},"initial-letter":{"syntax":"normal | [ <number> <integer>? ]","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Inline"],"initial":"normal","appliesto":"firstLetterPseudoElementsAndInlineLevelFirstChildren","computed":"asSpecified","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/initial-letter"},"initial-letter-align":{"syntax":"[ auto | alphabetic | hanging | ideographic ]","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Inline"],"initial":"auto","appliesto":"firstLetterPseudoElementsAndInlineLevelFirstChildren","computed":"asSpecified","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/initial-letter-align"},"inline-size":{"syntax":"<\'width\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"inlineSizeOfContainingBlock","groups":["CSS Logical Properties"],"initial":"auto","appliesto":"sameAsWidthAndHeight","computed":"sameAsWidthAndHeight","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/inline-size"},"inset":{"syntax":"<\'top\'>{1,4}","media":"visual","inherited":false,"animationType":"lpc","percentages":"logicalHeightOfContainingBlock","groups":["CSS Logical Properties"],"initial":"auto","appliesto":"positionedElements","computed":"sameAsBoxOffsets","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/inset"},"inset-block":{"syntax":"<\'top\'>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"logicalHeightOfContainingBlock","groups":["CSS Logical Properties"],"initial":"auto","appliesto":"positionedElements","computed":"sameAsBoxOffsets","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/inset-block"},"inset-block-end":{"syntax":"<\'top\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"logicalHeightOfContainingBlock","groups":["CSS Logical Properties"],"initial":"auto","appliesto":"positionedElements","computed":"sameAsBoxOffsets","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/inset-block-end"},"inset-block-start":{"syntax":"<\'top\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"logicalHeightOfContainingBlock","groups":["CSS Logical Properties"],"initial":"auto","appliesto":"positionedElements","computed":"sameAsBoxOffsets","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/inset-block-start"},"inset-inline":{"syntax":"<\'top\'>{1,2}","media":"visual","inherited":false,"animationType":"lpc","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"auto","appliesto":"positionedElements","computed":"sameAsBoxOffsets","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/inset-inline"},"inset-inline-end":{"syntax":"<\'top\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"auto","appliesto":"positionedElements","computed":"sameAsBoxOffsets","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/inset-inline-end"},"inset-inline-start":{"syntax":"<\'top\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"auto","appliesto":"positionedElements","computed":"sameAsBoxOffsets","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/inset-inline-start"},"isolation":{"syntax":"auto | isolate","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Compositing and Blending"],"initial":"auto","appliesto":"allElementsSVGContainerGraphicsAndGraphicsReferencingElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/isolation"},"justify-content":{"syntax":"normal | <content-distribution> | <overflow-position>? [ <content-position> | left | right ]","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Alignment"],"initial":"normal","appliesto":"flexContainers","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/justify-content"},"justify-items":{"syntax":"normal | stretch | <baseline-position> | <overflow-position>? [ <self-position> | left | right ] | legacy | legacy && [ left | right | center ]","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Alignment"],"initial":"legacy","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/justify-items"},"justify-self":{"syntax":"auto | normal | stretch | <baseline-position> | <overflow-position>? [ <self-position> | left | right ]","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Alignment"],"initial":"auto","appliesto":"blockLevelBoxesAndAbsolutelyPositionedBoxesAndGridItems","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/justify-self"},"justify-tracks":{"syntax":"[ normal | <content-distribution> | <overflow-position>? [ <content-position> | left | right ] ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":"normal","appliesto":"gridContainersWithMasonryLayoutInTheirInlineAxis","computed":"asSpecified","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/justify-tracks"},"left":{"syntax":"<length> | <percentage> | auto","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToWidthOfContainingBlock","groups":["CSS Positioning"],"initial":"auto","appliesto":"positionedElements","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/left"},"letter-spacing":{"syntax":"normal | <length>","media":"visual","inherited":true,"animationType":"length","percentages":"no","groups":["CSS Text"],"initial":"normal","appliesto":"allElements","computed":"optimumValueOfAbsoluteLengthOrNormal","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/letter-spacing"},"line-break":{"syntax":"auto | loose | normal | strict | anywhere","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/line-break"},"line-clamp":{"syntax":"none | <integer>","media":"visual","inherited":false,"animationType":"integer","percentages":"no","groups":["CSS Overflow"],"initial":"none","appliesto":"blockContainersExceptMultiColumnContainers","computed":"asSpecified","order":"perGrammar","status":"experimental"},"line-height":{"syntax":"normal | <number> | <length> | <percentage>","media":"visual","inherited":true,"animationType":"numberOrLength","percentages":"referToElementFontSize","groups":["CSS Fonts"],"initial":"normal","appliesto":"allElements","computed":"absoluteLengthOrAsSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/line-height"},"line-height-step":{"syntax":"<length>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fonts"],"initial":"0","appliesto":"blockContainers","computed":"absoluteLength","order":"perGrammar","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/line-height-step"},"list-style":{"syntax":"<\'list-style-type\'> || <\'list-style-position\'> || <\'list-style-image\'>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Lists and Counters"],"initial":["list-style-type","list-style-position","list-style-image"],"appliesto":"listItems","computed":["list-style-image","list-style-position","list-style-type"],"order":"orderOfAppearance","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/list-style"},"list-style-image":{"syntax":"<url> | none","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Lists and Counters"],"initial":"none","appliesto":"listItems","computed":"noneOrImageWithAbsoluteURI","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/list-style-image"},"list-style-position":{"syntax":"inside | outside","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Lists and Counters"],"initial":"outside","appliesto":"listItems","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/list-style-position"},"list-style-type":{"syntax":"<counter-style> | <string> | none","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Lists and Counters"],"initial":"disc","appliesto":"listItems","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/list-style-type"},"margin":{"syntax":"[ <length> | <percentage> | auto ]{1,4}","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":["margin-bottom","margin-left","margin-right","margin-top"],"appliesto":"allElementsExceptTableDisplayTypes","computed":["margin-bottom","margin-left","margin-right","margin-top"],"order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin"},"margin-block":{"syntax":"<\'margin-left\'>{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"dependsOnLayoutModel","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsMargin","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-block"},"margin-block-end":{"syntax":"<\'margin-left\'>","media":"visual","inherited":false,"animationType":"length","percentages":"dependsOnLayoutModel","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsMargin","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-block-end"},"margin-block-start":{"syntax":"<\'margin-left\'>","media":"visual","inherited":false,"animationType":"length","percentages":"dependsOnLayoutModel","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsMargin","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-block-start"},"margin-bottom":{"syntax":"<length> | <percentage> | auto","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"0","appliesto":"allElementsExceptTableDisplayTypes","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-bottom"},"margin-inline":{"syntax":"<\'margin-left\'>{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"dependsOnLayoutModel","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsMargin","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-inline"},"margin-inline-end":{"syntax":"<\'margin-left\'>","media":"visual","inherited":false,"animationType":"length","percentages":"dependsOnLayoutModel","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsMargin","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-inline-end"},"margin-inline-start":{"syntax":"<\'margin-left\'>","media":"visual","inherited":false,"animationType":"length","percentages":"dependsOnLayoutModel","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsMargin","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-inline-start"},"margin-left":{"syntax":"<length> | <percentage> | auto","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"0","appliesto":"allElementsExceptTableDisplayTypes","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-left"},"margin-right":{"syntax":"<length> | <percentage> | auto","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"0","appliesto":"allElementsExceptTableDisplayTypes","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-right"},"margin-top":{"syntax":"<length> | <percentage> | auto","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"0","appliesto":"allElementsExceptTableDisplayTypes","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-top"},"margin-trim":{"syntax":"none | in-flow | all","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Model"],"initial":"none","appliesto":"blockContainersAndMultiColumnContainers","computed":"asSpecified","order":"perGrammar","alsoAppliesTo":["::first-letter","::first-line"],"status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/margin-trim"},"mask":{"syntax":"<mask-layer>#","media":"visual","inherited":false,"animationType":["mask-image","mask-mode","mask-repeat","mask-position","mask-clip","mask-origin","mask-size","mask-composite"],"percentages":["mask-position"],"groups":["CSS Masking"],"initial":["mask-image","mask-mode","mask-repeat","mask-position","mask-clip","mask-origin","mask-size","mask-composite"],"appliesto":"allElementsSVGContainerElements","computed":["mask-image","mask-mode","mask-repeat","mask-position","mask-clip","mask-origin","mask-size","mask-composite"],"order":"perGrammar","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask"},"mask-border":{"syntax":"<\'mask-border-source\'> || <\'mask-border-slice\'> [ / <\'mask-border-width\'>? [ / <\'mask-border-outset\'> ]? ]? || <\'mask-border-repeat\'> || <\'mask-border-mode\'>","media":"visual","inherited":false,"animationType":["mask-border-mode","mask-border-outset","mask-border-repeat","mask-border-slice","mask-border-source","mask-border-width"],"percentages":["mask-border-slice","mask-border-width"],"groups":["CSS Masking"],"initial":["mask-border-mode","mask-border-outset","mask-border-repeat","mask-border-slice","mask-border-source","mask-border-width"],"appliesto":"allElementsSVGContainerElements","computed":["mask-border-mode","mask-border-outset","mask-border-repeat","mask-border-slice","mask-border-source","mask-border-width"],"order":"perGrammar","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-border"},"mask-border-mode":{"syntax":"luminance | alpha","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"alpha","appliesto":"allElementsSVGContainerElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-border-mode"},"mask-border-outset":{"syntax":"[ <length> | <number> ]{1,4}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"0","appliesto":"allElementsSVGContainerElements","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-border-outset"},"mask-border-repeat":{"syntax":"[ stretch | repeat | round | space ]{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"stretch","appliesto":"allElementsSVGContainerElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-border-repeat"},"mask-border-slice":{"syntax":"<number-percentage>{1,4} fill?","media":"visual","inherited":false,"animationType":"discrete","percentages":"referToSizeOfMaskBorderImage","groups":["CSS Masking"],"initial":"0","appliesto":"allElementsSVGContainerElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-border-slice"},"mask-border-source":{"syntax":"none | <image>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"none","appliesto":"allElementsSVGContainerElements","computed":"asSpecifiedURLsAbsolute","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-border-source"},"mask-border-width":{"syntax":"[ <length-percentage> | <number> | auto ]{1,4}","media":"visual","inherited":false,"animationType":"discrete","percentages":"relativeToMaskBorderImageArea","groups":["CSS Masking"],"initial":"auto","appliesto":"allElementsSVGContainerElements","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-border-width"},"mask-clip":{"syntax":"[ <geometry-box> | no-clip ]#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"border-box","appliesto":"allElementsSVGContainerElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-clip"},"mask-composite":{"syntax":"<compositing-operator>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"add","appliesto":"allElementsSVGContainerElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-composite"},"mask-image":{"syntax":"<mask-reference>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"none","appliesto":"allElementsSVGContainerElements","computed":"asSpecifiedURLsAbsolute","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-image"},"mask-mode":{"syntax":"<masking-mode>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"match-source","appliesto":"allElementsSVGContainerElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-mode"},"mask-origin":{"syntax":"<geometry-box>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"border-box","appliesto":"allElementsSVGContainerElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-origin"},"mask-position":{"syntax":"<position>#","media":"visual","inherited":false,"animationType":"repeatableListOfSimpleListOfLpc","percentages":"referToSizeOfMaskPaintingArea","groups":["CSS Masking"],"initial":"center","appliesto":"allElementsSVGContainerElements","computed":"consistsOfTwoKeywordsForOriginAndOffsets","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-position"},"mask-repeat":{"syntax":"<repeat-style>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"no-repeat","appliesto":"allElementsSVGContainerElements","computed":"consistsOfTwoDimensionKeywords","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-repeat"},"mask-size":{"syntax":"<bg-size>#","media":"visual","inherited":false,"animationType":"repeatableListOfSimpleListOfLpc","percentages":"no","groups":["CSS Masking"],"initial":"auto","appliesto":"allElementsSVGContainerElements","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-size"},"mask-type":{"syntax":"luminance | alpha","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Masking"],"initial":"luminance","appliesto":"maskElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mask-type"},"masonry-auto-flow":{"syntax":"[ pack | next ] || [ definite-first | ordered ]","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Grid Layout"],"initial":"pack","appliesto":"gridContainersWithMasonryLayout","computed":"asSpecified","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/masonry-auto-flow"},"math-style":{"syntax":"normal | compact","media":"visual","inherited":true,"animationType":"notAnimatable","percentages":"no","groups":["MathML"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/math-style"},"max-block-size":{"syntax":"<\'max-width\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"blockSizeOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsWidthAndHeight","computed":"sameAsMaxWidthAndMaxHeight","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/max-block-size"},"max-height":{"syntax":"none | <length-percentage> | min-content | max-content | fit-content(<length-percentage>)","media":"visual","inherited":false,"animationType":"lpc","percentages":"regardingHeightOfGeneratedBoxContainingBlockPercentagesNone","groups":["CSS Box Model"],"initial":"none","appliesto":"allElementsButNonReplacedAndTableColumns","computed":"percentageAsSpecifiedAbsoluteLengthOrNone","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/max-height"},"max-inline-size":{"syntax":"<\'max-width\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"inlineSizeOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsWidthAndHeight","computed":"sameAsMaxWidthAndMaxHeight","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/max-inline-size"},"max-lines":{"syntax":"none | <integer>","media":"visual","inherited":false,"animationType":"integer","percentages":"no","groups":["CSS Overflow"],"initial":"none","appliesto":"blockContainersExceptMultiColumnContainers","computed":"asSpecified","order":"perGrammar","status":"experimental"},"max-width":{"syntax":"none | <length-percentage> | min-content | max-content | fit-content(<length-percentage>)","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"none","appliesto":"allElementsButNonReplacedAndTableRows","computed":"percentageAsSpecifiedAbsoluteLengthOrNone","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/max-width"},"min-block-size":{"syntax":"<\'min-width\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"blockSizeOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsWidthAndHeight","computed":"sameAsMinWidthAndMinHeight","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/min-block-size"},"min-height":{"syntax":"auto | <length> | <percentage> | min-content | max-content | fit-content(<length-percentage>)","media":"visual","inherited":false,"animationType":"lpc","percentages":"regardingHeightOfGeneratedBoxContainingBlockPercentages0","groups":["CSS Box Model"],"initial":"auto","appliesto":"allElementsButNonReplacedAndTableColumns","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/min-height"},"min-inline-size":{"syntax":"<\'min-width\'>","media":"visual","inherited":false,"animationType":"lpc","percentages":"inlineSizeOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"sameAsWidthAndHeight","computed":"sameAsMinWidthAndMinHeight","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/min-inline-size"},"min-width":{"syntax":"auto | <length> | <percentage> | min-content | max-content | fit-content(<length-percentage>)","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"auto","appliesto":"allElementsButNonReplacedAndTableRows","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/min-width"},"mix-blend-mode":{"syntax":"<blend-mode>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Compositing and Blending"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/mix-blend-mode"},"object-fit":{"syntax":"fill | contain | cover | none | scale-down","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Images"],"initial":"fill","appliesto":"replacedElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/object-fit"},"object-position":{"syntax":"<position>","media":"visual","inherited":true,"animationType":"repeatableListOfSimpleListOfLpc","percentages":"referToWidthAndHeightOfElement","groups":["CSS Images"],"initial":"50% 50%","appliesto":"replacedElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/object-position"},"offset":{"syntax":"[ <\'offset-position\'>? [ <\'offset-path\'> [ <\'offset-distance\'> || <\'offset-rotate\'> ]? ]? ]! [ / <\'offset-anchor\'> ]?","media":"visual","inherited":false,"animationType":["offset-position","offset-path","offset-distance","offset-anchor","offset-rotate"],"percentages":["offset-position","offset-distance","offset-anchor"],"groups":["CSS Motion Path"],"initial":["offset-position","offset-path","offset-distance","offset-anchor","offset-rotate"],"appliesto":"transformableElements","computed":["offset-position","offset-path","offset-distance","offset-anchor","offset-rotate"],"order":"perGrammar","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/offset"},"offset-anchor":{"syntax":"auto | <position>","media":"visual","inherited":false,"animationType":"position","percentages":"relativeToWidthAndHeight","groups":["CSS Motion Path"],"initial":"auto","appliesto":"transformableElements","computed":"forLengthAbsoluteValueOtherwisePercentage","order":"perGrammar","status":"standard"},"offset-distance":{"syntax":"<length-percentage>","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToTotalPathLength","groups":["CSS Motion Path"],"initial":"0","appliesto":"transformableElements","computed":"forLengthAbsoluteValueOtherwisePercentage","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/offset-distance"},"offset-path":{"syntax":"none | ray( [ <angle> && <size> && contain? ] ) | <path()> | <url> | [ <basic-shape> || <geometry-box> ]","media":"visual","inherited":false,"animationType":"angleOrBasicShapeOrPath","percentages":"no","groups":["CSS Motion Path"],"initial":"none","appliesto":"transformableElements","computed":"asSpecified","order":"perGrammar","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/offset-path"},"offset-position":{"syntax":"auto | <position>","media":"visual","inherited":false,"animationType":"position","percentages":"referToSizeOfContainingBlock","groups":["CSS Motion Path"],"initial":"auto","appliesto":"transformableElements","computed":"forLengthAbsoluteValueOtherwisePercentage","order":"perGrammar","status":"experimental"},"offset-rotate":{"syntax":"[ auto | reverse ] || <angle>","media":"visual","inherited":false,"animationType":"angleOrBasicShapeOrPath","percentages":"no","groups":["CSS Motion Path"],"initial":"auto","appliesto":"transformableElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/offset-rotate"},"opacity":{"syntax":"<alpha-value>","media":"visual","inherited":false,"animationType":"number","percentages":"no","groups":["CSS Color"],"initial":"1.0","appliesto":"allElements","computed":"specifiedValueClipped0To1","order":"uniqueOrder","alsoAppliesTo":["::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/opacity"},"order":{"syntax":"<integer>","media":"visual","inherited":false,"animationType":"integer","percentages":"no","groups":["CSS Flexible Box Layout"],"initial":"0","appliesto":"flexItemsGridItemsAbsolutelyPositionedContainerChildren","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/order"},"orphans":{"syntax":"<integer>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fragmentation"],"initial":"2","appliesto":"blockContainerElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/orphans"},"outline":{"syntax":"[ <\'outline-color\'> || <\'outline-style\'> || <\'outline-width\'> ]","media":["visual","interactive"],"inherited":false,"animationType":["outline-color","outline-width","outline-style"],"percentages":"no","groups":["CSS Basic User Interface"],"initial":["outline-color","outline-style","outline-width"],"appliesto":"allElements","computed":["outline-color","outline-width","outline-style"],"order":"orderOfAppearance","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/outline"},"outline-color":{"syntax":"<color> | invert","media":["visual","interactive"],"inherited":false,"animationType":"color","percentages":"no","groups":["CSS Basic User Interface"],"initial":"invertOrCurrentColor","appliesto":"allElements","computed":"invertForTranslucentColorRGBAOtherwiseRGB","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/outline-color"},"outline-offset":{"syntax":"<length>","media":["visual","interactive"],"inherited":false,"animationType":"length","percentages":"no","groups":["CSS Basic User Interface"],"initial":"0","appliesto":"allElements","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/outline-offset"},"outline-style":{"syntax":"auto | <\'border-style\'>","media":["visual","interactive"],"inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Basic User Interface"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/outline-style"},"outline-width":{"syntax":"<line-width>","media":["visual","interactive"],"inherited":false,"animationType":"length","percentages":"no","groups":["CSS Basic User Interface"],"initial":"medium","appliesto":"allElements","computed":"absoluteLength0ForNone","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/outline-width"},"overflow":{"syntax":"[ visible | hidden | clip | scroll | auto ]{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Overflow"],"initial":"visible","appliesto":"blockContainersFlexContainersGridContainers","computed":["overflow-x","overflow-y"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overflow"},"overflow-anchor":{"syntax":"auto | none","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Scroll Anchoring"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard"},"overflow-block":{"syntax":"visible | hidden | clip | scroll | auto","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Overflow"],"initial":"auto","appliesto":"blockContainersFlexContainersGridContainers","computed":"asSpecifiedButVisibleOrClipReplacedToAutoOrHiddenIfOtherValueDifferent","order":"perGrammar","status":"standard"},"overflow-clip-box":{"syntax":"padding-box | content-box","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Mozilla Extensions"],"initial":"padding-box","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Mozilla/CSS/overflow-clip-box"},"overflow-inline":{"syntax":"visible | hidden | clip | scroll | auto","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Overflow"],"initial":"auto","appliesto":"blockContainersFlexContainersGridContainers","computed":"asSpecifiedButVisibleOrClipReplacedToAutoOrHiddenIfOtherValueDifferent","order":"perGrammar","status":"standard"},"overflow-wrap":{"syntax":"normal | break-word | anywhere","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"normal","appliesto":"nonReplacedInlineElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overflow-wrap"},"overflow-x":{"syntax":"visible | hidden | clip | scroll | auto","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Overflow"],"initial":"visible","appliesto":"blockContainersFlexContainersGridContainers","computed":"asSpecifiedButVisibleOrClipReplacedToAutoOrHiddenIfOtherValueDifferent","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overflow-x"},"overflow-y":{"syntax":"visible | hidden | clip | scroll | auto","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Overflow"],"initial":"visible","appliesto":"blockContainersFlexContainersGridContainers","computed":"asSpecifiedButVisibleOrClipReplacedToAutoOrHiddenIfOtherValueDifferent","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overflow-y"},"overscroll-behavior":{"syntax":"[ contain | none | auto ]{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Model"],"initial":"auto","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overscroll-behavior"},"overscroll-behavior-block":{"syntax":"contain | none | auto","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Model"],"initial":"auto","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overscroll-behavior-block"},"overscroll-behavior-inline":{"syntax":"contain | none | auto","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Model"],"initial":"auto","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overscroll-behavior-inline"},"overscroll-behavior-x":{"syntax":"contain | none | auto","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Model"],"initial":"auto","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overscroll-behavior-x"},"overscroll-behavior-y":{"syntax":"contain | none | auto","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Model"],"initial":"auto","appliesto":"nonReplacedBlockAndInlineBlockElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overscroll-behavior-y"},"padding":{"syntax":"[ <length> | <percentage> ]{1,4}","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":["padding-bottom","padding-left","padding-right","padding-top"],"appliesto":"allElementsExceptInternalTableDisplayTypes","computed":["padding-bottom","padding-left","padding-right","padding-top"],"order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding"},"padding-block":{"syntax":"<\'padding-left\'>{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElements","computed":"asLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-block"},"padding-block-end":{"syntax":"<\'padding-left\'>","media":"visual","inherited":false,"animationType":"length","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElements","computed":"asLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-block-end"},"padding-block-start":{"syntax":"<\'padding-left\'>","media":"visual","inherited":false,"animationType":"length","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElements","computed":"asLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-block-start"},"padding-bottom":{"syntax":"<length> | <percentage>","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"0","appliesto":"allElementsExceptInternalTableDisplayTypes","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-bottom"},"padding-inline":{"syntax":"<\'padding-left\'>{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElements","computed":"asLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-inline"},"padding-inline-end":{"syntax":"<\'padding-left\'>","media":"visual","inherited":false,"animationType":"length","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElements","computed":"asLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-inline-end"},"padding-inline-start":{"syntax":"<\'padding-left\'>","media":"visual","inherited":false,"animationType":"length","percentages":"logicalWidthOfContainingBlock","groups":["CSS Logical Properties"],"initial":"0","appliesto":"allElements","computed":"asLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-inline-start"},"padding-left":{"syntax":"<length> | <percentage>","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"0","appliesto":"allElementsExceptInternalTableDisplayTypes","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-left"},"padding-right":{"syntax":"<length> | <percentage>","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"0","appliesto":"allElementsExceptInternalTableDisplayTypes","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-right"},"padding-top":{"syntax":"<length> | <percentage>","media":"visual","inherited":false,"animationType":"length","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"0","appliesto":"allElementsExceptInternalTableDisplayTypes","computed":"percentageAsSpecifiedOrAbsoluteLength","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/padding-top"},"page-break-after":{"syntax":"auto | always | avoid | left | right | recto | verso","media":["visual","paged"],"inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Pages"],"initial":"auto","appliesto":"blockElementsInNormalFlow","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/page-break-after"},"page-break-before":{"syntax":"auto | always | avoid | left | right | recto | verso","media":["visual","paged"],"inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Pages"],"initial":"auto","appliesto":"blockElementsInNormalFlow","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/page-break-before"},"page-break-inside":{"syntax":"auto | avoid","media":["visual","paged"],"inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Pages"],"initial":"auto","appliesto":"blockElementsInNormalFlow","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/page-break-inside"},"paint-order":{"syntax":"normal | [ fill || stroke || markers ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"normal","appliesto":"textElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/paint-order"},"perspective":{"syntax":"none | <length>","media":"visual","inherited":false,"animationType":"length","percentages":"no","groups":["CSS Transforms"],"initial":"none","appliesto":"transformableElements","computed":"absoluteLengthOrNone","order":"uniqueOrder","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/perspective"},"perspective-origin":{"syntax":"<position>","media":"visual","inherited":false,"animationType":"simpleListOfLpc","percentages":"referToSizeOfBoundingBox","groups":["CSS Transforms"],"initial":"50% 50%","appliesto":"transformableElements","computed":"forLengthAbsoluteValueOtherwisePercentage","order":"oneOrTwoValuesLengthAbsoluteKeywordsPercentages","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/perspective-origin"},"place-content":{"syntax":"<\'align-content\'> <\'justify-content\'>?","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Alignment"],"initial":"normal","appliesto":"multilineFlexContainers","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/place-content"},"place-items":{"syntax":"<\'align-items\'> <\'justify-items\'>?","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Alignment"],"initial":["align-items","justify-items"],"appliesto":"allElements","computed":["align-items","justify-items"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/place-items"},"place-self":{"syntax":"<\'align-self\'> <\'justify-self\'>?","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Box Alignment"],"initial":["align-self","justify-self"],"appliesto":"blockLevelBoxesAndAbsolutelyPositionedBoxesAndGridItems","computed":["align-self","justify-self"],"order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/place-self"},"pointer-events":{"syntax":"auto | none | visiblePainted | visibleFill | visibleStroke | visible | painted | fill | stroke | all | inherit","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["Pointer Events"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/pointer-events"},"position":{"syntax":"static | relative | absolute | sticky | fixed","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Positioning"],"initial":"static","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/position"},"quotes":{"syntax":"none | auto | [ <string> <string> ]+","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Generated Content"],"initial":"dependsOnUserAgent","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/quotes"},"resize":{"syntax":"none | both | horizontal | vertical | block | inline","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Basic User Interface"],"initial":"none","appliesto":"elementsWithOverflowNotVisibleAndReplacedElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/resize"},"right":{"syntax":"<length> | <percentage> | auto","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToWidthOfContainingBlock","groups":["CSS Positioning"],"initial":"auto","appliesto":"positionedElements","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/right"},"rotate":{"syntax":"none | <angle> | [ x | y | z | <number>{3} ] && <angle>","media":"visual","inherited":false,"animationType":"transform","percentages":"no","groups":["CSS Transforms"],"initial":"none","appliesto":"transformableElements","computed":"asSpecified","order":"perGrammar","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/rotate"},"row-gap":{"syntax":"normal | <length-percentage>","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToDimensionOfContentArea","groups":["CSS Box Alignment"],"initial":"normal","appliesto":"multiColumnElementsFlexContainersGridContainers","computed":"asSpecifiedWithLengthsAbsoluteAndNormalComputingToZeroExceptMultiColumn","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/row-gap"},"ruby-align":{"syntax":"start | center | space-between | space-around","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Ruby"],"initial":"space-around","appliesto":"rubyBasesAnnotationsBaseAnnotationContainers","computed":"asSpecified","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/ruby-align"},"ruby-merge":{"syntax":"separate | collapse | auto","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Ruby"],"initial":"separate","appliesto":"rubyAnnotationsContainers","computed":"asSpecified","order":"uniqueOrder","status":"experimental"},"ruby-position":{"syntax":"over | under | inter-character","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Ruby"],"initial":"over","appliesto":"rubyAnnotationsContainers","computed":"asSpecified","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/ruby-position"},"scale":{"syntax":"none | <number>{1,3}","media":"visual","inherited":false,"animationType":"transform","percentages":"no","groups":["CSS Transforms"],"initial":"none","appliesto":"transformableElements","computed":"asSpecified","order":"perGrammar","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scale"},"scrollbar-color":{"syntax":"auto | dark | light | <color>{2}","media":"visual","inherited":true,"animationType":"color","percentages":"no","groups":["CSS Scrollbars"],"initial":"auto","appliesto":"scrollingBoxes","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scrollbar-color"},"scrollbar-gutter":{"syntax":"auto | [ stable | always ] && both? && force?","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Overflow"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scrollbar-gutter"},"scrollbar-width":{"syntax":"auto | thin | none","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Scrollbars"],"initial":"auto","appliesto":"scrollingBoxes","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scrollbar-width"},"scroll-behavior":{"syntax":"auto | smooth","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSSOM View"],"initial":"auto","appliesto":"scrollingBoxes","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-behavior"},"scroll-margin":{"syntax":"<length>{1,4}","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin"},"scroll-margin-block":{"syntax":"<length>{1,2}","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-block"},"scroll-margin-block-start":{"syntax":"<length>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-block-start"},"scroll-margin-block-end":{"syntax":"<length>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-block-end"},"scroll-margin-bottom":{"syntax":"<length>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-bottom"},"scroll-margin-inline":{"syntax":"<length>{1,2}","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-inline"},"scroll-margin-inline-start":{"syntax":"<length>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-inline-start"},"scroll-margin-inline-end":{"syntax":"<length>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-inline-end"},"scroll-margin-left":{"syntax":"<length>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-left"},"scroll-margin-right":{"syntax":"<length>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-right"},"scroll-margin-top":{"syntax":"<length>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"no","groups":["CSS Scroll Snap"],"initial":"0","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-margin-top"},"scroll-padding":{"syntax":"[ auto | <length-percentage> ]{1,4}","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding"},"scroll-padding-block":{"syntax":"[ auto | <length-percentage> ]{1,2}","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-block"},"scroll-padding-block-start":{"syntax":"auto | <length-percentage>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-block-start"},"scroll-padding-block-end":{"syntax":"auto | <length-percentage>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-block-end"},"scroll-padding-bottom":{"syntax":"auto | <length-percentage>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-bottom"},"scroll-padding-inline":{"syntax":"[ auto | <length-percentage> ]{1,2}","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-inline"},"scroll-padding-inline-start":{"syntax":"auto | <length-percentage>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-inline-start"},"scroll-padding-inline-end":{"syntax":"auto | <length-percentage>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-inline-end"},"scroll-padding-left":{"syntax":"auto | <length-percentage>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-left"},"scroll-padding-right":{"syntax":"auto | <length-percentage>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-right"},"scroll-padding-top":{"syntax":"auto | <length-percentage>","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"relativeToTheScrollContainersScrollport","groups":["CSS Scroll Snap"],"initial":"auto","appliesto":"scrollContainers","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-padding-top"},"scroll-snap-align":{"syntax":"[ none | start | end | center ]{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Scroll Snap"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-snap-align"},"scroll-snap-coordinate":{"syntax":"none | <position>#","media":"interactive","inherited":false,"animationType":"position","percentages":"referToBorderBox","groups":["CSS Scroll Snap"],"initial":"none","appliesto":"allElements","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-snap-coordinate"},"scroll-snap-destination":{"syntax":"<position>","media":"interactive","inherited":false,"animationType":"position","percentages":"relativeToScrollContainerPaddingBoxAxis","groups":["CSS Scroll Snap"],"initial":"0px 0px","appliesto":"scrollContainers","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-snap-destination"},"scroll-snap-points-x":{"syntax":"none | repeat( <length-percentage> )","media":"interactive","inherited":false,"animationType":"discrete","percentages":"relativeToScrollContainerPaddingBoxAxis","groups":["CSS Scroll Snap"],"initial":"none","appliesto":"scrollContainers","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-snap-points-x"},"scroll-snap-points-y":{"syntax":"none | repeat( <length-percentage> )","media":"interactive","inherited":false,"animationType":"discrete","percentages":"relativeToScrollContainerPaddingBoxAxis","groups":["CSS Scroll Snap"],"initial":"none","appliesto":"scrollContainers","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-snap-points-y"},"scroll-snap-stop":{"syntax":"normal | always","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Scroll Snap"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-snap-stop"},"scroll-snap-type":{"syntax":"none | [ x | y | block | inline | both ] [ mandatory | proximity ]?","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Scroll Snap"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-snap-type"},"scroll-snap-type-x":{"syntax":"none | mandatory | proximity","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Scroll Snap"],"initial":"none","appliesto":"scrollContainers","computed":"asSpecified","order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-snap-type-x"},"scroll-snap-type-y":{"syntax":"none | mandatory | proximity","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Scroll Snap"],"initial":"none","appliesto":"scrollContainers","computed":"asSpecified","order":"uniqueOrder","status":"obsolete","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/scroll-snap-type-y"},"shape-image-threshold":{"syntax":"<alpha-value>","media":"visual","inherited":false,"animationType":"number","percentages":"no","groups":["CSS Shapes"],"initial":"0.0","appliesto":"floats","computed":"specifiedValueNumberClipped0To1","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/shape-image-threshold"},"shape-margin":{"syntax":"<length-percentage>","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToWidthOfContainingBlock","groups":["CSS Shapes"],"initial":"0","appliesto":"floats","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/shape-margin"},"shape-outside":{"syntax":"none | <shape-box> || <basic-shape> | <image>","media":"visual","inherited":false,"animationType":"basicShapeOtherwiseNo","percentages":"no","groups":["CSS Shapes"],"initial":"none","appliesto":"floats","computed":"asDefinedForBasicShapeWithAbsoluteURIOtherwiseAsSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/shape-outside"},"tab-size":{"syntax":"<integer> | <length>","media":"visual","inherited":true,"animationType":"length","percentages":"no","groups":["CSS Text"],"initial":"8","appliesto":"blockContainers","computed":"specifiedIntegerOrAbsoluteLength","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/tab-size"},"table-layout":{"syntax":"auto | fixed","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Table"],"initial":"auto","appliesto":"tableElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/table-layout"},"text-align":{"syntax":"start | end | left | right | center | justify | match-parent","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"startOrNamelessValueIfLTRRightIfRTL","appliesto":"blockContainers","computed":"asSpecifiedExceptMatchParent","order":"orderOfAppearance","alsoAppliesTo":["::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-align"},"text-align-last":{"syntax":"auto | start | end | left | right | center | justify","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"auto","appliesto":"blockContainers","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-align-last"},"text-combine-upright":{"syntax":"none | all | [ digits <integer>? ]","media":"visual","inherited":true,"animationType":"notAnimatable","percentages":"no","groups":["CSS Writing Modes"],"initial":"none","appliesto":"nonReplacedInlineElements","computed":"keywordPlusIntegerIfDigits","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-combine-upright"},"text-decoration":{"syntax":"<\'text-decoration-line\'> || <\'text-decoration-style\'> || <\'text-decoration-color\'> || <\'text-decoration-thickness\'>","media":"visual","inherited":false,"animationType":["text-decoration-color","text-decoration-style","text-decoration-line","text-decoration-thickness"],"percentages":"no","groups":["CSS Text Decoration"],"initial":["text-decoration-color","text-decoration-style","text-decoration-line"],"appliesto":"allElements","computed":["text-decoration-line","text-decoration-style","text-decoration-color","text-decoration-thickness"],"order":"orderOfAppearance","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-decoration"},"text-decoration-color":{"syntax":"<color>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Text Decoration"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-decoration-color"},"text-decoration-line":{"syntax":"none | [ underline || overline || line-through || blink ] | spelling-error | grammar-error","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Text Decoration"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-decoration-line"},"text-decoration-skip":{"syntax":"none | [ objects || [ spaces | [ leading-spaces || trailing-spaces ] ] || edges || box-decoration ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text Decoration"],"initial":"objects","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-decoration-skip"},"text-decoration-skip-ink":{"syntax":"auto | all | none","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text Decoration"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-decoration-skip-ink"},"text-decoration-style":{"syntax":"solid | double | dotted | dashed | wavy","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Text Decoration"],"initial":"solid","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-decoration-style"},"text-decoration-thickness":{"syntax":"auto | from-font | <length> | <percentage> ","media":"visual","inherited":false,"animationType":"byComputedValueType","percentages":"referToElementFontSize","groups":["CSS Text Decoration"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-decoration-thickness"},"text-emphasis":{"syntax":"<\'text-emphasis-style\'> || <\'text-emphasis-color\'>","media":"visual","inherited":false,"animationType":["text-emphasis-color","text-emphasis-style"],"percentages":"no","groups":["CSS Text Decoration"],"initial":["text-emphasis-style","text-emphasis-color"],"appliesto":"allElements","computed":["text-emphasis-style","text-emphasis-color"],"order":"orderOfAppearance","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-emphasis"},"text-emphasis-color":{"syntax":"<color>","media":"visual","inherited":false,"animationType":"color","percentages":"no","groups":["CSS Text Decoration"],"initial":"currentcolor","appliesto":"allElements","computed":"computedColor","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-emphasis-color"},"text-emphasis-position":{"syntax":"[ over | under ] && [ right | left ]","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Text Decoration"],"initial":"over right","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-emphasis-position"},"text-emphasis-style":{"syntax":"none | [ [ filled | open ] || [ dot | circle | double-circle | triangle | sesame ] ] | <string>","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Text Decoration"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-emphasis-style"},"text-indent":{"syntax":"<length-percentage> && hanging? && each-line?","media":"visual","inherited":true,"animationType":"lpc","percentages":"referToWidthOfContainingBlock","groups":["CSS Text"],"initial":"0","appliesto":"blockContainers","computed":"percentageOrAbsoluteLengthPlusKeywords","order":"lengthOrPercentageBeforeKeywords","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-indent"},"text-justify":{"syntax":"auto | inter-character | inter-word | none","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"auto","appliesto":"inlineLevelAndTableCellElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-justify"},"text-orientation":{"syntax":"mixed | upright | sideways","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Writing Modes"],"initial":"mixed","appliesto":"allElementsExceptTableRowGroupsRowsColumnGroupsAndColumns","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-orientation"},"text-overflow":{"syntax":"[ clip | ellipsis | <string> ]{1,2}","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Basic User Interface"],"initial":"clip","appliesto":"blockContainerElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-overflow"},"text-rendering":{"syntax":"auto | optimizeSpeed | optimizeLegibility | geometricPrecision","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Miscellaneous"],"initial":"auto","appliesto":"textElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-rendering"},"text-shadow":{"syntax":"none | <shadow-t>#","media":"visual","inherited":true,"animationType":"shadowList","percentages":"no","groups":["CSS Text Decoration"],"initial":"none","appliesto":"allElements","computed":"colorPlusThreeAbsoluteLengths","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-shadow"},"text-size-adjust":{"syntax":"none | auto | <percentage>","media":"visual","inherited":true,"animationType":"discrete","percentages":"referToSizeOfFont","groups":["CSS Text"],"initial":"autoForSmartphoneBrowsersSupportingInflation","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"experimental","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-size-adjust"},"text-transform":{"syntax":"none | capitalize | uppercase | lowercase | full-width | full-size-kana","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"none","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-transform"},"text-underline-offset":{"syntax":"auto | <length> | <percentage> ","media":"visual","inherited":true,"animationType":"byComputedValueType","percentages":"referToElementFontSize","groups":["CSS Text Decoration"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-underline-offset"},"text-underline-position":{"syntax":"auto | from-font | [ under || [ left | right ] ]","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text Decoration"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"orderOfAppearance","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/text-underline-position"},"top":{"syntax":"<length> | <percentage> | auto","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToContainingBlockHeight","groups":["CSS Positioning"],"initial":"auto","appliesto":"positionedElements","computed":"lengthAbsolutePercentageAsSpecifiedOtherwiseAuto","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/top"},"touch-action":{"syntax":"auto | none | [ [ pan-x | pan-left | pan-right ] || [ pan-y | pan-up | pan-down ] || pinch-zoom ] | manipulation","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["Pointer Events"],"initial":"auto","appliesto":"allElementsExceptNonReplacedInlineElementsTableRowsColumnsRowColumnGroups","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/touch-action"},"transform":{"syntax":"none | <transform-list>","media":"visual","inherited":false,"animationType":"transform","percentages":"referToSizeOfBoundingBox","groups":["CSS Transforms"],"initial":"none","appliesto":"transformableElements","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"uniqueOrder","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/transform"},"transform-box":{"syntax":"content-box | border-box | fill-box | stroke-box | view-box","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Transforms"],"initial":"view-box","appliesto":"transformableElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/transform-box"},"transform-origin":{"syntax":"[ <length-percentage> | left | center | right | top | bottom ] | [ [ <length-percentage> | left | center | right ] && [ <length-percentage> | top | center | bottom ] ] <length>?","media":"visual","inherited":false,"animationType":"simpleListOfLpc","percentages":"referToSizeOfBoundingBox","groups":["CSS Transforms"],"initial":"50% 50% 0","appliesto":"transformableElements","computed":"forLengthAbsoluteValueOtherwisePercentage","order":"oneOrTwoValuesLengthAbsoluteKeywordsPercentages","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/transform-origin"},"transform-style":{"syntax":"flat | preserve-3d","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Transforms"],"initial":"flat","appliesto":"transformableElements","computed":"asSpecified","order":"uniqueOrder","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/transform-style"},"transition":{"syntax":"<single-transition>#","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Transitions"],"initial":["transition-delay","transition-duration","transition-property","transition-timing-function"],"appliesto":"allElementsAndPseudos","computed":["transition-delay","transition-duration","transition-property","transition-timing-function"],"order":"orderOfAppearance","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/transition"},"transition-delay":{"syntax":"<time>#","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Transitions"],"initial":"0s","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/transition-delay"},"transition-duration":{"syntax":"<time>#","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Transitions"],"initial":"0s","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/transition-duration"},"transition-property":{"syntax":"none | <single-transition-property>#","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Transitions"],"initial":"all","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/transition-property"},"transition-timing-function":{"syntax":"<timing-function>#","media":"interactive","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Transitions"],"initial":"ease","appliesto":"allElementsAndPseudos","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/transition-timing-function"},"translate":{"syntax":"none | <length-percentage> [ <length-percentage> <length>? ]?","media":"visual","inherited":false,"animationType":"transform","percentages":"referToSizeOfBoundingBox","groups":["CSS Transforms"],"initial":"none","appliesto":"transformableElements","computed":"asSpecifiedRelativeToAbsoluteLengths","order":"perGrammar","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/translate"},"unicode-bidi":{"syntax":"normal | embed | isolate | bidi-override | isolate-override | plaintext","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Writing Modes"],"initial":"normal","appliesto":"allElementsSomeValuesNoEffectOnNonInlineElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/unicode-bidi"},"user-select":{"syntax":"auto | text | none | contain | all","media":"visual","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Basic User Interface"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/user-select"},"vertical-align":{"syntax":"baseline | sub | super | text-top | text-bottom | middle | top | bottom | <percentage> | <length>","media":"visual","inherited":false,"animationType":"length","percentages":"referToLineHeight","groups":["CSS Table"],"initial":"baseline","appliesto":"inlineLevelAndTableCellElements","computed":"absoluteLengthOrKeyword","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/vertical-align"},"visibility":{"syntax":"visible | hidden | collapse","media":"visual","inherited":true,"animationType":"visibility","percentages":"no","groups":["CSS Box Model"],"initial":"visible","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/visibility"},"white-space":{"syntax":"normal | pre | nowrap | pre-wrap | pre-line | break-spaces","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/white-space"},"widows":{"syntax":"<integer>","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Fragmentation"],"initial":"2","appliesto":"blockContainerElements","computed":"asSpecified","order":"perGrammar","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/widows"},"width":{"syntax":"auto | <length> | <percentage> | min-content | max-content | fit-content(<length-percentage>)","media":"visual","inherited":false,"animationType":"lpc","percentages":"referToWidthOfContainingBlock","groups":["CSS Box Model"],"initial":"auto","appliesto":"allElementsButNonReplacedAndTableRows","computed":"percentageAutoOrAbsoluteLength","order":"lengthOrPercentageBeforeKeywordIfBothPresent","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/width"},"will-change":{"syntax":"auto | <animateable-feature>#","media":"all","inherited":false,"animationType":"discrete","percentages":"no","groups":["CSS Will Change"],"initial":"auto","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/will-change"},"word-break":{"syntax":"normal | break-all | keep-all | break-word","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/word-break"},"word-spacing":{"syntax":"normal | <length-percentage>","media":"visual","inherited":true,"animationType":"length","percentages":"referToWidthOfAffectedGlyph","groups":["CSS Text"],"initial":"normal","appliesto":"allElements","computed":"optimumMinAndMaxValueOfAbsoluteLengthPercentageOrNormal","order":"uniqueOrder","alsoAppliesTo":["::first-letter","::first-line","::placeholder"],"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/word-spacing"},"word-wrap":{"syntax":"normal | break-word","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Text"],"initial":"normal","appliesto":"nonReplacedInlineElements","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/overflow-wrap"},"writing-mode":{"syntax":"horizontal-tb | vertical-rl | vertical-lr | sideways-rl | sideways-lr","media":"visual","inherited":true,"animationType":"discrete","percentages":"no","groups":["CSS Writing Modes"],"initial":"horizontal-tb","appliesto":"allElementsExceptTableRowColumnGroupsTableRowsColumns","computed":"asSpecified","order":"uniqueOrder","status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/writing-mode"},"z-index":{"syntax":"auto | <integer>","media":"visual","inherited":false,"animationType":"integer","percentages":"no","groups":["CSS Positioning"],"initial":"auto","appliesto":"positionedElements","computed":"asSpecified","order":"uniqueOrder","stacking":true,"status":"standard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/z-index"},"zoom":{"syntax":"normal | reset | <number> | <percentage>","media":"visual","inherited":false,"animationType":"integer","percentages":"no","groups":["Microsoft Extensions"],"initial":"normal","appliesto":"allElements","computed":"asSpecified","order":"uniqueOrder","status":"nonstandard","mdn_url":"https://developer.mozilla.org/docs/Web/CSS/zoom"}}')},9023:e=>{"use strict"
e.exports=JSON.parse('{"absolute-size":{"syntax":"xx-small | x-small | small | medium | large | x-large | xx-large | xxx-large"},"alpha-value":{"syntax":"<number> | <percentage>"},"angle-percentage":{"syntax":"<angle> | <percentage>"},"angular-color-hint":{"syntax":"<angle-percentage>"},"angular-color-stop":{"syntax":"<color> && <color-stop-angle>?"},"angular-color-stop-list":{"syntax":"[ <angular-color-stop> [, <angular-color-hint>]? ]# , <angular-color-stop>"},"animateable-feature":{"syntax":"scroll-position | contents | <custom-ident>"},"attachment":{"syntax":"scroll | fixed | local"},"attr()":{"syntax":"attr( <attr-name> <type-or-unit>? [, <attr-fallback> ]? )"},"attr-matcher":{"syntax":"[ \'~\' | \'|\' | \'^\' | \'$\' | \'*\' ]? \'=\'"},"attr-modifier":{"syntax":"i | s"},"attribute-selector":{"syntax":"\'[\' <wq-name> \']\' | \'[\' <wq-name> <attr-matcher> [ <string-token> | <ident-token> ] <attr-modifier>? \']\'"},"auto-repeat":{"syntax":"repeat( [ auto-fill | auto-fit ] , [ <line-names>? <fixed-size> ]+ <line-names>? )"},"auto-track-list":{"syntax":"[ <line-names>? [ <fixed-size> | <fixed-repeat> ] ]* <line-names>? <auto-repeat>\\n[ <line-names>? [ <fixed-size> | <fixed-repeat> ] ]* <line-names>?"},"baseline-position":{"syntax":"[ first | last ]? baseline"},"basic-shape":{"syntax":"<inset()> | <circle()> | <ellipse()> | <polygon()> | <path()>"},"bg-image":{"syntax":"none | <image>"},"bg-layer":{"syntax":"<bg-image> || <bg-position> [ / <bg-size> ]? || <repeat-style> || <attachment> || <box> || <box>"},"bg-position":{"syntax":"[ [ left | center | right | top | bottom | <length-percentage> ] | [ left | center | right | <length-percentage> ] [ top | center | bottom | <length-percentage> ] | [ center | [ left | right ] <length-percentage>? ] && [ center | [ top | bottom ] <length-percentage>? ] ]"},"bg-size":{"syntax":"[ <length-percentage> | auto ]{1,2} | cover | contain"},"blur()":{"syntax":"blur( <length> )"},"blend-mode":{"syntax":"normal | multiply | screen | overlay | darken | lighten | color-dodge | color-burn | hard-light | soft-light | difference | exclusion | hue | saturation | color | luminosity"},"box":{"syntax":"border-box | padding-box | content-box"},"brightness()":{"syntax":"brightness( <number-percentage> )"},"calc()":{"syntax":"calc( <calc-sum> )"},"calc-sum":{"syntax":"<calc-product> [ [ \'+\' | \'-\' ] <calc-product> ]*"},"calc-product":{"syntax":"<calc-value> [ \'*\' <calc-value> | \'/\' <number> ]*"},"calc-value":{"syntax":"<number> | <dimension> | <percentage> | ( <calc-sum> )"},"cf-final-image":{"syntax":"<image> | <color>"},"cf-mixing-image":{"syntax":"<percentage>? && <image>"},"circle()":{"syntax":"circle( [ <shape-radius> ]? [ at <position> ]? )"},"clamp()":{"syntax":"clamp( <calc-sum>#{3} )"},"class-selector":{"syntax":"\'.\' <ident-token>"},"clip-source":{"syntax":"<url>"},"color":{"syntax":"<rgb()> | <rgba()> | <hsl()> | <hsla()> | <hex-color> | <named-color> | currentcolor | <deprecated-system-color>"},"color-stop":{"syntax":"<color-stop-length> | <color-stop-angle>"},"color-stop-angle":{"syntax":"<angle-percentage>{1,2}"},"color-stop-length":{"syntax":"<length-percentage>{1,2}"},"color-stop-list":{"syntax":"[ <linear-color-stop> [, <linear-color-hint>]? ]# , <linear-color-stop>"},"combinator":{"syntax":"\'>\' | \'+\' | \'~\' | [ \'||\' ]"},"common-lig-values":{"syntax":"[ common-ligatures | no-common-ligatures ]"},"compat-auto":{"syntax":"searchfield | textarea | push-button | slider-horizontal | checkbox | radio | square-button | menulist | listbox | meter | progress-bar | button"},"composite-style":{"syntax":"clear | copy | source-over | source-in | source-out | source-atop | destination-over | destination-in | destination-out | destination-atop | xor"},"compositing-operator":{"syntax":"add | subtract | intersect | exclude"},"compound-selector":{"syntax":"[ <type-selector>? <subclass-selector>* [ <pseudo-element-selector> <pseudo-class-selector>* ]* ]!"},"compound-selector-list":{"syntax":"<compound-selector>#"},"complex-selector":{"syntax":"<compound-selector> [ <combinator>? <compound-selector> ]*"},"complex-selector-list":{"syntax":"<complex-selector>#"},"conic-gradient()":{"syntax":"conic-gradient( [ from <angle> ]? [ at <position> ]?, <angular-color-stop-list> )"},"contextual-alt-values":{"syntax":"[ contextual | no-contextual ]"},"content-distribution":{"syntax":"space-between | space-around | space-evenly | stretch"},"content-list":{"syntax":"[ <string> | contents | <image> | <quote> | <target> | <leader()> ]+"},"content-position":{"syntax":"center | start | end | flex-start | flex-end"},"content-replacement":{"syntax":"<image>"},"contrast()":{"syntax":"contrast( [ <number-percentage> ] )"},"counter()":{"syntax":"counter( <custom-ident>, <counter-style>? )"},"counter-style":{"syntax":"<counter-style-name> | symbols()"},"counter-style-name":{"syntax":"<custom-ident>"},"counters()":{"syntax":"counters( <custom-ident>, <string>, <counter-style>? )"},"cross-fade()":{"syntax":"cross-fade( <cf-mixing-image> , <cf-final-image>? )"},"cubic-bezier-timing-function":{"syntax":"ease | ease-in | ease-out | ease-in-out | cubic-bezier(<number [0,1]>, <number>, <number [0,1]>, <number>)"},"deprecated-system-color":{"syntax":"ActiveBorder | ActiveCaption | AppWorkspace | Background | ButtonFace | ButtonHighlight | ButtonShadow | ButtonText | CaptionText | GrayText | Highlight | HighlightText | InactiveBorder | InactiveCaption | InactiveCaptionText | InfoBackground | InfoText | Menu | MenuText | Scrollbar | ThreeDDarkShadow | ThreeDFace | ThreeDHighlight | ThreeDLightShadow | ThreeDShadow | Window | WindowFrame | WindowText"},"discretionary-lig-values":{"syntax":"[ discretionary-ligatures | no-discretionary-ligatures ]"},"display-box":{"syntax":"contents | none"},"display-inside":{"syntax":"flow | flow-root | table | flex | grid | ruby"},"display-internal":{"syntax":"table-row-group | table-header-group | table-footer-group | table-row | table-cell | table-column-group | table-column | table-caption | ruby-base | ruby-text | ruby-base-container | ruby-text-container"},"display-legacy":{"syntax":"inline-block | inline-list-item | inline-table | inline-flex | inline-grid"},"display-listitem":{"syntax":"<display-outside>? && [ flow | flow-root ]? && list-item"},"display-outside":{"syntax":"block | inline | run-in"},"drop-shadow()":{"syntax":"drop-shadow( <length>{2,3} <color>? )"},"east-asian-variant-values":{"syntax":"[ jis78 | jis83 | jis90 | jis04 | simplified | traditional ]"},"east-asian-width-values":{"syntax":"[ full-width | proportional-width ]"},"element()":{"syntax":"element( <id-selector> )"},"ellipse()":{"syntax":"ellipse( [ <shape-radius>{2} ]? [ at <position> ]? )"},"ending-shape":{"syntax":"circle | ellipse"},"env()":{"syntax":"env( <custom-ident> , <declaration-value>? )"},"explicit-track-list":{"syntax":"[ <line-names>? <track-size> ]+ <line-names>?"},"family-name":{"syntax":"<string> | <custom-ident>+"},"feature-tag-value":{"syntax":"<string> [ <integer> | on | off ]?"},"feature-type":{"syntax":"@stylistic | @historical-forms | @styleset | @character-variant | @swash | @ornaments | @annotation"},"feature-value-block":{"syntax":"<feature-type> \'{\' <feature-value-declaration-list> \'}\'"},"feature-value-block-list":{"syntax":"<feature-value-block>+"},"feature-value-declaration":{"syntax":"<custom-ident>: <integer>+;"},"feature-value-declaration-list":{"syntax":"<feature-value-declaration>"},"feature-value-name":{"syntax":"<custom-ident>"},"fill-rule":{"syntax":"nonzero | evenodd"},"filter-function":{"syntax":"<blur()> | <brightness()> | <contrast()> | <drop-shadow()> | <grayscale()> | <hue-rotate()> | <invert()> | <opacity()> | <saturate()> | <sepia()>"},"filter-function-list":{"syntax":"[ <filter-function> | <url> ]+"},"final-bg-layer":{"syntax":"<\'background-color\'> || <bg-image> || <bg-position> [ / <bg-size> ]? || <repeat-style> || <attachment> || <box> || <box>"},"fit-content()":{"syntax":"fit-content( [ <length> | <percentage> ] )"},"fixed-breadth":{"syntax":"<length-percentage>"},"fixed-repeat":{"syntax":"repeat( [ <positive-integer> ] , [ <line-names>? <fixed-size> ]+ <line-names>? )"},"fixed-size":{"syntax":"<fixed-breadth> | minmax( <fixed-breadth> , <track-breadth> ) | minmax( <inflexible-breadth> , <fixed-breadth> )"},"font-stretch-absolute":{"syntax":"normal | ultra-condensed | extra-condensed | condensed | semi-condensed | semi-expanded | expanded | extra-expanded | ultra-expanded | <percentage>"},"font-variant-css21":{"syntax":"[ normal | small-caps ]"},"font-weight-absolute":{"syntax":"normal | bold | <number [1,1000]>"},"frequency-percentage":{"syntax":"<frequency> | <percentage>"},"general-enclosed":{"syntax":"[ <function-token> <any-value> ) ] | ( <ident> <any-value> )"},"generic-family":{"syntax":"serif | sans-serif | cursive | fantasy | monospace"},"generic-name":{"syntax":"serif | sans-serif | cursive | fantasy | monospace"},"geometry-box":{"syntax":"<shape-box> | fill-box | stroke-box | view-box"},"gradient":{"syntax":"<linear-gradient()> | <repeating-linear-gradient()> | <radial-gradient()> | <repeating-radial-gradient()> | <conic-gradient()>"},"grayscale()":{"syntax":"grayscale( <number-percentage> )"},"grid-line":{"syntax":"auto | <custom-ident> | [ <integer> && <custom-ident>? ] | [ span && [ <integer> || <custom-ident> ] ]"},"historical-lig-values":{"syntax":"[ historical-ligatures | no-historical-ligatures ]"},"hsl()":{"syntax":"hsl( <hue> <percentage> <percentage> [ / <alpha-value> ]? ) | hsl( <hue>, <percentage>, <percentage>, <alpha-value>? )"},"hsla()":{"syntax":"hsla( <hue> <percentage> <percentage> [ / <alpha-value> ]? ) | hsla( <hue>, <percentage>, <percentage>, <alpha-value>? )"},"hue":{"syntax":"<number> | <angle>"},"hue-rotate()":{"syntax":"hue-rotate( <angle> )"},"id-selector":{"syntax":"<hash-token>"},"image":{"syntax":"<url> | <image()> | <image-set()> | <element()> | <paint()> | <cross-fade()> | <gradient>"},"image()":{"syntax":"image( <image-tags>? [ <image-src>? , <color>? ]! )"},"image-set()":{"syntax":"image-set( <image-set-option># )"},"image-set-option":{"syntax":"[ <image> | <string> ] <resolution>"},"image-src":{"syntax":"<url> | <string>"},"image-tags":{"syntax":"ltr | rtl"},"inflexible-breadth":{"syntax":"<length> | <percentage> | min-content | max-content | auto"},"inset()":{"syntax":"inset( <length-percentage>{1,4} [ round <\'border-radius\'> ]? )"},"invert()":{"syntax":"invert( <number-percentage> )"},"keyframes-name":{"syntax":"<custom-ident> | <string>"},"keyframe-block":{"syntax":"<keyframe-selector># {\\n  <declaration-list>\\n}"},"keyframe-block-list":{"syntax":"<keyframe-block>+"},"keyframe-selector":{"syntax":"from | to | <percentage>"},"leader()":{"syntax":"leader( <leader-type> )"},"leader-type":{"syntax":"dotted | solid | space | <string>"},"length-percentage":{"syntax":"<length> | <percentage>"},"line-names":{"syntax":"\'[\' <custom-ident>* \']\'"},"line-name-list":{"syntax":"[ <line-names> | <name-repeat> ]+"},"line-style":{"syntax":"none | hidden | dotted | dashed | solid | double | groove | ridge | inset | outset"},"line-width":{"syntax":"<length> | thin | medium | thick"},"linear-color-hint":{"syntax":"<length-percentage>"},"linear-color-stop":{"syntax":"<color> <color-stop-length>?"},"linear-gradient()":{"syntax":"linear-gradient( [ <angle> | to <side-or-corner> ]? , <color-stop-list> )"},"mask-layer":{"syntax":"<mask-reference> || <position> [ / <bg-size> ]? || <repeat-style> || <geometry-box> || [ <geometry-box> | no-clip ] || <compositing-operator> || <masking-mode>"},"mask-position":{"syntax":"[ <length-percentage> | left | center | right ] [ <length-percentage> | top | center | bottom ]?"},"mask-reference":{"syntax":"none | <image> | <mask-source>"},"mask-source":{"syntax":"<url>"},"masking-mode":{"syntax":"alpha | luminance | match-source"},"matrix()":{"syntax":"matrix( <number>#{6} )"},"matrix3d()":{"syntax":"matrix3d( <number>#{16} )"},"max()":{"syntax":"max( <calc-sum># )"},"media-and":{"syntax":"<media-in-parens> [ and <media-in-parens> ]+"},"media-condition":{"syntax":"<media-not> | <media-and> | <media-or> | <media-in-parens>"},"media-condition-without-or":{"syntax":"<media-not> | <media-and> | <media-in-parens>"},"media-feature":{"syntax":"( [ <mf-plain> | <mf-boolean> | <mf-range> ] )"},"media-in-parens":{"syntax":"( <media-condition> ) | <media-feature> | <general-enclosed>"},"media-not":{"syntax":"not <media-in-parens>"},"media-or":{"syntax":"<media-in-parens> [ or <media-in-parens> ]+"},"media-query":{"syntax":"<media-condition> | [ not | only ]? <media-type> [ and <media-condition-without-or> ]?"},"media-query-list":{"syntax":"<media-query>#"},"media-type":{"syntax":"<ident>"},"mf-boolean":{"syntax":"<mf-name>"},"mf-name":{"syntax":"<ident>"},"mf-plain":{"syntax":"<mf-name> : <mf-value>"},"mf-range":{"syntax":"<mf-name> [ \'<\' | \'>\' ]? \'=\'? <mf-value>\\n| <mf-value> [ \'<\' | \'>\' ]? \'=\'? <mf-name>\\n| <mf-value> \'<\' \'=\'? <mf-name> \'<\' \'=\'? <mf-value>\\n| <mf-value> \'>\' \'=\'? <mf-name> \'>\' \'=\'? <mf-value>"},"mf-value":{"syntax":"<number> | <dimension> | <ident> | <ratio>"},"min()":{"syntax":"min( <calc-sum># )"},"minmax()":{"syntax":"minmax( [ <length> | <percentage> | min-content | max-content | auto ] , [ <length> | <percentage> | <flex> | min-content | max-content | auto ] )"},"named-color":{"syntax":"transparent | aliceblue | antiquewhite | aqua | aquamarine | azure | beige | bisque | black | blanchedalmond | blue | blueviolet | brown | burlywood | cadetblue | chartreuse | chocolate | coral | cornflowerblue | cornsilk | crimson | cyan | darkblue | darkcyan | darkgoldenrod | darkgray | darkgreen | darkgrey | darkkhaki | darkmagenta | darkolivegreen | darkorange | darkorchid | darkred | darksalmon | darkseagreen | darkslateblue | darkslategray | darkslategrey | darkturquoise | darkviolet | deeppink | deepskyblue | dimgray | dimgrey | dodgerblue | firebrick | floralwhite | forestgreen | fuchsia | gainsboro | ghostwhite | gold | goldenrod | gray | green | greenyellow | grey | honeydew | hotpink | indianred | indigo | ivory | khaki | lavender | lavenderblush | lawngreen | lemonchiffon | lightblue | lightcoral | lightcyan | lightgoldenrodyellow | lightgray | lightgreen | lightgrey | lightpink | lightsalmon | lightseagreen | lightskyblue | lightslategray | lightslategrey | lightsteelblue | lightyellow | lime | limegreen | linen | magenta | maroon | mediumaquamarine | mediumblue | mediumorchid | mediumpurple | mediumseagreen | mediumslateblue | mediumspringgreen | mediumturquoise | mediumvioletred | midnightblue | mintcream | mistyrose | moccasin | navajowhite | navy | oldlace | olive | olivedrab | orange | orangered | orchid | palegoldenrod | palegreen | paleturquoise | palevioletred | papayawhip | peachpuff | peru | pink | plum | powderblue | purple | rebeccapurple | red | rosybrown | royalblue | saddlebrown | salmon | sandybrown | seagreen | seashell | sienna | silver | skyblue | slateblue | slategray | slategrey | snow | springgreen | steelblue | tan | teal | thistle | tomato | turquoise | violet | wheat | white | whitesmoke | yellow | yellowgreen"},"namespace-prefix":{"syntax":"<ident>"},"ns-prefix":{"syntax":"[ <ident-token> | \'*\' ]? \'|\'"},"number-percentage":{"syntax":"<number> | <percentage>"},"numeric-figure-values":{"syntax":"[ lining-nums | oldstyle-nums ]"},"numeric-fraction-values":{"syntax":"[ diagonal-fractions | stacked-fractions ]"},"numeric-spacing-values":{"syntax":"[ proportional-nums | tabular-nums ]"},"nth":{"syntax":"<an-plus-b> | even | odd"},"opacity()":{"syntax":"opacity( [ <number-percentage> ] )"},"overflow-position":{"syntax":"unsafe | safe"},"outline-radius":{"syntax":"<length> | <percentage>"},"page-body":{"syntax":"<declaration>? [ ; <page-body> ]? | <page-margin-box> <page-body>"},"page-margin-box":{"syntax":"<page-margin-box-type> \'{\' <declaration-list> \'}\'"},"page-margin-box-type":{"syntax":"@top-left-corner | @top-left | @top-center | @top-right | @top-right-corner | @bottom-left-corner | @bottom-left | @bottom-center | @bottom-right | @bottom-right-corner | @left-top | @left-middle | @left-bottom | @right-top | @right-middle | @right-bottom"},"page-selector-list":{"syntax":"[ <page-selector># ]?"},"page-selector":{"syntax":"<pseudo-page>+ | <ident> <pseudo-page>*"},"path()":{"syntax":"path( [ <fill-rule>, ]? <string> )"},"paint()":{"syntax":"paint( <ident>, <declaration-value>? )"},"perspective()":{"syntax":"perspective( <length> )"},"polygon()":{"syntax":"polygon( <fill-rule>? , [ <length-percentage> <length-percentage> ]# )"},"position":{"syntax":"[ [ left | center | right ] || [ top | center | bottom ] | [ left | center | right | <length-percentage> ] [ top | center | bottom | <length-percentage> ]? | [ [ left | right ] <length-percentage> ] && [ [ top | bottom ] <length-percentage> ] ]"},"pseudo-class-selector":{"syntax":"\':\' <ident-token> | \':\' <function-token> <any-value> \')\'"},"pseudo-element-selector":{"syntax":"\':\' <pseudo-class-selector>"},"pseudo-page":{"syntax":": [ left | right | first | blank ]"},"quote":{"syntax":"open-quote | close-quote | no-open-quote | no-close-quote"},"radial-gradient()":{"syntax":"radial-gradient( [ <ending-shape> || <size> ]? [ at <position> ]? , <color-stop-list> )"},"relative-selector":{"syntax":"<combinator>? <complex-selector>"},"relative-selector-list":{"syntax":"<relative-selector>#"},"relative-size":{"syntax":"larger | smaller"},"repeat-style":{"syntax":"repeat-x | repeat-y | [ repeat | space | round | no-repeat ]{1,2}"},"repeating-linear-gradient()":{"syntax":"repeating-linear-gradient( [ <angle> | to <side-or-corner> ]? , <color-stop-list> )"},"repeating-radial-gradient()":{"syntax":"repeating-radial-gradient( [ <ending-shape> || <size> ]? [ at <position> ]? , <color-stop-list> )"},"rgb()":{"syntax":"rgb( <percentage>{3} [ / <alpha-value> ]? ) | rgb( <number>{3} [ / <alpha-value> ]? ) | rgb( <percentage>#{3} , <alpha-value>? ) | rgb( <number>#{3} , <alpha-value>? )"},"rgba()":{"syntax":"rgba( <percentage>{3} [ / <alpha-value> ]? ) | rgba( <number>{3} [ / <alpha-value> ]? ) | rgba( <percentage>#{3} , <alpha-value>? ) | rgba( <number>#{3} , <alpha-value>? )"},"rotate()":{"syntax":"rotate( [ <angle> | <zero> ] )"},"rotate3d()":{"syntax":"rotate3d( <number> , <number> , <number> , [ <angle> | <zero> ] )"},"rotateX()":{"syntax":"rotateX( [ <angle> | <zero> ] )"},"rotateY()":{"syntax":"rotateY( [ <angle> | <zero> ] )"},"rotateZ()":{"syntax":"rotateZ( [ <angle> | <zero> ] )"},"saturate()":{"syntax":"saturate( <number-percentage> )"},"scale()":{"syntax":"scale( <number> , <number>? )"},"scale3d()":{"syntax":"scale3d( <number> , <number> , <number> )"},"scaleX()":{"syntax":"scaleX( <number> )"},"scaleY()":{"syntax":"scaleY( <number> )"},"scaleZ()":{"syntax":"scaleZ( <number> )"},"self-position":{"syntax":"center | start | end | self-start | self-end | flex-start | flex-end"},"shape-radius":{"syntax":"<length-percentage> | closest-side | farthest-side"},"skew()":{"syntax":"skew( [ <angle> | <zero> ] , [ <angle> | <zero> ]? )"},"skewX()":{"syntax":"skewX( [ <angle> | <zero> ] )"},"skewY()":{"syntax":"skewY( [ <angle> | <zero> ] )"},"sepia()":{"syntax":"sepia( <number-percentage> )"},"shadow":{"syntax":"inset? && <length>{2,4} && <color>?"},"shadow-t":{"syntax":"[ <length>{2,3} && <color>? ]"},"shape":{"syntax":"rect(<top>, <right>, <bottom>, <left>)"},"shape-box":{"syntax":"<box> | margin-box"},"side-or-corner":{"syntax":"[ left | right ] || [ top | bottom ]"},"single-animation":{"syntax":"<time> || <timing-function> || <time> || <single-animation-iteration-count> || <single-animation-direction> || <single-animation-fill-mode> || <single-animation-play-state> || [ none | <keyframes-name> ]"},"single-animation-direction":{"syntax":"normal | reverse | alternate | alternate-reverse"},"single-animation-fill-mode":{"syntax":"none | forwards | backwards | both"},"single-animation-iteration-count":{"syntax":"infinite | <number>"},"single-animation-play-state":{"syntax":"running | paused"},"single-transition":{"syntax":"[ none | <single-transition-property> ] || <time> || <timing-function> || <time>"},"single-transition-property":{"syntax":"all | <custom-ident>"},"size":{"syntax":"closest-side | farthest-side | closest-corner | farthest-corner | <length> | <length-percentage>{2}"},"step-position":{"syntax":"jump-start | jump-end | jump-none | jump-both | start | end"},"step-timing-function":{"syntax":"step-start | step-end | steps(<integer>[, <step-position>]?)"},"subclass-selector":{"syntax":"<id-selector> | <class-selector> | <attribute-selector> | <pseudo-class-selector>"},"supports-condition":{"syntax":"not <supports-in-parens> | <supports-in-parens> [ and <supports-in-parens> ]* | <supports-in-parens> [ or <supports-in-parens> ]*"},"supports-in-parens":{"syntax":"( <supports-condition> ) | <supports-feature> | <general-enclosed>"},"supports-feature":{"syntax":"<supports-decl> | <supports-selector-fn>"},"supports-decl":{"syntax":"( <declaration> )"},"supports-selector-fn":{"syntax":"selector( <complex-selector> )"},"symbol":{"syntax":"<string> | <image> | <custom-ident>"},"target":{"syntax":"<target-counter()> | <target-counters()> | <target-text()>"},"target-counter()":{"syntax":"target-counter( [ <string> | <url> ] , <custom-ident> , <counter-style>? )"},"target-counters()":{"syntax":"target-counters( [ <string> | <url> ] , <custom-ident> , <string> , <counter-style>? )"},"target-text()":{"syntax":"target-text( [ <string> | <url> ] , [ content | before | after | first-letter ]? )"},"time-percentage":{"syntax":"<time> | <percentage>"},"timing-function":{"syntax":"linear | <cubic-bezier-timing-function> | <step-timing-function>"},"track-breadth":{"syntax":"<length-percentage> | <flex> | min-content | max-content | auto"},"track-list":{"syntax":"[ <line-names>? [ <track-size> | <track-repeat> ] ]+ <line-names>?"},"track-repeat":{"syntax":"repeat( [ <positive-integer> ] , [ <line-names>? <track-size> ]+ <line-names>? )"},"track-size":{"syntax":"<track-breadth> | minmax( <inflexible-breadth> , <track-breadth> ) | fit-content( [ <length> | <percentage> ] )"},"transform-function":{"syntax":"<matrix()> | <translate()> | <translateX()> | <translateY()> | <scale()> | <scaleX()> | <scaleY()> | <rotate()> | <skew()> | <skewX()> | <skewY()> | <matrix3d()> | <translate3d()> | <translateZ()> | <scale3d()> | <scaleZ()> | <rotate3d()> | <rotateX()> | <rotateY()> | <rotateZ()> | <perspective()>"},"transform-list":{"syntax":"<transform-function>+"},"translate()":{"syntax":"translate( <length-percentage> , <length-percentage>? )"},"translate3d()":{"syntax":"translate3d( <length-percentage> , <length-percentage> , <length> )"},"translateX()":{"syntax":"translateX( <length-percentage> )"},"translateY()":{"syntax":"translateY( <length-percentage> )"},"translateZ()":{"syntax":"translateZ( <length> )"},"type-or-unit":{"syntax":"string | color | url | integer | number | length | angle | time | frequency | cap | ch | em | ex | ic | lh | rlh | rem | vb | vi | vw | vh | vmin | vmax | mm | Q | cm | in | pt | pc | px | deg | grad | rad | turn | ms | s | Hz | kHz | %"},"type-selector":{"syntax":"<wq-name> | <ns-prefix>? \'*\'"},"var()":{"syntax":"var( <custom-property-name> , <declaration-value>? )"},"viewport-length":{"syntax":"auto | <length-percentage>"},"wq-name":{"syntax":"<ns-prefix>? <ident-token>"}}')},2413:e=>{"use strict"
e.exports=require("stream")},4304:e=>{"use strict"
e.exports=require("string_decoder")}}
var t={}
function r(n){if(t[n])return t[n].exports
var a=t[n]={exports:{}}
e[n].call(a.exports,a,a.exports,r)
return a.exports}r.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e
r.d(t,{a:t})
return t}
r.d=(e,t)=>{for(var n in t)r.o(t,n)&&!r.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})}
r.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t)
r.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})
Object.defineProperty(e,"__esModule",{value:!0})}
return r(1691)})().default},"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typeof define&&define.amd?define([],t):"object"==typeof exports?exports.SVGO=t():e.SVGO=t()
var e,t